Spamchat = {
"Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger Nigger"
}

Spamchat2 = {
"get 2take1 you broke ass bitch bitch"
}

Spamchat3 = {
"Try crash me, you wont lol"
}

Spamchat4 = {
"fuck trump! fuck trump! fuck trump! fuck trump! fuck trump! fuck trump! fuck trump! fuck trump!"
}

Spamchat5 = {
"Covid is fake! Covid is fake! Covid is fake! Covid is fake! Covid is fake! "
}

Spamchat5 = {
"Covid is fake! Covid is fake! Covid is fake! Covid is fake! Covid is fake! "
}

Spamchat6 = {
"Covid is real! Covid is real! Covid is real! Covid is real! Covid is real! "
}

Spamchat7 = {
"all blacks need to be locked up and killed!! hahaahahaaa George Floyd WHO!? George Floyd Dead!!!!"
}

Spamchat8 = {
"fuck the whites, fuck the kkk fuck them all!! allah wakbah"
}

Spamchat9 = {
"nigger fuck shit pussy cum porn ass child porn fuck me hard daddy abuse rape doggy style"
}

Spamchat10 = {
"I am op af. be like me"
}

Spamchat11 = {
""..name.." is greater then everyone in here"
}