Lyrics = {
"Roses are red, violets are blue, the zoo is out of monkeys. Your family would do."
}

Lyrics2 = {
"Roses are red, violets are blue, all s*** are brown, just like you."
}

Lyrics3 = {
"Roses are red, violets are blue, your mother is a whore and thats all i knew"
}

Lyrics4 = {
"Roses are red, violets are blue, my cocks so huge and your mother knew that too"
}

Lyrics5 = {
"Your dick is big and your dad is bigger but neither compare to the dick on this nigger"
}

Lyrics6 = {
    "Body crazy, curvy, wavy, big titties, lil' waist (yeah, yeah)",
    "Body-ody-ody-ody-ody-ody-ody-ody",
    "Ody-ody-ody-ody-ody-ody-ody (ah, ah, ah, ah)",
    "So there you go OH cant make a wife out of a hoe"
    }