LyricsSong6 = {
"Body crazy, curvy, wavy, big titties, lil' waist (yeah, yeah)",
"Body-ody-ody-ody-ody-ody-ody-ody",
"Ody-ody-ody-ody-ody-ody-ody (ah, ah, ah, ah)",
"So there you go OH cant make a wife out of a hoe"
}